/*
 /// <summary>
 /// app.modules.install.controllers - parameterEditWMQCtrl.js
 /// Controller to manage Default Websphere Message Queuing parameter editing
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Created By: Mac Bhyat
 /// Date: 22/02/2017
 /// </summary>
 */
define(['modules/admin/module', 'lodash', 'bootstrap-validator'], function (module, lodash) {

	"use strict";

	module.registerController('parameterEditWMQCtrl', ['$scope', '$timeout', '$element','$log', '$state','uiSvc','cacheDataSvc','adminDataSvc', function ($scope, $timeout, divElement, $log, $state, uiSvc, cacheDataSvc, adminDataSvc) {

	    // initialize the variables
        $scope.vm.model = {};
        $scope.bv = {};
        $scope.bvWatch = {value: -1};
        $scope.loadFlag = 0;

        $scope.onFieldValidate = function(isError)
        {
                // tell the wizard that the form has changed
                $scope.vm.state.form.hasChanged = true;
        };

        var getValidator = function ()
        {
            // routine to return the validator for this form
            return $scope.bv;
        };





        var updateCallback = function()
        {
            // function to update the record to the database
            adminDataSvc.saveDefaultMQ($scope.vm.model).then(function(result)
            {
                uiSvc.showExtraSmallPopup("WMQ Connectivity Settings", "The WMQ Connectivity Details have been updated successfully !", 5000);
                // if we are in wizard mode - get the next step
                if ($scope.vm.wizard)
                    $scope.vm.functions.moveNext();

            }).catch(function (err) {
                $log.error("Unable to Update WMQ Connectivity Settings", err);
            })


        };

        var initialize = function()
        {
            // routine to read the record from the database and update the model

            adminDataSvc.readDefaultMQ().then(function(result)
            {
                $scope.vm.model = result;

                // now setup the form
                if ($scope.vm.wizard)
                    $scope.vm.functions.initializeStep(result, getValidator, updateCallback);
                else
                    $scope.vm.functions.initializeSettingWithModel(result, getValidator, updateCallback);
                if ($scope.loadFlag == 2) // form has already loaded
                {
                    // initialize the form
                    var formElement = $(divElement).first();
                    $scope.vm.functions.stepContentLoaded(formElement);
                }
                $scope.loadFlag = 1;
            }).catch(function(err)
            {
                $log.error("WMQ Connectivity Settings Initialization Error", err);
            });

        };


        // initialize the step
        $scope.$on('$viewContentLoaded', function()
        {
            // when the DOM has loaded initialize BV
           $timeout(function()
           {
               if ($scope.loadFlag == 1) // read has been read
               {

                   var formElement = $(divElement).first();
                   $scope.vm.functions.stepContentLoaded(formElement);
               }
               else
                   $scope.loadFlag = 2; // screen has load but the model has not
           }, 500);
        });

        initialize();
    }]);
});
