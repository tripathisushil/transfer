/*
 /// <summary>
 /// app.modules.admin.controllers - parameterNotifyGroupListCtrl.js
 /// Controller to manage Editing of Notification Groups
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 24/06/2017
 /// </summary>
 */
define(['modules/admin/module', 'lodash', 'bootstrap-validator', 'angular-jsoneditor'], function (module, lodash) {

    "use strict";

    module.registerController('parameterNotifyGroupListCtrl', ['$scope', '$log','userSvc','adminDataSvc','cacheDataSvc','uiSvc', function ($scope, $log,userSvc,adminDataSvc,cacheDataSvc,uiSvc)
    {
        var _this = this;

        // add the initial data
        _this.model = {gridData:[], data:[], viewData:{}, mainCaption: "Add Group...", editorHTML:"<mqa-adm-notify-group-edit/>"};
        _this.functions = [];
        var companyId = userSvc.getOrgInfo().companyId;
        var type = "NotifyGroup";


        var initialize = function() {
            // routine to initialize the grid upon load
            _this.functions.gridSetup();
            adminDataSvc.listFunctions.initialize(_this, companyId, type);
            _this.model.viewData.allRoles = cacheDataSvc.getListForType("1", "Role", companyId);

        };


        var buildLists = function()
        {
            // routine to build up the list of roles and users
            var modelInclude =
            {
                    listFilterType: 1, //users in the list and in the company
                    companyId: companyId,
                    userList: $scope.editRow.jsonData.users
            };

            adminDataSvc.findUsers(modelInclude).then(function(result)
            {
                _this.model.viewData.includedUsersServer = result;
                _this.model.viewData.users = lodash.map(result, function(user)
                {
                    return {id: user.id, caption: user.name};
                });
            }).catch(function(err)
            {
               $log.error("Unable to find users for Company", err);
            });

            var modelExclude =
                {
                    listFilterType: 0, //users in company but not in list
                    companyId: companyId,
                    userList: $scope.editRow.jsonData.users
                };

           adminDataSvc.findUsers(modelExclude).then(function(result)
            {
                _this.model.viewData.excludedUsersServer = result;
                _this.model.viewData.excludedUsers = lodash.map(result, function(user)
                {
                    return {id: user.id, caption: user.name};
                });
            }).catch(function(err)
            {
                $log.error("Unable to find users for Company", err);
            });

            // update the role lists
            _this.model.viewData.roles = lodash.map($scope.editRow.jsonData.roles, function(role)
            {
                var record = lodash.find(_this.model.viewData.allRoles, {code: role});
                return {id: role, caption: record.description};
            });
            var exclusions = lodash.filter(_this.model.viewData.allRoles, function (role)
            {
                var record = lodash.find(_this.model.viewData.roles, {id: role.code});
                return record == null;
            });
            // update the role lists
            _this.model.viewData.excludedRoles = lodash.map(exclusions, function(role)
            {
                return {id: role.code, caption: role.description};
            });

            // update the api end points
            if (!$scope.editRow.jsonData.endPoints)
                $scope.editRow.jsonData.endPoints = [];
        };


        //<editor-fold desc="Edit Form  Setup">

        $scope.editRecord = function(row)
        {
            // routine to edit the given row
            adminDataSvc.listFunctions.editRecord(row, _this, $scope);
            buildLists();
        };

        $scope.insertRecord = function()
        {
            // routine to initialize the new record
            adminDataSvc.listFunctions.insertRecord(_this, $scope, companyId, type);
            $scope.editRow.jsonData = {users:[], queues:[], roles:[], endPoints:[]};
            buildLists();
        };

        $scope.cancelRecord = function()
        {
            adminDataSvc.listFunctions.cancelRecord(_this);
            _this.model.showEdit = false;
        };

        $scope.saveRecord = function()
        {
            // routine to save the record

            // update the queue list
            if ($scope.editRow.jsonData.queues)
            {
                var queues = lodash.map($scope.editRow.jsonData.queues, function (record) {
                    return {queue: record.queue, queueManager: record.queueManager};
                });
                $scope.editRow.jsonData.queues = queues;
            };
            adminDataSvc.listFunctions.saveRecord($scope, _this);
        };

        $scope.deleteRecord = function()
        {
            // routine to be called when the user chooses to delete a record
            adminDataSvc.listFunctions.deleteRecord($scope, _this);
        };

        _this.functions.updateFunction = function()
        {
            // routine to post the updates to the server
            adminDataSvc.listFunctions.postUpdates(companyId, _this, "System Parameters", "Notification Groups");
        };
        //</editor-fold>

        //<editor-fold desc="Grid Setup">
        _this.functions.gridSetup = function()
        {
            _this.model.grid = {};
            _this.model.grid.dataOptions = {
                sortable: true,
                groupable: false,
                filterable: true,
                columnMenu: true,
                resizable: false,
                pageable: {
                    pageSizes: true
                },
                selectable: "row",
                dataSource:
                {
                    data: [],
                    pageSize: 10,
                    sort:
                        [

                            {field:	"code", dir:"asc"}
                        ],
                    schema:
                    {
                        model:
                        {
                            id: "rowId",
                            uid:"rowId"
                        }
                    }
                },
                columns: [
                    {field: "rowId", type: "string", tooltip: false,hidden: true},
                    {field: "rowStyle", type: "string", tooltip: false,hidden: true},
                    {field: "recordStatus",type: "string", tooltip: false,hidden: true},
                    {field: "code", title: "Code", type: "string", tooltip: false},
                    {field: "description", title: "Description", type: "string", tooltip: false},
                    {
                        field: "items",
                        title: "Details",
                        filterable: false,
                        template: function(dataItem)
                        {
                            if (dataItem.jsonData && dataItem.jsonData != "")
                            {

                                var html = "<ul class='list-inline'>";
                                if (dataItem.jsonData.users)
                                    html += "<li>Users <span class='badge bg-color-blue txt-color-white'>" + dataItem.jsonData.users.length + "</span></li>";
                                if (dataItem.jsonData.roles)
                                    html += "<li>Roles <span class='badge bg-color-blueDark txt-color-white'>" + dataItem.jsonData.roles.length + "</span></li>";
                                if (dataItem.jsonData.queues)
                                    html += "<li>Queues <span class='badge bg-color-purple txt-color-white'>" + dataItem.jsonData.queues.length + "</span></li>";
                                if (dataItem.jsonData.endPoints)
                                    html += "<li>API End Points <span class='badge bg-color-orange txt-color-white'>" + dataItem.jsonData.endPoints.length + "</span></li>";
                                html += "</ul>";
                                return html;
                            }
                            else
                                return "";
                        }
                    }



                ],
                dataBound: function(e)
                {
                    var grid = this;
                    uiSvc.dataBoundKendoGrid(grid);
                }
            };
        };

        //</editor-fold>

        initialize();
    }]);
});