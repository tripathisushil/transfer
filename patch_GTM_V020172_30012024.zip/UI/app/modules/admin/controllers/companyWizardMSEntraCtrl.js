/*
 /// <summary>
 /// app.modules.admin.controllers - companyWizardMSEntraCtrl.js
 /// Controller to manage Company Wizard - Microsoft-Entra Validation Information
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Created By Mac Bhyat
 /// Date: 22/01/2024
 /// </summary>
 */
define(['modules/admin/module','bootstrap-validator'], function (module) {

	"use strict";

	module.registerController('companyWizardMSEntraCtrl', ['$scope', '$timeout','$element', 'uiSvc','adminDataSvc', function ($scope, $timeout, divElement, uiSvc, adminDataSvc) {

        let _this = this;

        //<editor-fold desc="Functions">
        _this.functions = {};

        _this.functions.field_validation = function(isError)
        {
            // custom validation processing - nothing to do here as bootstrapvalidator will handle everything
        };
        _this.functions.form_validation = function()
        {
            // reset the hidden field and call it again
            $scope.vm.functions.validateForm();
        };
        _this.functions.updateFunction = function()
        {
            // function to run when in non-new company mode and we want to update the database directly
            let model = {validation_type: parseInt($scope.vm.validation.type), validation_details: $scope.vm.model.company.validation_details, validate: true};
            adminDataSvc.saveCompanyValidation($scope.vm.model.company.id, model).then(function(result)
            {
                $scope.$parent.vm.state.form.hasChanged = false;
                $scope.vm.model.company.validation_details = result;
                uiSvc.showExtraSmallPopup("Validation Details", "The Entra Information has been Updated Successfully !", 5000);
            });
        };
        //</editor-fold>

        //<editor-fold desc="Wizard Overrides">
        let bootValidatorOptions = {
            fields: {
                appId: {
                    group:"#div_sid",
                    excluded: true
                },
                tenantId: {
                    excluded: false,
                    group:"#div_tenant",
                    validators: {
                        notEmpty: {
                            message: 'Tenant ID cannot be Empty'
                        },
                    }
                },
                clientId: {
                    excluded: false,
                    group:"#div_client",
                    validators: {
                        notEmpty: {
                            message: 'Client ID cannot be Empty'
                        },
                    }
                },
                clientSecret: {
                    excluded: false,
                    group:"#div_graph",
                    validators: {
                        notEmpty: {
                            message: 'Graph API Secret cannot be Empty'
                        },
                    }
                },

            }
        };

        $scope.vm.functions.initializeStep(bootValidatorOptions, _this.functions.field_validation, _this.functions.updateFunction, _this.functions.form_validation, null);
        $scope.$on('$viewContentLoaded', function()
        {

            // when the DOM has loaded initialize BV
           $timeout(function()
           {
                var formElement = $(divElement).first();
                $scope.vm.functions.stepContentLoaded(formElement);
           }, 500);
        });
        //</editor-fold>
    }]);
});
