/*
 /// <summary>
 /// app.modules.admin.controllers - companyWizardADUserCtrl.js
 /// Controller to manage Company Wizard -  User Add and Edit (Active Directory)
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Created By Mac Bhyat
 /// Date: 22/02/2017
 /// </summary>
 */
define(['modules/admin/module', 'lodash', 'bootstrap-validator'], function (module, lodash) {

    "use strict";

    module.registerController('companyWizardADUserCtrl', ['$scope', '$timeout', '$element', '$log', '$uibModal', 'uiSvc','jqueryuiSvc', 'adminDataSvc', 'cacheDataSvc', function ($scope, $timeout, divElement, $log, $uibModal, uiSvc, jqueryuiSvc, adminDataSvc, cacheDataSvc)
    {

        var _this = this;
        _this.functions = {};
        _this.model = {};
        let _parentModel = null;


        _this.functions.checkInsertDepts = function()
        {
            // routine to revalidate the field on bv when the departments changes
            if ($scope.$parent.vm.state && $scope.$parent.vm.state.step.validator && _this.model.domainRecord.insertedUsers.length > 0)
            {
                $scope.$parent.vm.state.step.validator.revalidateField('hiddenDept');
            }
        };
        _this.functions.checkInsertRoles = function()
        {
            // routine to revalidate the field on bv when the departments changes
            if ($scope.$parent.vm.state && $scope.$parent.vm.state.step.validator && _this.model.domainRecord.insertedUsers.length > 0)
            {
                $scope.$parent.vm.state.step.validator.revalidateField('hiddenRole');
            }
        };
        _this.functions.toggleAdd = function()
        {
            //  routine to manage the form  when the user has clicked the add
            if (!_this.model.flags.showAddUser)
                _this.functions.buildAddUserList();
            else
            {
                _this.model.flags.showAddUser = !_this.model.flags.showAddUser;
                _this.model.addMessage = "Add Users...";
            }
        };
        _this.functions.onFieldValidated = function(isError)
        {
            // tell the wizard that the form has changed
            $scope.$parent.vm.state.form.hasChanged = true;
        };



        _this.functions.changeDomain = function(flag)
        {
            // routine to trigger when the user has changed the domain
            if ($scope.$parent.vm.state.step.validator && flag > 0)
            {
                // if the validator has been initialized check it
                $scope.$parent.vm.state.step.validator.revalidateField("domainSelect");
                $scope.$parent.vm.state.step.validator.revalidateField("hiddenRole");
                $scope.$parent.vm.state.step.validator.revalidateField("hiddenDept");
                var valid = scope.$parent.vm.state.step.validator.isValid();
                if (!valid)
                    return;
            }
            if (!_this.model.domainSelect)
                return;
            _this.model.domainRecord = lodash.find(_this.model.domains, {id: _this.model.domainSelect});

            // initialize the variable
            _this.model.addMessage = "Add Users...";
            _this.model.flags.showAddUser = false;
            _this.model.flags.adLoading = false;

            // rebuild the current list
            _this.functions.updateCurrentUserList();
        };

        _this.functions.updateCurrentUserList = function()
        {
            // routine to update the current user list when the domain changes or the current list is edited
            _this.model.currentUserList = lodash.filter(_this.model.users, {domain: _this.model.domainRecord.id});
            _this.model.flags.currentUsersFlag.value += 1;
        };

        _this.functions.updateCounts = function(inserts)
        {

            if (inserts)
            {
                // routine to update the insert and invalid counts
                _this.model.counts.inserted = 0;
                _this.model.counts.invalid = 0;
                lodash.forEach(_this.model.domains, function(domain)
                {
                   _this.model.counts.inserted += domain.insertedUsers.length;
                   _this.model.counts.invalid += domain.invalidUsers.length;
                });

                if ($scope.$parent.vm.state && $scope.$parent.vm.state.step.validator)
                {
                    $scope.$parent.vm.state.step.validator.revalidateField("hiddenDept");
                    $scope.$parent.vm.state.step.validator.revalidateField("hiddenRole");
                }
            }
            else
            {
                _this.model.counts.deleted = lodash.filter(_this.model.users, {recordStatus: uiSvc.editModes.DELETE}).length;
                _this.model.counts.updated = lodash.filter(_this.model.users, {rowStyle: "recordUpdate"}).length;
            }
        };


        _this.functions.initialize = function(initializeStep)
        {
            // routine to initialize the screen
            _this.model = {lastRowId: -1, flags:{showAddUser: false, adLoading: false}, counts: {deleted: 0, inserted: 0, invalid: 0, updated: 0}, domains:[], addMessage:"Add Users...", domainSelect: null, insertSelector:{}};


            if (!$scope.$parent.vm.model || !$scope.$parent.vm.model.company)
            {
                $timeout(function()
                {
                    _this.functions.initialize();
                }, 2000);
                return;
            }
            _parentModel = $scope.$parent.vm.model;

            // create the domain objects
            if (!$scope.vm.model.company.validation_details.domains)
                $scope.vm.model.company.validation_details.domains = [];
            $scope.vm.model.domains =  $scope.vm.model.company.validation_details.domains;
            _this.model.domains = lodash.map($scope.vm.model.domains, function (domain)
            {
                return {id: domain.domain, roles:[], departments:[], insertedUsers:[], invalidUsers:[], userList:[]};
            })
            // get the roles for this company
            _this.model.roleList = cacheDataSvc.getListForType("1","Role", _parentModel.company.id);
            _this.model.departmentList = $scope.$parent.vm.functions.getDepartments();
            _this.model.users = _parentModel.users;

            // update the last ids
            _this.model.lastRowId = -1;
            lodash.forEach(_this.model.users, function(record)
            {
                _this.model.lastRowId++;
                record.rowId = _this.model.lastRowId;
                record.rowStyle = null;
            });

            // update the grid options
            _this.model.flags.currentUsersFlag = {value: 0};
            _this.model.currentUserGridOptions = {
                sortable: true,
                groupable: true,
                filterable: true,
                pageable: {
                    pageSizes: true
                },
                dataSource: {
                    data: [],
                    pageSize: 10,
                    schema: {
                        model: {
                            id: "id",
                            uid: "id",
                            fields: {
                                id: {type: "number"},
                                userId: {type: "string"},
                                name: {type: "string"},
                                emailAddress: {type: "string"},
                                domain: {type: "string"}
                            }
                        }
                    }
                },

                columns: [
                    {
                        field: "id",
                        title: "Id",
                        hidden: true
                    },
                    {
                        field: 'name',
                        title: 'Name'
                    },
                    {
                        field: 'emailAddress',
                        title: 'Email Address'
                    },
                    {
                        field: 'userId',
                        title: 'Login Code',
                        template: function(dataItem)
                        {
                            if (dataItem.domain && dataItem.domain != "")
                                return dataItem.domain + "\\" + dataItem.userId;
                            else
                                return dataItem.userId;
                        }
                    },
                    {
                        field: 'roles',
                        title: 'Roles',
                        template: function(dataItem)
                        {
                            if (dataItem.roles)
                            {

                                var html = "<ul style='list-style-type: disc'>";
                                lodash.forEach(dataItem.roles, function (roleItem)
                                {
                                    var role = lodash.find(_this.model.roleList, {code: roleItem});
                                    if (role != null)
                                        html += "<li>" + role.description + "</li>";
                                });
                                html += "</ul>";
                                return html;
                            }
                        }
                    }


                ],
                dataBound: function (e)
                {
                    var grid = this;
                    uiSvc.dataBoundKendoGrid(grid,  _this.functions.editUser);
                }
            };
            _this.model.addUserGridOptions =  {
                sortable: true,
                groupable: true,
                filterable: true,
                pageable: {
                    pageSizes: true
                },
                dataSource: {
                    data: [],
                    pageSize: 10,
                    schema: {
                        model: {
                            id: "id",
                            uid: "id",
                            fields: {
                                id: {type: "number"},
                                userId: {type: "string"},
                                name: {type: "string"},
                                emailAddress: {type: "string"},
                                domain: {type: "string"}
                            }
                        }
                    }
                },

                columns: [
                    {
                        field: "id",
                        title: "Id",
                        hidden: true
                    },
                    {
                        field: "select",
                        title: "Select",
                        width: "80px",
                        template: function (dataItem)
                        {
                            return '<input type="checkbox" name="rolesCheckbox[]" ng-model="selections[\'' + dataItem.userId + '\']">';
                        }
                    },
                    {
                        field: 'name',
                        title: 'Name'
                    },
                    {
                        field: 'emailAddress',
                        title: 'Email Address'
                    },
                    {
                        field: 'userId',
                        title: 'Login Code',
                        template: function(dataItem)
                        {
                            if (dataItem.domain && dataItem.domain != "")
                                return dataItem.domain + "\\" + dataItem.userId;
                            else
                                return dataItem.userId;
                        }

                    }

                ]
            }

            // select the first domain
            if (_parentModel.domains && _parentModel.domains.length > 0)
            {
                _this.model.domainSelect = _parentModel.domains[0].domain;
                _this.functions.changeDomain(0);
            }
        };

        _this.functions.buildAddUserList = function()
        {
            // routine to rebuild the add user selection list when the the user selects "Add User"
            _this.model.domainRecord.userList = [];
            _this.model.flags.adLoading = true;
            _this.model.adMessage = "Please Wait...";
            let domain = lodash.find(_parentModel.domains, {domain: _this.model.domainSelect});
            _this.model.addGridTitle = "Select the Users to Add - [LDAP Filter: " + domain.searchString + "]";

            // update the add user departments and roles
            let domains = [];
            domains.push(domain);
            let model = {validation_type: 1, validation_details: {domains: domains}};
            adminDataSvc.getUnRegisteredUsers( _parentModel.company.id, model).then(function(result)
            {
                _this.model.domainRecord.userList = result;

                // update the insert selector
                _this.model.insertSelector = {};
                lodash.forEach(_this.model.domainRecord.insertedUsers, function(user)
                {
                   _this.model.insertSelector[user.userId] = true;
                });
                _this.model.addMessage = "Hide Users...";
                _this.model.flags.showAddUser = true;
            }).catch(function(err)
            {
                $log.error("Unable to retrieve a List of AD Users", err);
            }).finally(function()
            {
                _this.model.flags.adLoading = false;
            });

        };


        _this.functions.updateInsertList = function(newValue)
        {
            // routine to update the inserted and invalid users as the user chooses from the grid
            var users = [];
            _this.model.domainRecord.insertedUsers = [];
            _this.model.domainRecord.invalidUsers = [];

            lodash.forOwn(lodash.pickBy(newValue), function (value, key) {
                users.push(key);
            });
            lodash.map(users, function(user)
            {
                var userRecord = lodash.find(_this.model.domainRecord.userList, {userId: user});
                if (!userRecord.emailAddress || !userRecord.name)
                    _this.model.domainRecord.invalidUsers.push({userId: user});
                else
                {
                    _this.model.domainRecord.insertedUsers.push(userRecord);
                }
            });
            _this.functions.updateCounts(true);
        };

        _this.functions.updateFunction = function()
        {
            // function to run when in non-new company mode and we want to update the database directly
            _this.model.expectedPostCount = _this.model.domains.length;
            _this.model.successPostCount = 0;
            lodash.forEach(_this.model.domains, function(domain)
            {
                let apiCallModel = {users:lodash.filter(_this.model.users, {domain: domain.id}), departments: domain.departments, roles: domain.roles};
                lodash.forEach(domain.insertedUsers, function(user)
                {
                    user.recordStatus = uiSvc.editModes.INSERT; // inserted
                    user.domain = domain.id;
                    user.id = 0;
                    apiCallModel.users.push(user);
                });

                adminDataSvc.saveUsersBulk(_parentModel.company.id, apiCallModel).then(function(result)
                {
                    uiSvc.showExtraSmallPopup("Active Directory Users", "The User List for domain " + domain.id + " been Updated Successfully !", 5000);

                    // check if we can refresh the screen
                    _this.model.userList = lodash.remove(_this.model.userList, {domain: domain.id});
                    _this.model.userList = lodash.concat(_this.model.userList, result);
                    _this.model.successPostCount++;
                    if (_this.model.successPostCount == _this.model.expectedPostCount)
                    {
                        _parentModel.users =_this.model.userList;
                        $scope.$parent.vm.state.form.hasChanged = false;
                        $scope.$parent.vm.state.form.flag = uiSvc.formStates.INDETERMINATE;
                        _this.functions.initialize();
                    }
                }).catch(function (err)
                {
                    _this.model.successPostCount++;
                    $log.error("Unable to Update Active Directory Users for Domain " + domain.id, err);
                    if (_this.model.successPostCount == _this.model.expectedPostCount)
                    {
                        _parentModel.users =_this.model.userList;
                        _this.functions.initialize();
                    }
                });
            });
        };

        _this.functions.editUser = function(record)
        {
            // routine to edit the existing user
            record.recordStatus = uiSvc.editModes.UPDATE;
            _this.functions.showDialog(record);
        };

        _this.functions.showDialog = function(record)
        {
            // routine to bring up the editing dialog
            var dialogData = {};
            dialogData = {users: _this.model.userList, roles: _this.model.roleList, departments: _this.model.departmentList};
            dialogData.record = angular.copy(record);
            dialogData.flags =  {allowUserId: record.userId == null, allowRoles: true, adUser: true};

            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/modules/admin/partials/company-user-edit-wizard-dialog.tpl.html',
                controller: 'companyWizardUserEditDialogCtrl',
                controllerAs: 'vmDialog',
                backdrop: 'static',
                size:'lg',
                resolve:
                    {
                        dialogData: dialogData
                    }
            });
            modalInstance.result.then(function(result)
            {
                // close the dialog
                _this.model.lastRowId = adminDataSvc.updateUserRecord(result, _this.model.users, _this.model.lastRowId);
                modalInstance.close();
                _this.functions.updateCurrentUserList();
                _this.functions.updateCounts(false);
            }, function () {
            });
        };
    _this.functions.validateForm = function()
        {
            // validate the form
            $scope.$parent.vm.functions.validateForm();
        };


        $scope.$watch("vmStep.model.insertSelector", function(newValue)
        {
            // work out the insert users and invalid users when the user selection changes
            if (!newValue)
                return;
            _this.functions.updateInsertList(newValue);
        }, true);

        // initialize the step
        $scope.$on('$viewContentLoaded', function()
        {
            // when the DOM has loaded initialize BV
            $timeout(function()
            {
                var fields = {
                    fields: {
                        hiddenDept: {
                            validators: {
                                callback: {
                                    enabled: true,
                                    message: 'Users must be assigned to at least 1 Department',
                                    callback: function (value, validator, $field)
                                    {
                                        if (!_this.model.domainRecord)
                                            return true;
                                        var insertCount = _this.model.domainRecord.insertedUsers.length > 0;
                                        if (insertCount > 0 && _this.model.domainRecord.departments.length == 0) {
                                            return false;
                                        }
                                        return true;
                                    }
                                }
                            }
                        },
                        hiddenRole: {
                            validators: {
                                callback: {
                                    enabled: true,
                                    message: 'Users must be assigned to at least 1 Role',
                                    callback: function (value, validator, $field) {
                                        if (!_this.model.domainRecord)
                                            return true;
                                        var insertCount = _this.model.domainRecord.insertedUsers.length > 0;
                                        if (insertCount > 0 && _this.model.domainRecord.roles.length == 0) {
                                            return false;
                                        }
                                        return true;
                                    }
                                }

                            }
                        },
                        domainSelect: {
                            group: '#div_domain',
                            excluded: false,
                            validators:
                                {
                                    notEmpty: {
                                        message: 'Please Select a Domain'
                                    },
                                    callback:
                                        {
                                            message: 'Departments or Roles Invalid',
                                            callback: function (value, validator, $field) {
                                                // check that there is depts and roles for the if there are users inserted
                                                if (!_this.model.domainRecord)
                                                    return true;
                                                var insertCount = _this.model.domainRecord.insertedUsers.length > 0;
                                                if (insertCount > 0 && _this.model.domainRecord.departments.length == 0) {
                                                    return false;
                                                }
                                                if (insertCount > 0 && _this.model.domainRecord.roles.length == 0) {
                                                    return false;
                                                }
                                                return true;
                                            }

                                        }
                                }
                        }
                    }
                };
                var formOptions = lodash.merge({excluded: ':disabled'}, jqueryuiSvc.getFormValidateOptions(), fields);
                $scope.$parent.vm.functions.initializeStep(formOptions, _this.functions.onFieldValidated, _this.functions.updateFunction, _this.functions.validateForm, null);
                var formElement = $(divElement).first();
                $scope.$parent.vm.functions.stepContentLoaded(formElement);
            }, 500);
        });
        _this.functions.initialize();
    }]);
});
