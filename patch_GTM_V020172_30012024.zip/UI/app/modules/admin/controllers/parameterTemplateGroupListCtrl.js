/*
 /// <summary>
 /// app.modules.admin.controllers - parameterTemplateGroupListCtrl.js
 /// Controller to manage Editing of Template Groups
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 01/07/2017
 /// </summary>
 */
define(['modules/admin/module', 'lodash', 'bootstrap-validator', 'angular-summernote'], function (module, lodash) {

    "use strict";

    module.registerController('parameterTemplateGroupListCtrl', ['$scope', '$log','$filter', '$timeout','userSvc','adminDataSvc','uiSvc', function ($scope, $log,$filter,$timeout,userSvc,adminDataSvc,uiSvc)
    {
        var _this = this;

        // add the initial data
        _this.model = {gridData:[], data:[], viewData:{}};
        _this.functions = [];
        var companyId = userSvc.getOrgInfo().companyId;
        var type = "TemplateGroup";


        var initialize = function()
        {
            // routine to initialize the grid upon load
            _this.functions.gridSetup();
            adminDataSvc.listFunctions.initialize(_this, companyId, type);
        };


        //<editor-fold desc="Edit Form  Setup">

        $scope.editRecord = function(row)
        {
            // routine to edit the given row
            adminDataSvc.listFunctions.editRecord(row, _this, $scope);
        };

        $scope.insertRecord = function()
        {
            // routine to initialize the new record
            adminDataSvc.listFunctions.insertRecord(_this, $scope, companyId, type);
        };

        $scope.cancelRecord = function()
        {
            adminDataSvc.listFunctions.cancelRecord(_this);
            _this.model.showEdit = false;
        };

        $scope.saveRecord = function()
        {
            // post the current record
            if ($scope.editRow.isNew)
            {
                $scope.editRow.recordStatus = uiSvc.editModes.INSERT;
            }
            else
            {
                // update the existing row
                if (!$scope.editRow.recordStatus)
                    $scope.editRow.recordStatus = uiSvc.editModes.UPDATE;
            }

            // post the record
            adminDataSvc.saveTemplateGroup($scope.editRow).then(function(result)
            {
                adminDataSvc.listFunctions.initialize(_this, companyId, type);
                uiSvc.showExtraSmallPopup("System Parameters", "Template Group Update Successful !", 5000);
            }).catch(function(err)
            {
                $log.error("Unable to Save Template Group", err);
            });
        };

        $scope.duplicateRecord = function()
        {
            // routine to duplicate the current record into a new window
            var row = $scope.editRow;
            $scope.cancelRecord();

            // validate the form on edit
            $timeout(function ()
            {
                // now create the new row
                $scope.insertRecord();
                $scope.editRow.jsonData = row.jsonData;
                $scope.editRow.templateList = row.templateList;
                $scope.editRow.isDuplicate = true;
            }, 500);


        };

        $scope.deleteRecord = function()
        {
            // routine to be called when the user chooses to delete a record
            var record = lodash.find(_this.model.data, {rowId: $scope.editRow.rowId});
            if (record)
            {
                record.recordStatus = uiSvc.editModes.DELETE;
                adminDataSvc.saveTemplateGroup(record).then(function(result) {
                    var record = lodash.find(_this.model.data, {rowId: $scope.editRow.rowId});
                    if (record)
                    {
                        uiSvc.showExtraSmallPopup("System Parameters", "Template Group Delete Successful !", 5000);
                        lodash.remove(_this.model.data, record);
                        adminDataSvc.listFunctions.refreshGrid(_this);
                    }
                }).catch(function(err)
                {
                    $log.error("Unable to Delete Template Group", err);
                });
            }
        };

        //</editor-fold>

        //<editor-fold desc="Grid Setup">
        _this.functions.gridSetup = function()
        {
            _this.model.grid = {};
            _this.model.grid.dataOptions = {
                sortable: true,
                groupable: false,
                filterable: true,
                columnMenu: true,
                resizable: false,
                pageable: {
                    pageSizes: true
                },
                selectable: "row",
                dataSource:
                {
                    data: [],
                    pageSize: 10,
                    sort:
                        [

                            {field:	"code", dir:"asc"}
                        ],
                    schema:
                    {
                        model:
                        {
                            id: "rowId",
                            uid:"rowId"
                        }
                    }
                },
                columns: [
                    {field: "rowId", type: "string", tooltip: false,hidden: true},
                    {field: "code", title: "Code", type: "string", tooltip: false},
                    {field: "description", title: "Description", type: "string", tooltip: false},
                    {
                        field: "items",
                        title: "Details",
                        filterable: false,
                        template: function(dataItem)
                        {
                            var icons = {"0":"envelope", "1":"bell", "2":"check-square-o", "3":"stack-overflow"};
                            if (dataItem.jsonData && dataItem.jsonData.templates)
                            {

                                var html = "<ul class='list-inline'>";

                                lodash.forEach(dataItem.jsonData.templates, function (template)
                                {
                                    var icon = icons[template];
                                    if (icon == null)
                                        return;
                                   html += "<li><i class='fa fa-" + icon + "'></i></li>";
                                });
                                html += "</ul>";
                                return html;
                            }
                            else
                                return "";
                        }
                    }
                ],
                dataBound: function(e)
                {
                    var grid = this;
                    uiSvc.dataBoundKendoGrid(grid);
                }
            };
        };

        //</editor-fold>
        initialize();
    }]);
});