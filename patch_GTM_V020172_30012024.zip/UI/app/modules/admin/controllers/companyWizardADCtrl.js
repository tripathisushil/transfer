/*
 /// <summary>
 /// app.modules.admin.controllers - companyWizardADCtrl.js
 /// Controller to manage Company Wizard - Active Directory Information
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Created By Mohammed Helly
 /// Date: 02/02/2017
 /// Reworked for Stablility By: Mac Bhyat
 /// Date: 12/02/2017
 /// </summary>
 */
define(['modules/admin/module', 'lodash', 'bootstrap-validator'], function (module, lodash) {

	"use strict";

	module.registerController('companyWizardADCtrl', ['$scope', '$timeout', '$element', 'uiSvc','adminDataSvc', 'cacheDataSvc', function ($scope, $timeout, divElement,  uiSvc, adminDataSvc, cacheDataSvc) {

        let _this = this;
        _this.functions = {};

        //<editor-fold desc="Wizard Functions">

        _this.functions.field_validation = function(isError)
        {
            // custom validation processing - nothing to do here as bootstrapvalidator will handle everything
        };

        _this.functions.form_validation = function()
        {
            // reset the hidden field and call it again
            $scope.vm.state.step.validator.revalidateField('hiddenDomains');
            $scope.vm.functions.validateForm();
        };


        _this.functions.updateFunction = function()
        {
            // function to run when in non-new company mode and we want to update the database directly
            let model = {validation_type: parseInt($scope.vm.validation.type), validation_details: {domains: $scope.vm.model.domains}};
            adminDataSvc.saveCompanyValidation($scope.vm.model.company.id, model).then(function(result)
            {
                $scope.$parent.vm.state.form.hasChanged = false;
                $scope.vm.model.company.validation_details = result;
                uiSvc.showExtraSmallPopup("Validation Details", "The Active Directory Information has been Updated Successfully !", 5000);

                // re-initialize the form
                $scope.vm.functions.initializeStep(bootValidatorOptions, field_validation, updateFunction, form_validation, null);
                var formElement = $(divElement).first();
                $scope.vm.functions.stepContentLoaded(formElement);

            });
        };

        _this.functions.initializeData = function()
        {
            // routine to initialize the data based on the main record
            if (!$scope.vm.model.company.validation_details)
                $scope.vm.model.company.validation_details = {};
            if (!$scope.vm.model.company.validation_details.domains)
                $scope.vm.model.company.validation_details.domains = [];
            $scope.vm.model.domains =  $scope.vm.model.company.validation_details.domains;
            $scope.updateDisplay();
        }
        //</editor-fold>



        // initialize the variables
        $scope.formErrorMessage = null;
        $scope.adGridOptions = {
            sortable: true,
            groupable: false,
            filterable: true,
            resizable: true,
            selectable: "row",
            noRecords: true,
            pageable: {
                pageSizes: true
            },
            dataSource:
                {
                    data: [],
                    pageSize: 10,
                    schema:
                        {
                            model:
                                {
                                    id: "domain",
                                    uid:"domain",
                                    fields:
                                        {
                                            domain: {type:"string"},
                                            connection: {type:"string"}
                                        }
                                }
                        }
                },

            columns: [
                {
                    field: "domain",
                    title: "Domain",
                    width: "200px"
                },
                {
                    field: 'connection',
                    title: 'LDAP Connection',
                    template: function(dataItem)
                    {
                        return "LDAP://" + dataItem.host + "/" + dataItem.nameString;
                    }

                }
            ],
            dataBound: function(e)
            {
                var grid = this;

                uiSvc.dataBoundKendoGrid(grid, $scope.editRecord);
            }

        };

        let bootValidatorOptions = {
            fields: {
                hiddenDomains: {
                    excluded: false,
                    validators: {
                        callback: {
                            message: " ",
                            callback: function (value, validator, $field)
                            {
                                var valid = $scope.vm.model.domains != null && $scope.vm.model.domains.length > 0;
                                if (valid)
                                    $scope.formErrorMessage = null;
                                else
                                    $scope.formErrorMessage = "At least One Domain is Required for a Company using Active Directory Validation";
                                return valid;
                            }
                        }
                    }
                }
            }
        };

        $scope.vm.functions.initializeStep(bootValidatorOptions, _this.functions.field_validation, _this.functions.updateFunction, _this.functions.form_validation, null);

        //<editor-fold desc="Edit Form  Setup">
        $scope.updateDisplay = function ()
        {
            // routine to update the grid display
            $scope.vm.showEdit = false;
            $scope.adGrid.dataSource.data($scope.vm.model.domains);
        };

        $scope.vm.showEdit = false;

        $scope.editRecord = function(row)
        {
            // routine to edit the row
            $scope.newRecord = false;
            $scope.editRow = lodash.find($scope.vm.model.domains, {domain: row.domain});
            $scope.vm.showEdit = true;
        };

        $scope.insertRecord = function()
        {
            // routine to add a new row
            $scope.newRecord = true;
            $scope.editRow = {searchString: cacheDataSvc.getParameter("DefaultADSearchString")[0].value};
            $scope.vm.showEdit = true;
        };

        $scope.cancelRecord = function()
        {
            $scope.vm.showEdit = false;
        };

        $scope.saveRecord = function()
        {
            // save the record
            if ($scope.newRecord)
                $scope.vm.model.domains.push($scope.editRow);
            $scope.newRecord = false;
            $scope.updateDisplay();
        };

        $scope.deleteRecord = function()
        {
            // remove the record from the list
            var index = lodash.findIndex($scope.vm.model.domains, {domain: $scope.editRow.domain});
            if (index > -1)
                $scope.vm.model.domains.splice(index, 1);
            $scope.updateDisplay();
        };


        //</editor-fold>

        $scope.$on('$viewContentLoaded', function()
        {

            // when the DOM has loaded initialize BV
           $timeout(function()
           {
                var formElement = $(divElement).first();
                $scope.vm.functions.stepContentLoaded(formElement);
                _this.functions.initializeData();
           }, 500);
        });

        $scope.$on("kendoWidgetCreated", function(event, widget)
        {

            // when the widget gets created set the data or watch the data variable for changes
            if ($scope.adGrid === widget)
            {
                if ($scope.vm.model.domains)
                    $scope.updateDisplay();
            }
        });




    }]);
});
