/*
 /// <summary>
 /// app.modules.admin.controllers - companyWizardBasicCtrl.js
 /// Controller to manage Company Wizard - Basic Information
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Created By Mohammed Helly
 /// Date: 02/02/2017
 /// Reworked for Stablility By: Mac Bhyat
 /// Date: 10/02/2017
 /// </summary>
 */
define(['modules/admin/module', 'lodash', 'bootstrap-validator'], function (module, lodash) {

	"use strict";

	module.registerController('companyWizardBasicCtrl', ['$scope', '$timeout', '$log', '$element','cacheDataSvc', 'adminDataSvc','uiSvc', function ($scope, $timeout, $log, divElement, cacheDataSvc, adminDataSvc, uiSvc) {

        let _this = this;
        _this.functions = {};
        _this.model = {};

        _this.functions.initializeValidator = function ()
        {
            let bootValidatorOptions = {
                fields: {
                    companyName: {
                        excluded: false,
                        validators: {
                            notEmpty: {
                                message: 'The Company Name cannot be empty'
                            },
                            callback: {
                                message: 'This Company Is already exists',
                                callback: function (value, validator, $field) {
                                    var companies = cacheDataSvc.getCompanies();
                                    var found = lodash.find(companies, function(company)
                                    {
                                        return (company.name == value && company.id != $scope.vm.model.company.id);
                                    });
                                    if (found) {
                                        return false;
                                    }
                                    return true;
                                }
                            }
                        }
                    },
                    companyPhone: {
                        excluded: false,
                        group: '.col-sm-6',
                        validators: {
                            notEmpty: {
                                message: 'The Company Phone cannot be empty'
                            },
                            phone: {
                                country: 'US',
                                message: 'Please provide a Valid Phone Number '
                            }
                        }
                    },
                    companyEmail: {
                        excluded: false,
                        group: '.col-sm-6',
                        validators: {
                            notEmpty: {
                                message: 'The Email Address cannot be empty'
                            },
                            emailAddress: {
                                message: 'Invalid Email Address'
                            }
                        }
                    },
                    companyUrl: {
                        excluded: true,
                        validators: {
                            uri: {
                                message: 'The URL is invalid'
                            }
                        }
                    },
                    hiddenDept: {
                        excluded: false,
                        validators: {
                            callback: {
                                message: 'A Company needs to have at least 1 department',
                                callback: function (value, validator, $field)
                                {
                                    var valid = $scope.vm.model.departmentNames != null && $scope.vm.model.departmentNames.length > 0;
                                    $scope.deptError = valid ? 1 : 99;
                                    return valid;
                                }
                            }
                        }
                    }
                }
            };

            let field_validation = function(isError)
            {
                // custom validation processing - nothing to do here as bootstrapvalidator will handle everything
            };
            let updateFunction = function()
            {
                // function to run when in non-new company mode and we want to update the database directly
                let model = {basic: {id: $scope.vm.model.company.id, name: $scope.vm.model.company.name, info: $scope.vm.model.company.info}, departmentNames: $scope.vm.model.departmentNames, validation_type: parseInt($scope.vm.validation.type), isDefault: $scope.vm.model.isDefault};
                adminDataSvc.saveCompanyBasic(model).then(function(result)
                {
                    $scope.vm.model.company.name = result.basic.name;
                    $scope.vm.model.company.info = result.basic.info;
                    $scope.vm.model.departmentNames = result.departmentNames;
                    $scope.vm.model.validation_type = result.validation_type;
                    $scope.vm.model.isDefault = result.isDefault;

                    uiSvc.showExtraSmallPopup("Basic Information", "The Basic Information has been Updated Successfully !", 5000);

                    // re-initialize the screen
                    $scope.vm.functions.initializeStep(bootValidatorOptions, field_validation, updateFunction, null, null);
                    let formElement = $(divElement).first();
                    $scope.vm.functions.stepContentLoaded(formElement);

                }).catch(function (err)
                {
                    $log.error("Unable to Update Basic Information", err);
                });
            };
            $scope.vm.functions.initializeStep(bootValidatorOptions, field_validation, updateFunction, null, null);


        }

	    // setup the form
        _this.functions.initialize = function()
        {
            // routine to initialize the screen
            $scope.deptError = 0;

            _this.functions.initializeValidator();


            $scope.checkDepts = function()
            {
                // routine to update the value of the hidden field
                $scope.vm.state.step.validator.revalidateField('hiddenDept');
            };

            $scope.$on('$viewContentLoaded', function()
            {
                // when the DOM has loaded initialize BV
                $timeout(function()
                {
                    let formElement = $(divElement).first();
                    $scope.vm.functions.stepContentLoaded(formElement);
                    _this.functions.initializeValidation();
                }, 500);
            });
        }

        _this.functions.initializeValidation = function()
        {
            // routine to initialize validation
            $scope.vm.validation = {};
            $scope.vm.validation.options = [
                {code: "0", description: "Standard Validation"},
                {code: "1", description: "Active Directory Validation"},
                {code: "2", description: "Microsoft Entra Validation"},
            ]
            $scope.vm.validation.type = $scope.vm.model.company.validation_type.toString();
        }

        // initialize the screen
        _this.functions.initialize();



    }]);
});
