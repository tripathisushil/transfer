/*
 /// <summary>
 /// app.modules.admin.controllers - companyWizardUserEditDialogCtrl
 /// Company Wizard - User Edit Dialog Controller
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 06/07/2020
 /// </summary>
 */
define(['modules/admin/module'], function (module) {

    "use strict";

	module.registerController('companyWizardUserEditDialogCtrl', ['$uibModalInstance', '$scope', 'userSvc', 'uiSvc',  'dialogData', function ($uibModalInstance, $scope, userSvc, uiSvc, dialogData)
    {

        // initialize the object
        var _this = this;
        _this.functions = {};
        _this.model = {};

        //<editor-fold desc="Functions">

        _this.functions.init = function()
        {
            // routine to prepare the view for display
            _this.model = dialogData;
            _this.model.title = "Add User";
            _this.model.buttonText = "Add";
            if (_this.model.record.recordStatus != uiSvc.editModes.INSERT)
            {
                _this.model.title = "Edit User";
                _this.model.buttonText = "Save";
            }
            var profile = userSvc.getProfile();
            _this.model.flags.allowDelete = (_this.model.record.userId != null && (_this.model.record.userId !=  profile.login && _this.model.record.companyId != profile.companyId));
            _this.validation = {};
        };


        _this.functions.userDelete = function()
        {
            // routine to confirm deletion of of the row
            var html = "<i class='fa fa-trash-o' style='color:red'></i>    Delete  <span style='color:white'>" + _this.model.record.userId + "</span> ?";
            uiSvc.showSmartAdminBox(html, "Are you sure you want to delete this User  ? ", '[No][Yes]', _this.functions.confirmDelete)

        };

        _this.functions.confirmDelete = function (ButtonPressed) {
            // routine to handle the delete request from the user
            if (ButtonPressed == "Yes")
            {
                _this.model.record.recordStatus = uiSvc.editModes.DELETE;
                $uibModalInstance.close(_this.model.record);
            }
        };
        _this.functions.saveRecord = function()
        {

            // routine to save the entry
            _this.validation.validator.revalidateField("hiddenDept");
            _this.validation.validator.revalidateField("hiddenRole");
            _this.validation.validator.validate();
            var valid = _this.validation.validator.isValid();
            if (!valid)
                return;
            // close the window
            $uibModalInstance.close(_this.model.record);
        };

        _this.functions.cancelRecord = function()
        {
            // close the window
            $uibModalInstance.dismiss('cancel');
        };
        //</editor-fold>

        _this.functions.init();





    }]);
});
