/*
 /// <summary>
 /// app.modules.admin.controllers - companyWizardRoleCtrl.js
 /// Controller to manage Company Wizard - Role Information
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Created By Mohammed Helly
 /// Date: 02/02/2017
 /// Reworked for Stablility By: Mac Bhyat
 /// Date: 10/02/2017
 /// </summary>
 */
define(['modules/admin/module', 'lodash', 'bootstrap-validator'], function (module, lodash) {

	"use strict";

	module.registerController('companyWizardRoleCtrl', ['$scope', '$timeout', '$element',  '$log', 'uiSvc','adminDataSvc', 'cacheDataSvc', function ($scope, $timeout, divElement,  $log, uiSvc, adminDataSvc, cacheDataSvc) {

	    // setup the form
        let _this = this;
        _this.functions = {};

        //<editor-fold desc="Wizard Overrides">
        let bootValidatorOptions = {
            fields: {
                hiddenRoles: {
                    excluded: false,
                    validators: {
                        callback: {
                            message: " ",
                            callback: function (value, validator, $field)
                            {
                                var valid = $scope.vm.model.roles != null && $scope.vm.model.roles.length > 0;
                                if (valid)
                                    $scope.formErrorMessage = null;
                                else
                                    $scope.formErrorMessage = "At least 1 Role is Required for a Company";
                                return valid;
                            }
                        }
                    }
                }
            }
        };

        _this.functions.field_validation = function(isError)
        {
            // custom validation processing - nothing to do here as bootstrapvalidator will handle everything
        };

        _this.functions.form_validation = function()
        {
            // reset the hidden field and call it again
            $scope.vm.state.step.validator.revalidateField('hiddenRoles');
            $scope.vm.functions.validateForm();
        };


        _this.functions.updateFunction = function()
        {
            // function to run when in non-new company mode and we want to update the database directly
            adminDataSvc.saveRoles($scope.vm.model.company.id, $scope.vm.model.roles).then(function(result)
            {
                $scope.vm.model.roles = result;
                uiSvc.showExtraSmallPopup("Role Update", "The Role(s) been Updated Successfully !", 5000);
                $scope.$parent.vm.state.form.hasChanged = false;

                cacheDataSvc.initializeLists(true).then(function(result)
                {

                }).catch(function(err)
                {
                    $log.error("Unable to Update Cache List", err);
                });

                // re-initialize the screen
                $scope.vm.functions.initializeStep(bootValidatorOptions, field_validation, updateFunction, form_validation, null);
                var formElement = $(divElement).first();
                $scope.vm.functions.stepContentLoaded(formElement);

            }).catch(function (err) {
                $log.error("Unable to Update Roles", err);
            });

        };
        //</editor-fold>

        //<editor-fold desc="Other Functions">
        _this.functions.parseRoles = function()
        {
            // routine to parse the roles for viewing when anything changes in the view
            $scope.vm.showEdit = false;
            let active = lodash.filter($scope.vm.model.roles, function (role)
            {
                return (role.recordStatus != 99);
            });
            $scope.roleGrid.dataSource.data(active);
        }

        _this.functions.initializeButtonOption = function() {
            // routine to initialize the button option
            $scope.vmForm = {};
            $scope.vmForm.flags = {};
            $scope.vmForm.functions = {};

            $scope.vmForm.flags.allowAdd = true;
            $scope.vmForm.flags.allowSync = false;
            $scope.vmForm.flags.inProgress = false;

            // based on the validation type enable the buttons
            switch (parseInt($scope.vm.validation.type))
            {
                case 2:
                    $scope.vmForm.flags.allowSync = true;
                    $scope.vmForm.flags.allowAdd = false;
                    break;
            }

            $scope.vmForm.functions = {};
            $scope.vmForm.functions.performSync = _this.functions.performSync;
        }
        _this.functions.initialize = function () {
            // initialize scope functions
            $scope.editRecord = function(row)
            {
                // routine to edit the row
                $scope.editRow = lodash.find($scope.vm.model.roles, {code: row.code});
                $scope.vm.showEdit = true;
            };

            $scope.newRecord = function()
            {
                // routine to add a new row
                $scope.editRow = {id: "new_" + $scope.vm.model.roles.length + 1, items:[], companyId: $scope.vm.model.company.id};
                $scope.vm.showEdit = true;
            };

            $scope.cancelRecord = function()
            {
                $scope.vm.showEdit = false;
            };

            $scope.saveRecord = function()
            {
                // save the record
                if ($scope.editRow.recordStatus == null || $scope.editRow.recordStatus == undefined)
                {
                    $scope.editRow.recordStatus = 1; // new record
                    $scope.editRow.type = "Role";
                    $scope.vm.model.roles.push($scope.editRow);
                }
                _this.functions.parseRoles();
            };

            $scope.deleteRecord = function()
            {
                // remove the record from the list
                if (!$scope.editRow.recordStatus == 1)
                {
                    // new record delete it from the roles
                    var index = lodash.findIndex($scope.vm.model.roles, {id: $scope.editRow.id});
                    if (index > -1)
                        $scope.vm.model.roles.splice(index, 1);
                }
                else
                    $scope.editRow.recordStatus = 99;   // delete on server
                _this.functions.parseRoles();
            };

            // initialize scope variables
            $scope.vm.showEdit = false;
            $scope.features = cacheDataSvc.getListForType("0", "Feature");
            $scope.formErrorMessage = null;
            $scope.roleGridOptions = {
                sortable: true,
                groupable: false,
                filterable: true,
                resizable: true,
                selectable: "row",
                noRecords: true,
                pageable: {
                    pageSizes: true
                },
                dataSource:
                    {
                        data: [],
                        pageSize: 10,
                        schema:
                            {
                                model:
                                    {
                                        id: "id",
                                        uid:"id",
                                        fields:
                                            {
                                                id: {type:"string"},
                                                description: {type:"string"},
                                                items: {type:"object"}
                                            }
                                    }
                            }
                    },

                columns: [
                    {
                        field: "id",
                        title: "Id",
                        hidden: true
                    },
                    {
                        field: 'description',
                        title: 'Description'
                    },
                    {
                        field: "items",
                        title: "Permissions",
                        filterable: false,
                        template: function(dataItem)
                        {
                            if (dataItem.additional && dataItem.additional != "")
                            {
                                var html = "";
                                lodash.forEach(dataItem.additional.split('|'), function(item)
                                {
                                    var record = lodash.find($scope.features, {code: item});
                                    if (record != null)
                                        html += '<ul class="list-inline"><li>' + record.description + '</li></ul>';
                                });
                                return html;
                            }
                            else
                                return "";
                        }
                    }
                ],
                dataBound: function(e)
                {
                    var grid = this;

                    uiSvc.dataBoundKendoGrid(grid, $scope.editRecord);
                }

            };


            // initialize the wizard
            $scope.vm.functions.initializeStep(bootValidatorOptions, _this.functions.field_validation, _this.functions.updateFunction, _this.functions.form_validation, null);
        }

        _this.functions.performSync = function()
        {
            let html = "<i class='fa fa-refresh txt-color-green'></i>&nbsp;Perform Sync of Roles </span>";
            uiSvc.showSmartAdminBox(html, "Are you sure you wish to Sync the Roles with Validation Option?",'[No][Yes]', _this.functions.confirmSync);
        }

        _this.functions.confirmSync = function(ButtonPressed)
        {

            // routine to sync the company roles with validation option
            if (!ButtonPressed || ButtonPressed !== "Yes")
                return;
            let model =
            {
                validation_type: parseInt($scope.vm.validation.type),
                validation_details: $scope.vm.model.company.validation_details
            };

            $scope.vmForm.flags.inProgress = true;
            let id = $scope.vm.state.record.isNew ? 0 :  $scope.vm.model.company.id;
            adminDataSvc.syncCompanyRoles(id, model).then(function(result)
            {
                $scope.vm.model.roles = result;
                _this.functions.parseRoles();
                $scope.$parent.vm.state.form.hasChanged = false;
                uiSvc.showExtraSmallPopup("Role Update", "The Role(s) been Synced Successfully !", 5000);

            }).catch(function (err)
            {
                $log.error("Unable to Sync Roles", err);
            }).finally(function(){
                $scope.vmForm.flags.inProgress = false;

            });

        }
        //</editor-fold>

        $scope.$on('$viewContentLoaded', function()
        {

            // when the DOM has loaded initialize BV
           $timeout(function()
           {
                let formElement = $(divElement).first();
                $scope.vm.functions.stepContentLoaded(formElement);
               _this.functions.initializeButtonOption();
           }, 500);
        });

        $scope.$on("kendoWidgetCreated", function(event, widget)
        {

            // when the widget gets created set the data or watch the data variable for changes
            if ($scope.roleGrid === widget)
            {
                if ($scope.vm.model)
                    _this.functions.parseRoles();
            }
        });

        _this.functions.initialize();

    }]);
});
