/*
 /// <summary>
 /// modules.admin.directives - mqaAdmCompanyUserList.js
 /// Administration Module Directive to List Company Users in a Kendo Grid
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 10/02/2017
 /// </summary>
 */

define(['modules/admin/module', 'lodash','bootstrap-validator'], function(module, lodash) {
  "use strict";

  module.registerDirective('mqaAdmCompanyUserList', ['$timeout','uiSvc', 'jqueryuiSvc', function($timeout, uiSvc, jqueryuiSvc)
  {
    return {
        restrict: 'E',
        templateUrl: "app/modules/admin/directives/mqaAdmCompanyUserList.tpl.html",
        replace: true,
        scope:
        {
            title:'@',
            data:'=',
            gridOptions:'=',
            selections: '=?',
            refreshFlag:'=?'
        },
        link: function($scope, form, attrs)
        {
            // setup the grid options
            if (!$scope.data)
                $scope.data = [];

            $scope.$on("kendoWidgetCreated", function(event, widget)
            {

                // when the widget gets created set the data or watch the data variable for changes
                if ($scope.userGrid === widget)
                {
                    $scope.updateData();
                }
            });

            $scope.updateData = function()
            {
                // routine to update the data
                $scope.userGrid.dataSource.data($scope.data);
            };

            $scope.$watchCollection("data", function(newValue, oldValue)
            {
                 // update the grid the moment the data changes - no need for observable array
                 if (newValue != oldValue || !$scope.watched)
                 {
                    $scope.watched = true;
                    if ($scope.userGrid)
                        $scope.updateData();
                }
            });
            if ($scope.refreshFlag) {
                $scope.$watch('refreshFlag', function () {
                    if ($scope.userGrid)
                        $scope.updateData();
                }, true);
            }
        }
    }
  }]);

});


