/*
 /// <summary>
 /// modules.admin.directives - mqaAdmWmqConnEdit.js
 /// Administration Module Directive to Manage Websphere MQ Connection Information
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mohammed Helly
 /// Date: 02/13/2017
 /// </summary>
 */
define(['modules/admin/module', 'lodash','bootstrap-validator'], function(module, lodash) {
    "use strict";

    module.registerDirective('mqaAdmWmqConnEdit', ['$log', 'jqueryuiSvc', function($log, jqueryuiSvc){

        return {
            restrict: 'EA',
            scope:
                {
                    model: '=',
                    watchFlag: '=',
                    validation:'=',
                    onValidation:'&?'
                },

            replace: true,
            templateUrl: "app/modules/admin/directives/mqaAdmWmqConnEdit.tpl.html",
            link: function($scope, form, attrs)
            {

                // setup the grid options
                $scope.gridDataOptions = {
                    sortable: true,
                    groupable: false,
                    filterable: true,
                    columnMenu: true,
                    resizable: false,
                    pageable: {
                        pageSizes: true
                    },
                    selectable: "row",
                    dataSource:
                        {
                            data: [],
                            pageSize: 10,
                            sort:
                                [

                                    {field:	"hostName", dir:"asc"}
                                ],
                            schema:
                                {
                                    model:
                                        {
                                            id: "id",
                                            uid:"id",
                                            fields:
                                                {
                                                    id: {type:"string"},
                                                    hostName:{type:"string", from:"hostName"},
                                                    port:{type:"number", from:"port"}
                                                }
                                        }
                                }
                        },
                    columns: [
                        {
                            field: "id",
                            title:"Id",
                            hidden: true
                        },
                        {
                            field:"hostName",
                            title:"Host",
                        },
                        {
                            field:"port",
                            title:"Port"
                        }
                    ]
                };



                // setup the defaults
                if ($scope.model.bindingType == null || $scope.model.bindingType == undefined)
                {
                    $scope.model.bindingType = 0;
                    $scope.model.hosts = [];
                    $scope.model.channel = "MQA.SVRCONN";
                };

                // setup the bootstrap validator fields
                var serverNameTxt = { fields:{queueManager: {
                    excluded:false,
                    group:"#div_queueManager",
                    validators: {
                        notEmpty: {
                            message: 'The Queue Manager Name cannot be empty'
                        }
                    }
                } }};
                var hostNameTxt = {fields: {hiddenHosts: {
                    excluded: false,
                    group:"#div_hiddenHosts",
                    validators: {
                        callback: {
                            message: "At least One Host is Required for a Client Connection",
                            callback: function (value, validator, $field)
                            {
                                var valid = $scope.model.hosts != null && $scope.model.hosts.length > 0;
                                return valid;
                            }
                        }
                    }
                }}};

                var channelNameTxt = { fields:{channel: {
                    excluded:false,
                    group:"#div_channel",
                    validators: {
                        notEmpty: {
                            message: 'The Channel Name cannot be empty'
                        }
                    }
                } }};

                // setup bootstrap validator
                var fields = lodash.merge(serverNameTxt, channelNameTxt, hostNameTxt);

                var formOptions = lodash.merge({} ,  jqueryuiSvc.getFormValidateOptions(), fields);
                var fv = form.bootstrapValidator(formOptions).on('error.field.bv', function (e)
                {
                    if ($scope.onValidation)
                    {
                        // call the validation function
                        $scope.onValidation()(false);
                    }
                }).on("success.field.bv", function (e, data)
                {
                    if ($scope.onValidation)
                    {
                        // call the validation function
                        $scope.onValidation()(true);
                    }
                });
                $scope.validation = form.data('bootstrapValidator');

                // setup the validator watch
                $scope.$watch("watchFlag", function(newValue, oldValue)
                {
                    switch ($scope.watchFlag.value) {
                        case 1:
                            // validate the form
                            $scope.validation.validate();
                            break;
                        case 2:
                            // revalidate the form
                            $scope.validation.resetForm();
                            $scope.validation.validate();
                            break;
                        default:
                    }
                });

                $scope.onBindingChange = function()
                {
                    // routine to add or remove the host field from the validation if the binding is client
                    $scope.validation.enableFieldValidators("hiddenHosts", $scope.model.bindingType == 0);
                    $scope.validation.enableFieldValidators("channel", $scope.model.bindingType == 0);
                };

                //<editor-fold desc="Edit Form  Setup">
                $scope.showEdit = false;
                $scope.editRecord = function(row)
                {
                    // routine to edit the row
                    $scope.editRow = angular.copy(row);
                    var index = lodash.findIndex($scope.model.hosts, {hostName: row.hostName});
                    $scope.editRow.id =  index;
                    $scope.editRow.recordStatus = "Update";
                    $scope.showEdit = true;
                };

                $scope.newRecord = function()
                {
                    // routine to add a new row
                    $scope.editRow = {id: "new_" + ($scope.model.hosts.length + 1)};
                    if ($scope.model.hosts.length == 0)
                        $scope.editRow.port = 1414;
                    $scope.editRow.recordStatus ="New";
                    $scope.showEdit = true;
                };

                $scope.cancelRecord = function()
                {
                    $scope.showEdit = false;
                };

                $scope.saveRecord = function()
                {
                    // save the record
                    if ($scope.editRow.recordStatus == "New")
                        $scope.model.hosts.push($scope.editRow);
                    else
                    {
                        // remove the old record and add the new one
                        var record = $scope.model.hosts[$scope.editRow.id];
                        if (record)
                        {
                            lodash.remove($scope.model.hosts, record);
                            $scope.model.hosts.push($scope.editRow);
                        }
                    }
                    $scope.showEdit = false;
                     $scope.validation.revalidateField("hiddenHosts");
                };

                $scope.deleteRecord = function()
                {
                    // remove the record from the list
                    var entry = $scope.model.hosts[$scope.editRow.id];
                    lodash.remove($scope.model.hosts, entry);
                    $scope.showEdit = false;
                    $scope.validation.revalidateField("hiddenHosts");
                };
                //</editor-fold>
                $scope.onBindingChange();

            }
        }
    }]);

});

