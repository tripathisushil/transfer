/*
 /// <summary>
 /// modules.admin.directives - mqaAdmEnvironmentEdit.js
 /// Administration Module Directive to Manage Customer Environment Information
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mohammed Helly
 /// Date: 02/17/2017
 /// </summary>
 */
define(['../module', 'lodash','bootstrap-validator'], function(module, lodash) {
    "use strict";

    module.registerDirective('mqaAdmEnvironmentEdit', ['$log','jqueryuiSvc', function($log, jqueryuiSvc){

        return {
            restrict: 'EA',
            scope: {
                model: '=',
                watchFlag: '=',
                validation:'=',
                onValidation:'&?'
            },

            replace: true,
            templateUrl: "app/modules/admin/directives/mqaAdmEnvironmentEdit.tpl.html",
            link: function($scope, form, attrs)
            {

                // setup the validation
                var companyNameTxt = { fields:{companyName: {
                    excluded:false,
                    group:"#div_companyName",
                    validators: {
                        notEmpty: {
                            message: 'The Company Name cannot be empty'
                        }
                    }
                }}};
                var envNameTxt = { fields:{envName: {
                    excluded:false,
                    group:"#div_envName",
                    validators: {
                        notEmpty: {
                            message: 'The Environment cannot be empty'
                        }
                    }
                } }};
                var contactNameTxt = { fields:{contactName: {
                    excluded:false,
                    group:"#div_contactName",
                    validators: {
                        notEmpty: {
                            message: 'The Contact Name cannot be empty'
                        }
                    }
                }}};
                var contactEmailTxt ={fields:{contactEmail: {
                    excluded:false,
                    group:"#div_contactEmail",
                    validators: {
                        notEmpty: {
                            message: 'The Email Address cannot be empty'
                        },
                        emailAddress: {
                            message: 'Invalid Email Address'
                        }
                    }
                }}};


                // setup bootstrap validator
                var fields = lodash.merge(envNameTxt,companyNameTxt,contactNameTxt,contactEmailTxt);
                var formOptions = lodash.merge({} ,  jqueryuiSvc.getFormValidateOptions(), fields);
                var fv = form.bootstrapValidator(formOptions).on('error.field.bv', function (e)
                {
                    if ($scope.onValidation)
                    {
                        // call the validation function
                        $scope.onValidation()(false);
                    }
                }).on("success.field.bv", function (e, data)
                {
                    if ($scope.onValidation)
                    {
                        // call the validation function
                        $scope.onValidation()(true);
                    }
                });
                $scope.validation = form.data('bootstrapValidator');

                // setup the validator watch
                $scope.$watch("watchFlag", function(newValue, oldValue)
                {
                    switch ($scope.watchFlag.value) {
                        case 1:
                            // validate the form
                            $scope.validation.validate();
                            break;
                        case 2:
                            // revalidate the form
                            $scope.validation.resetForm();
                            $scope.validation.validate();
                            break;
                        default:
                    }
                });
            }
        }
    }]);

});

