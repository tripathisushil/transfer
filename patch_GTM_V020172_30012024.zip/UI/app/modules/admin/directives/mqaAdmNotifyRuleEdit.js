/*
 /// <summary>
 /// modules.admin.directives - mqaAdmNotifyRuleEdit.js
 /// Administration Module Directive to Manage Notification Rule Events Edit
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 03/07/2017
 /// </summary>
 */

define(['modules/admin/module', 'lodash','bootstrap-validator'], function(module, lodash) {
  "use strict";

  module.registerDirective('mqaAdmNotifyRuleEdit', ['$timeout','$log','adminDataSvc','uiSvc', 'jqueryuiSvc', function($timeout, $log, adminDataSvc, uiSvc, jqueryuiSvc)
  {
    return {
        restrict: 'E',
        templateUrl: "app/modules/admin/directives/mqaAdmNotifyRuleEdit.tpl.html",
        replace: true,
        scope:{
            data:'=',
            validation:'=',
            companyId:'@',
            onEdit:'&?'
        },
        link: function ($scope, form, attrs)
        {
            $scope.vm = {model:{flags:{}, grid:{}, lists:{notificationGroups:[], templateGroups:[]}}};
            var vm = $scope.vm;

            // set the record
            if ($scope.data)
                vm.model.record = $scope.data;

            var mainFormSetup = function ()
            {
                // setup the bv for the main form
                var innerForm = $($(form).find("[name='frmNotifyRuleEdit']")[0]);
                // routine to setup the queue editor form
                var fields = {
                    fields: {
                        hiddenValidation: {
                            excluded: false,
                            feedbackIcons:false,
                            validators: {
                                callback: {
                                    message: 'A Notification Rule requires at least one Event Configured',
                                    callback: function (value, validator, $field)
                                    {
                                        var event = lodash.find(vm.model.record.jsonData.events, function(event)
                                        {
                                            return (event.notifyGroups.length > 0 && event.templateGroup != null)
                                        });
                                        return (event != null);
                                    }
                                }
                            }
                        }
                    }
                };
                var formOptions = lodash.merge({}, jqueryuiSvc.getFormValidateOptions(), fields);
                var fv = innerForm.bootstrapValidator(formOptions);
                $scope.validation = innerForm.data('bootstrapValidator');

                // validate the form on edit
                if (vm.model.record.recordStatus == uiSvc.editModes.UPDATE)
                {
                    $timeout(function ()
                    {
                       $scope.validation.validate();

                    }, 500);
                }
            };

            var editFormSetup = function ()
            {
                // setup the bv for the main form
                var innerForm = $($(form).find("[name='frmEventEdit']")[0]);
                // routine to setup the queue editor form
                var fields = {
                    fields: {
                        hiddenValidationInner: {
                            excluded: false,
                            validators: {
                                callback: {
                                    message: 'An Event must have at least 1 Notification Group',
                                    callback: function (value, validator, $field)
                                    {
                                        return vm.model.editRow.notifyGroups.length > 0;
                                    }
                                }
                            }
                        },
                        template_select: {
                            group: "#div_template",
                            excluded: false,
                            validators: {
                                notEmpty: {
                                    message: 'Template Group Must be Selected'
                                }
                            }
                        }

                    }
                };
                var formOptions = lodash.merge({}, jqueryuiSvc.getFormValidateOptions(), fields);
                var fv = innerForm.bootstrapValidator(formOptions);
                $scope.vm.bvEdit = innerForm.data('bootstrapValidator');
            };


            var initialize = function()
            {
                // routine to initialize the form
                vm.model.flags.gridRefresh = {value:0};
                vm.model.grid.dataOptions = {
                    sortable: true,
                    groupable: false,
                    filterable: false,
                    columnMenu: false,
                    resizable: false,
                    pageable: {
                        pageSizes: true
                    },
                    selectable: "row",

                    dataSource: {
                        data: [],
                        pageSize: 10,
                        schema: {
                            model: {
                                id: "eventCode",
                                uid: "eventCode",
                                fields: {
                                    type: {type: "string"}
                                }
                            }
                        }
                    },
                    columns: [
                        {
                            field: "eventCode",
                            title: "Event"
                        },
                        {
                            field: "description",
                            title: "Description"
                        },
                        {
                            field: "apply",
                            title: " ",
                            width:"100px",
                            template: function(dataItem)
                            {
                                var entry = lodash.find(vm.model.record.jsonData.events, {eventCode: dataItem.eventCode});
                                if (entry != null && entry.notifyGroups.length > 0)
                                    return "<ul class='list-unstyled'><li class='text-success'><i class='fa fa-bell fa-lg'/></li></ul>";
                                return "";
                            }
                        }
                    ]
                };

                // setup bootstrap validator
                mainFormSetup();
                editFormSetup();

                // get the lists
                adminDataSvc.readCustomerLists({companyId: $scope.companyId, type:"NotifyGroup"}).then(function(result)
                {
                    vm.model.lists.notificationGroups = result;
                    vm.model.lists.notificationGroups.push({
                        code: "sys-inline",
                        description: "In-Line Recipients",
                        companyId: $scope.companyId,
                        recordStatus: uiSvc.editModes.DUMMY,
                        id: 0
                    });
                }).catch(function(err)
                {
                    $log.error("Unable to retrieve Notification Groups");
                });
                adminDataSvc.readCustomerLists({companyId: $scope.companyId, type:"TemplateGroup"}).then(function(result)
                {
                    vm.model.lists.templateGroups = result;
                }).catch(function(err)
                {
                    $log.error("Unable to retrieve Template Groups");
                });

            };

            //<editor-fold desc="Event Editing Functions">
            var invokeOnEdit = function()
            {
                // routine to invoke the caller's onEdit Function
                if ($scope.onEdit)
                {
                    $scope.onEdit()(vm.model.flags.showEdit);
                }
            };

            var confirmDeleteEvent = function()
            {
                // routine to clear the current event
                var entry = lodash.find(vm.model.record.jsonData.events, {eventCode: vm.model.editRow.eventCode});
                if (entry != null)
                {
                    entry.notifyGroups = [];
                    entry.templateGroup = null;
                }
                vm.model.flags.gridRefresh.value += 1;
                $scope.cancelEvent();
            };

            $scope.deleteEvent = function () {
                // routine to confirm clearing of content
                var html = "<i class='fa fa-trash-o' style='color:red'></i>    Clear ?";
                uiSvc.showSmartAdminBox(html, "Are you sure you want to Clear this Event ? ", '[No][Yes]', confirmDeleteEvent);
            };

            $scope.editEvent = function(item)
            {
                // routine to manage the editing of an event
                var entry = lodash.find(vm.model.record.jsonData.events, {eventCode: item.eventCode});
                vm.model.editRow = angular.copy(entry);
                vm.model.flags.allowEventClear = (vm.model.editRow.notifyGroups.length > 0 || (vm.model.editRow.templateGroup != null));
                vm.model.flags.showEdit = true;

                // either reset the form or validate if
                invokeOnEdit();

                // update the form
                $timeout(function ()
                {
                    $scope.vm.bvEdit.resetForm();
                    if (vm.model.flags.allowEventClear)
                        $scope.vm.bvEdit.validate();
                }, 500);
            };

            $scope.saveEvent = function()
            {
                // routine to initiate the save of the event
                $scope.vm.bvEdit.validate();
                var valid = $scope.vm.bvEdit.isValid();
                if (!valid)
                    return;
                var entry = lodash.find(vm.model.record.jsonData.events, {eventCode: vm.model.editRow.eventCode});
                if (entry)
                {
                    entry.notifyGroups = vm.model.editRow.notifyGroups;
                    entry.templateGroup = vm.model.editRow.templateGroup;
                }
                // close the event edit
                $scope.validation.revalidateField("hiddenValidation");
                vm.model.flags.gridRefresh.value += 1;
                $scope.cancelEvent();
            };

            $scope.cancelEvent = function()
            {
                // routine to abort the editing of the template record
                vm.model.flags.showEdit = false;
                invokeOnEdit();
            };

            $scope.onNotifyChange = function()
            {
                $scope.vm.bvEdit.revalidateField("hiddenValidationInner");
            };


            //</editor-fold>

            // initialize the directive
            initialize();
        }
    }
  }]);

});


