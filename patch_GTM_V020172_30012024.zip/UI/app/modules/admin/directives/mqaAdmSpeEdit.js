/*
 /// <summary>
 /// modules.admin.directives - mqaAdmSpeEdit.js
 /// Administration Module Directive to Manage SPE Connection Details
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 30/05/2017
 /// </summary>
 */
define(['modules/admin/module', 'lodash','bootstrap-validator'], function(module, lodash) {
    "use strict";

    module.registerDirective('mqaAdmSpeEdit', ['$log', 'jqueryuiSvc', function($log, jqueryuiSvc){

        return {
            restrict: 'EA',
            scope:
            {
                    model: '=',
                    watchFlag: '=',
                    validation:'=',
                    onValidation:'&?'
            },
            replace: true,
            templateUrl: "app/modules/admin/directives/mqaAdmSpeEdit.tpl.html",
            link: function($scope, form, attrs)
            {
                // setup the bootstrap validator fields
                var urlTxt = { fields:{url: {
                    excluded:false,
                    group:"#div_url",
                    validators: {
                        notEmpty: {
                            message: 'The Server URL cannot be empty'
                        }
                    }
                } }};
                var userTxt = {
                    fields: {
                        userName: {
                            excluded: false,
                            group: "#div_user",
                            validators: {
                                notEmpty: {
                                    message: 'The User cannot be empty'
                                }
                            }
                        }
                    }
                };
                var passwordTxt = {
                    fields: {
                        userPassword: {
                            group: "#div_password",
                            excluded: false,
                            validators: {
                                notEmpty: {
                                    message: 'The Password cannot be empty'
                                }
                            }
                        }
                    }
                };

                var senderIDTxt = {
                    fields: {
                        senderID: {
                            excluded: false,
                            group: "#div_senderID",
                            validators: {
                                notEmpty: {
                                    message: 'The Template Sender ID cannot be empty'
                                }
                            }
                        }
                    }
                };
                var fields = lodash.merge(urlTxt,userTxt,passwordTxt,senderIDTxt);

                // setup bootstrap validator
                var formOptions = lodash.merge({} , jqueryuiSvc.getFormValidateOptions(), fields);
                var fv = form.bootstrapValidator(formOptions).on('error.field.bv', function (e)
                {
                    if ($scope.onValidation)
                    {
                        // call the validation function
                        $scope.onValidation()(false);
                    }
                }).on("success.field.bv", function (e, data)
                {
                    if ($scope.onValidation)
                    {
                        // call the validation function
                        $scope.onValidation()(true);
                    }
                });
                $scope.validation = form.data('bootstrapValidator');

                // setup the validator watch
                $scope.$watch("watchFlag", function(newValue, oldValue)
                {
                    switch ($scope.watchFlag.value) {
                        case 1:
                            // validate the form
                            $scope.validation.validate();
                            break;
                        case 2:
                            // revalidate the form
                            $scope.validation.resetForm();
                            $scope.validation.validate();
                            break;
                        default:
                    }
                });

                var formOptions = lodash.merge({} ,  fields);
                var fv = form.bootstrapValidator(formOptions);
            }
        }
    }]);

});

