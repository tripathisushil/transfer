/*
 /// <summary>
 /// modules.admin.directives - mqaAdmArchiveEdit.js
 /// Administration Module Directive to Manage Archive Settings
 /// @Deprecated - V02.01.49
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mohammed Helly
 /// Date: 02/17/2017
 /// </summary>
 */
define(['modules/admin/module', 'lodash','bootstrap-validator'], function(module, lodash) {
    "use strict";

    module.registerDirective('mqaAdmArchiveEdit', ['$filter','jqueryuiSvc', function($filter ,jqueryuiSvc){

        return {
            restrict: 'EA',
            scope: {
                model: '=',
                watchFlag: '=',
                validation:'=',
                onValidation:'&?'
            },
            replace: true,
            templateUrl: "app/modules/admin/directives/mqaAdmArchiveEdit.tpl.html",
            link: function($scope, form, attrs)
            {
                //<editor-fold desc="Setup Form Validation">
                var selector = {
                    fields: {
                        typeSelect: {
                            excluded: false,
                            group: "#div_type",
                            validators: {
                                notEmpty: {
                                    message: 'The Database Type cannot be empty'
                                }
                            }
                       }
                    }
                };

                var archiveDaysTxt = {
                    fields: {
                        archiveDays: {
                            excluded: false,
                            group: "#div_archiveDays",
                            validators: {
                                notEmpty: {
                                    message: 'The No. of Days Before Archiving cannot be empty'
                                },
                                integer: {
                                    message: 'The No. of Days Before Archiving should be a numeric'
                                }
                            }
                        }
                    }
                };
                var deleteDaysTxt = {
                    fields: {
                        deleteDays: {
                            excluded: false,
                            group: "#div_deleteDays",
                            validators: {
                                notEmpty: {
                                    message: 'The No. of Days Before Deleting cannot be empty'
                                },
                                numeric: {
                                    message: 'The No. of Days Before Deleting should be numeric'
                                }
                            }
                        }
                    }
                };
                var forceDeleteDaysTxt = {
                    fields: {
                        forceDeleteDays: {
                            excluded: false,
                            group: "#div_forceDeleteDays",
                            validators: {
                                notEmpty: {
                                    message: 'The No. of Days Before Force Deleting cannot be empty'
                                }
                                ,
                                numeric: {
                                    message: 'The No. of Days Before Force Deleting should be numeric'
                                }
                            }
                        }
                    }
                };
                var hostTxt = {
                    fields: {
                        host: {
                            excluded: false,
                            group: "#div_host",
                            validators: {
                                notEmpty: {
                                    message: 'The Host cannot be empty'
                                }
                            }
                        }
                    }
                };
                var dbTxt = {
                    fields: {
                        dbName: {
                            excluded: false,
                            group: "#div_dbName",
                            validators: {
                                notEmpty: {
                                    message: 'The Database Name cannot be empty'
                                }
                            }
                        }
                    }
                };
                var loginTxt = {
                    fields: {
                        userName: {
                            excluded: false,
                            group: "#div_userName",
                            validators: {
                                notEmpty: {
                                    message: 'The Login cannot be empty'
                                }
                            }
                        }
                    }
                };
                var passwordTxt = {
                    fields: {
                        userPassword: {
                            excluded: false,
                            group: "#div_userPassword",
                            validators: {
                                notEmpty: {
                                    message: 'The Login Password cannot be empty'
                                }
                            }
                        }
                    }
                };
                var initialized = false;

                // setup bootstrap validator
                var fields = lodash.merge(selector, hostTxt,dbTxt,loginTxt,passwordTxt, archiveDaysTxt, deleteDaysTxt, forceDeleteDaysTxt);
                var formOptions = lodash.merge({} , jqueryuiSvc.getFormValidateOptions(), fields);
                var fv = form.bootstrapValidator(formOptions).on('error.field.bv', function (e)
                {
                    if ($scope.onValidation)
                    {
                        // call the validation function
                        $scope.onValidation()(false);
                    }
                }).on("success.field.bv", function (e, data)
                {
                    if ($scope.onValidation)
                    {
                        // call the validation function
                        $scope.onValidation()(true);
                    }
                });
                $scope.validation = form.data('bootstrapValidator');

                // setup the validator watch
                $scope.$watch("watchFlag", function(newValue, oldValue)
                {
                    switch ($scope.watchFlag.value) {
                        case 1:
                            // validate the form
                            $scope.validation.validate();
                            break;
                        case 2:
                            // revalidate the form
                            $scope.validation.resetForm();
                            $scope.validation.validate();
                            break;
                        default:
                    }
                });

                $scope.onAuthChange = function()
                {
                    // routine to add or remove the user and password from the validation if the connection type is SQL
                    $scope.validation.enableFieldValidators("userName", $scope.model.connectionType == "0");
                    $scope.validation.enableFieldValidators("userPassword", $scope.model.connectionType == "0");
                };
                $scope.onDatabaseTypeChange = function()
                {
                    // routine to enable or disable the OS Level Selection based on the dbType
                    var type = parseInt($scope.model.dbType);
                    var isdB2 = (type == 2);
                    $scope.model.connectionSettings.type = type;
                    $scope.disableRadio = isdB2; //
                    if (isdB2) // db2
                    {
                        $scope.model.connectionType = "0";
                        $scope.onAuthChange();
                    }
                };
                $scope.setAuth = function()
                {
                    // update to update the connection type based on the initial user
                    $scope.model.connectionType = "0"; //
                    if ($scope.model.connectionSettings.user == null || $scope.model.connectionSettings.user == '')

                        $scope.model.connectionType = "1";
                };
                $scope.initialize = function()
                {
                    // routine to initialize the form when the model changes
                    if (!$scope.model.connectionSettings)
                        return;

                    initialized = true;
                    $scope.model.dbType = $scope.model.connectionSettings.type.toString();

                    $scope.setAuth();
                    $scope.onAuthChange();
                    $scope.onDatabaseTypeChange();
                };

                // setup the model watch
                $scope.$watch("model", function(newValue, oldValue)
                {
                    if (newValue != oldValue && !initialized)
                        $scope.initialize();
                });
                $scope.initialize();
            }
        }
    }]);

});


