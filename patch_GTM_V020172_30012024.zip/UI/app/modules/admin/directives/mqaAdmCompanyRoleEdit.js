/*
 /// <summary>
 /// modules.admin.directives - mqaAdmDocTypeEditForm.js
 /// Administration Module Directive to Manage Roles Capture
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 10/02/2017
 /// </summary>
 */

define(['modules/admin/module', 'lodash','bootstrap-validator'], function(module, lodash) {
  "use strict";

  module.registerDirective('mqaAdmCompanyRoleEdit', ['$timeout','uiSvc', 'jqueryuiSvc', function($timeout, uiSvc, jqueryuiSvc)
  {
    return {
        restrict: 'E',
        templateUrl: "app/modules/admin/directives/mqaAdmCompanyRoleEdit.tpl.html",
        replace: true,
        link: function ($scope, form, attrs) {
            // setup the bootstrap validator
            var fields = {
                fields: {
                    code: {
                        excluded: false,
                        validators: {
                            notEmpty: {
                                message: 'Role Code is Required'
                            },
                            regexp:
                                {
                                    regexp:"^[a-zA-Z0-9_-]{4,}$",
                                    message:"Role must contain no spaces or special characters and must be a minimum of 4"
                                },
                            callback: {
                                message: 'Role Code already exists',
                                callback: function (value, validator, $field) {
                                    var found = lodash.find($scope.vm.model.roles, function (role) {
                                        return (role.code === value && role.recordStatus != 99 && role.id != $scope.editRow.id);
                                    });
                                    if (found) {
                                        return false;
                                    }
                                    return true;
                                }
                            }
                        }
                    },
                    description: {
                        excluded: false,
                        validators: {
                            notEmpty: {
                                message: 'Role Name is Required'
                            },
                        }
                    },
                    hiddenFeatures: {
                        excluded: false,
                        validators: {
                            callback: {
                                message: 'A Role requires at least 1 Feature',
                                callback: function (value, validator, $field) {
                                    var valid = $scope.foundFeatures.length > 0;
                                    $scope.featureError = valid ? 1 : 99;
                                    return valid;
                                }
                            }
                        }
                    }
                }
            };
            var formOptions = lodash.merge({}, {submitButtons: 'button[id="submit"]'}, jqueryuiSvc.getFormValidateOptions(), fields);
            var fv = form.bootstrapValidator(formOptions).on('error.field.bv', function (e) {
                $scope.bv.disableSubmitButtons(false);
            }).on("success.field.bv", function (e, data) {
                $scope.bv.disableSubmitButtons(false);
            });
            $scope.bv = form.data('bootstrapValidator');

            $scope.featureGridOptions = {
                sortable: false,
                groupable: false,
                filterable: false,
                dataSource: {
                    data: [],
                    schema: {
                        model: {
                            id: "code",
                            uid: "code",
                            fields: {
                                code: {type: "string"},
                                description: {type: "string"},
                                additional: {type: "string"}
                            }
                        }
                    }
                },

                columns: [
                    {
                        field: "select",
                        title: "Select",
                        width: "80px",
                        template: function (dataItem) {
                            return '<input type="checkbox" name="rolesCheckbox[]" ng-model="selectedFeatures[\'' + dataItem.code + '\']">';
                        }
                    },
                    {
                        field: "code",
                        title: "Code",
                        hidden: true
                    },
                    {
                        field: 'description',
                        title: 'Description'
                    },
                    {
                        field: "additional",
                        title: 'Notes',
                        hidden: true
                    }
                ]
            };

            var confirmDelete = function (ButtonPressed) {
                // routine to handle the delete request from the user
                if (ButtonPressed == "Yes") {
                    $scope.deleteRecord();
                }
            };

            $scope.buttonText = "Create";
            $scope.headingText = "Add Role";
            $scope.allowCode = true;
            if ($scope.editRow.recordStatus != null) {
                $scope.buttonText = "Save";
                $scope.headingText = "Edit Role";
            }
            if ($scope.editRow.recordStatus != null && $scope.editRow.recordStatus === 0)
                $scope.allowCode = false;

            // get the selected features
            $scope.selectedFeatures = {};
            if ($scope.editRow.additional && !$scope.editRow.additional != null) {
                lodash.forEach($scope.editRow.additional.split('|'), function (item) {
                    $scope.selectedFeatures[item] = true;
                });
            }

            $scope.selectFeatures = function () {
                // routine to update the found features when the feature selection changes
                $scope.foundFeatures = [];
                lodash.forOwn(lodash.pickBy($scope.selectedFeatures), function (value, key) {
                    $scope.foundFeatures.push(key);
                });
            };

            $scope.saveChanges = function () {
                $scope.selectFeatures();
                $scope.bv.revalidateField('hiddenFeatures');
                $scope.bv.validate();
                var valid = $scope.bv.isValid();
                if (!valid) {
                    $timeout(function () {
                        $scope.bv.disableSubmitButtons(false);
                    }, 500);
                    return;
                }
                // work out the additional
                $scope.editRow.additional = $scope.foundFeatures.join('|');

                // now save the record
                $scope.saveRecord();
            };


            $scope.userDelete = function () {
                // routine to confirm deletion of of the row
                var html = "<i class='fa fa-trash-o' style='color:red'></i>    Delete Role <span style='color:white'>" + $scope.editRow.description + "</span> ?";
                uiSvc.showSmartAdminBox(html, "Are you sure you want to delete this Role ? ", '[No][Yes]', confirmDelete)
            };

            $scope.$on("kendoWidgetCreated", function (event, widget) {

                // when the widget gets created set the data or watch the data variable for changes
                if ($scope.featureGrid === widget) {
                    $scope.featureGrid.dataSource.data($scope.features);
                    $scope.addNoteTooltip("td:nth-child(3)", $scope.featureGrid, "additional", "top");
                }
            });
            $scope.addNoteTooltip = function(filterName, grid, fieldName, position)
            {
                // routine to add a tooltip for the given field
                if (fieldName == null)
                    fieldName = filterName;
                var element = $(grid.wrapper);
                element.kendoTooltip({
                    filter: filterName,
                    position: position ? position : "left",
                    beforeShow: function (e)
                    {
                        var dataItem = grid.dataItem(e.target.closest("tr"));
                        if (!dataItem[fieldName] || dataItem[fieldName] == '')
                            e.preventDefault();
                    },
                    content: function(e)
                    {
                        var dataItem = grid.dataItem(e.target.closest("tr"));
                        var content = dataItem[fieldName];
                        return content;
                    }
                }).data("kendoTooltip");
            };

        }
    }
  }]);

});


