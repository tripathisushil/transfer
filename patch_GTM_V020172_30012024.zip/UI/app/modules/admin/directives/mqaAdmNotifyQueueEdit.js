/*
 /// <summary>
 /// modules.admin.directives - mqaAdmNotifyQueueEdit.js
 /// Administration Module Directive to Manage Queue Details Capture on a Notification Group
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 30/06/2017
 /// </summary>
 */

define(['modules/admin/module', 'lodash', 'bootstrap-validator'], function (module, lodash) {
    "use strict";

    module.registerDirective('mqaAdmNotifyQueueEdit', ['$timeout', 'uiSvc', 'jqueryuiSvc', function ($timeout, uiSvc, jqueryuiSvc) {
        return {
            restrict: 'E',
            templateUrl: "app/modules/admin/directives/mqaAdmNotifyQueueEdit.tpl.html",
            replace: true,
            link: function ($scope, form, attrs) {
                var editFormSetup = function () {
                    // routine to setup the queue editor form
                    var fields = {
                        fields: {
                            queueName: {
                                excluded: false,
                                group: "#div_queueName",
                                validators: {
                                    notEmpty: {
                                        message: 'Queue is Required'
                                    },
                                    callback: {
                                        message: 'Queue Name @ Queue Manager Combination Already Exists',
                                        callback: function (value, validator, $field) {
                                            var found = lodash.find($scope.editRow.jsonData.queues, function (record) {
                                                return (record.queue === value && record.id != $scope.queueEditRow.id && record.queueManager == $scope.queueEditRow.queueManager);
                                            });
                                            if (found) {
                                                return false;
                                            }
                                            return true;
                                        }
                                    }
                                }
                            },
                            queueManager: {
                                excluded: false,
                                group: "#div_queueManager",
                                validators: {
                                    notEmpty: {
                                        message: 'Queue Manager is Required'
                                    },
                                    callback: {
                                        message: 'Queue Name @ Queue Manager Combination Already Exists',
                                        callback: function (value, validator, $field) {
                                            var found = lodash.find($scope.editRow.jsonData.queues, function (record) {
                                                return (record.queueManager === value && record.id != $scope.queueEditRow.id && record.queue == $scope.queueEditRow.queue);
                                            });
                                            if (found) {
                                                return false;
                                            }
                                            return true;
                                        }
                                    }

                                }
                            }
                        }
                    };
                    var formOptions = lodash.merge({}, jqueryuiSvc.getFormValidateOptions(), fields);
                    var fv = form.bootstrapValidator(formOptions);
                    $scope.bvQueueEdit = form.data('bootstrapValidator');
                };

                var initialize = function () {
                    // routine to initialize the form
                    editFormSetup();
                    $scope.queueButtonText = "Create";
                    if (!$scope.queueEditRow.isNew)
                    {
                        $scope.queueButtonText = "Save";

                        // validate the form on edit
                        $timeout(function () {
                            $scope.bvQueueEdit.validate();

                        }, 500);
                    }
                };


                var confirmDelete = function (ButtonPressed) {
                    // routine to handle the delete request from the user
                    if (ButtonPressed == "Yes")
                        $scope.deleteQueueRecord();
                };

                $scope.saveQueueRecord = function () {
                    // validate the form
                    $scope.bvQueueEdit.validate();
                    var valid = $scope.bvQueueEdit.isValid();
                    if (!valid)
                        return;

                    // now save the record
                    $scope.postQueueRecord();
                };


                $scope.userDeleteQueueRecord = function () {
                    // routine to confirm deletion of of the row
                    var name = $scope.queueEditRow.queue + "@" + $scope.queueEditRow.queueManager;
                    var html = "<i class='fa fa-trash-o' style='color:red'></i>    Delete Queue <span style='color:white'>" + name + "</span> ?";
                    uiSvc.showSmartAdminBox(html, "Are you sure you want to delete this Queue Notification ? ", '[No][Yes]', confirmDelete)
                };

                // initialize the directive
                initialize();
            }
        }
    }]);

});


