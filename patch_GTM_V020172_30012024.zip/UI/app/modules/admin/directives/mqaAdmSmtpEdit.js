/*
 /// <summary>
 /// modules.admin.directives - mqaAdmSmtpEdit.js
 /// Administration Module Directive to Manage SMTP Details
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mohammed Helly
 /// Date: 02/13/2017
 /// </summary>
 */
define(['modules/admin/module', 'lodash','bootstrap-validator'], function(module, lodash) {
    "use strict";

    module.registerDirective('mqaAdmSmtpEdit', ['$log', 'jqueryuiSvc', function($log, jqueryuiSvc){

        return {
            restrict: 'EA',
            scope:
            {
                model: '=',
                watchFlag: '=',
                validation:'=',
                onValidation:'&?'
            },

            replace: true,
            templateUrl: "app/modules/admin/directives/mqaAdmSmtpEdit.tpl.html",
            link: function($scope, form, attrs)
            {
                // setup the bootstrap validator fields
                var PortTxt = { fields:{port: {
                    excluded:false,
                    group:"#div_port",
                    validators: {
                        notEmpty: {
                            message: 'The port cannot be empty'
                        },
                        numeric: {
                            message: 'The port is not a number'
                        }
                    }
                }}};
                var serverNameTxt = { fields:{serverName: {
                    excluded:false,
                    group:"#div_serverName",
                    validators: {
                        notEmpty: {
                            message: 'The server name cannot be empty'
                        }
                    }
                } }};
                var fromNameTxt = { fields:{fromName: {
                    excluded:false,
                    group:"#div_fromName",
                    validators: {
                        notEmpty: {
                            message: 'The Sender From Name cannot be empty'
                        }
                    }
                } }};
                var fromAddressTxt ={fields:{fromAddress: {
                    excluded:false,
                    group:"#div_fromAddress",
                    validators: {
                        notEmpty: {
                            message: 'The Sender Email Address cannot be empty'
                        },
                        emailAddress: {
                            message: 'Invalid Email Address'
                        }
                    }
                }}};
                var userTxt = { fields:{userName:{
                    group:"#div_user",
                    excluded: false,
                    validators: {
                        notEmpty: {
                            message: 'The Password cannot be empty'
                        }
                    }
                }}};

                var passwordTxt = { fields:{userPassword:{
                    group:"#div_password",
                    excluded: false,
                    validators: {
                        notEmpty: {
                            message: 'The Password cannot be empty'
                        }
                    }
                }}};
                var fields = lodash.merge(serverNameTxt,PortTxt,fromNameTxt,fromAddressTxt, userTxt, passwordTxt);

                // setup bootstrap validator
                var formOptions = lodash.merge({} ,  jqueryuiSvc.getFormValidateOptions(), fields);
                var fv = form.bootstrapValidator(formOptions).on('error.field.bv', function (e)
                {
                    if ($scope.onValidation)
                    {
                        // call the validation function
                        $scope.onValidation()(false);
                    }
                }).on("success.field.bv", function (e, data)
                {
                    if ($scope.onValidation)
                    {
                        // call the validation function
                        $scope.onValidation()(true);
                    }
                });
                $scope.validation = form.data('bootstrapValidator');

                // setup the validator watch
                $scope.$watch("watchFlag", function(newValue, oldValue)
                {
                    switch ($scope.watchFlag.value) {
                        case 1:
                            // validate the form
                            $scope.validation.validate();
                            break;
                        case 2:
                            // revalidate the form
                            $scope.validation.resetForm();
                            $scope.validation.validate();
                            break;
                        default:
                    }
                });


                $scope.onNameChange = function()
                {
                    // routine to add or remove the user & password from the validation if the name is entered or not
                    $scope.validation.enableFieldValidators("userName", $scope.model.userName != null && $scope.model.userName != "");
                    $scope.validation.enableFieldValidators("userPassword", $scope.model.userName != null && $scope.model.userName != "");
                };
                $scope.onNameChange();
            }
        }
    }]);

});

