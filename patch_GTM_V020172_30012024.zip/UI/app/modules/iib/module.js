// noinspection JSAnnotator

/*
 /// <summary>
 /// app.modules.iib - module.js
 /// IIB Module Bootstrapper
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 18/11/2015
 /// </summary>
 */
define([
    'angular',
    'angular-couch-potato',
    'angular-ui-router',
    'angular-resource',
    'modules/common/module',
    'modules/iib/module'
], function (ng, couchPotato) {
    'use strict';

    var module = ng.module('app.mqaiib', ['ui.router','ngResource','app.mqacommon']);
    var stateProvider;
    var couchProvider;


    module.config(function ($stateProvider, $couchPotatoProvider)
    {
        stateProvider = $stateProvider;
        couchProvider = $couchPotatoProvider;
        $stateProvider
            .state('app.iib', {
                abstract: true,
                url: '/iib',
                views: {

                    "nav@app":
                    {
                        controller: 'iibNavigationCtrl',
                        templateUrl: 'app/modules/iib/partials/navigation.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/iib/controllers/iibNavigationCtrl',
                                'modules/iib/services/iibDataSvc',
                                'modules/common/services/chartSvc',
                                'modules/mft/services/mftDataSvc'
                                ])

                        }
                    },
                    "content@app":
                    {
                        templateUrl: 'app/modules/layout/partials/module-header.tpl.html'
                    },
                    "realtime@content":
                    {
                        controller: 'iibRealtimeCtrl',
                        templateUrl: 'app/modules/iib/partials/realtime-header.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/iib/controllers/iibRealtimeCtrl'
                            ])
                        }
                    }
                },
                data:{
                    title: 'Integration Bus', module: 'Integration Bus', security:['iib'], module_id:"iib"

                }})
            .state('app.iib.reporting.transaction',
            {
                abstract: true,
                url: '/transaction',
                views:
                {
                    "innerContent@content":
                    {
                        controller: 'iibTransactionReportingCtrl',
                        templateUrl: 'app/modules/transaction-reporting/partials/transaction-reporting-layout.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/iib/controllers/iibTransactionReportingCtrl'
                            ])

                        }
                    },
                    "filterContent@content":
                    {
                        templateUrl:'app/modules/iib/partials/transaction-reporting-filter.tpl.html'
                    },
                    "footerContent@content":
                    {
                        template:'<div></div>'
                    }
                },
                data:
                {
                    title:'Transaction Reporting'
                }
            })
            .state("app.iib.reporting.transaction.gridview",{
                url: '/gridview',
                views: {
                    "tabContent@content": {
                        controller: 'transactionReportingGridViewCtrl',
                        templateUrl: 'app/modules/transaction-reporting/partials/transaction-reporting-gridview.tpl.html',
                        resolve:  {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/transaction-reporting/controllers/transactionReportingGridViewCtrl'
                            ])
                        }
                    }
                }
            })

    });

    couchPotato.configureApp(module);

    module.run(['$couchPotato', 'transactionReportingSvc',  function($couchPotato, transactionReportingSvc)
    {
        module.lazy = $couchPotato;
        transactionReportingSvc.createDetailRoutes("app.iib", stateProvider, couchProvider);
    }]);
    return module;
});