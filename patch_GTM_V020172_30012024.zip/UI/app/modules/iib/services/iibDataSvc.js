/*
 /// <summary>
 /// app.modules.iib.services - iibDataSvc.js
 /// IIB Module Data Service
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 15/05/2016
 /// </summary>
 */
define(['modules/iib/module', 'lodash', 'appCustomConfig'], function(module, lodash, appCustomConfig)
{
    "use strict";
    module.registerService('iibDataSvc',['$filter','$q','apiSvc', 'apiProvider', 'cacheDataSvc', function($filter, $q, apiSvc, apiProvider, cacheDataSvc)
    {
        var _this = this;

        // setup the webservice calls
        var nodeUrl = appCustomConfig.node;
        if (appCustomConfig.nodePath)
            nodeUrl = appCustomConfig.node + "/" + appCustomConfig.nodePath;
        var configs = [
            {url: '/mft/transaction/detail/iibEventDoc', resourceName:'mftTransDetailIIBDoc'},
            {url: '/mft/transaction/detail/iibEventDoc/find/:transactionId/', resourceName:'mftTransDetailIIBTransDoc'},
            {url :'iib/dashboard/search', 'resourceName': 'iibDashboardSearch', baseUrl: nodeUrl},

        ];
        angular.forEach(configs, function(value){
            apiSvc.add(value);
        });

        _this.updateEventsViewModel = function(events)
        {
            // routine to update the IIB Events with view specific information
            lodash.forEach(events, function (event)
            {

                switch (event.blobFormat) {
                    case "text":
                    case "txt":
                        event.icon = "fa-file-text-o";
                        event.foreground = "txt-color-blue";
                        event.background = "bg-color-blue";
                        break;
                    case "pdf":
                        event.icon = "fa-file-pdf-o";
                        event.foreground = "txt-color-red";
                        event.background = "bg-color-red";
                        break;
                    case "jpeg":
                        event.icon = "fa-file-image-o";
                        event.foreground = "txt-color-orange";
                        event.background = "bg-color-orange";
                        break;
                    case "xml":
                        event.icon = "fa-file-code-o";
                        event.foreground = "txt-color-blueDark";
                        event.background = "bg-color-blueDark";
                        break;
                    default:
                        event.icon = "fa-file";
                        event.foreground = "txt-color-muted";
                        event.background = "bg-color-muted";
                        break;
                }
            });
        };

        _this.refreshDashboard = function(filterObject)
        {
            // routine to request iib reporting for the given filter object
            return apiProvider.getObject('iibDashboardSearch', filterObject);
        };


        _this.parseKendoGridData = function(rows)
        {
            // routine to massage the data for grid use
            var statusList = cacheDataSvc.getListForType("0", "FTEStatus");
            lodash.forEach(rows, function(item)
            {
                var value = $filter("localUTCStringFilter")(item.time);
                item.CompleteDate = $filter("kendoDateFilter")(value);
                item.Status = cacheDataSvc.getListDescriptionFromArray(statusList, item.StatusCode);
                if (item.IsError)
                {
                    item.rowStyle = "transactionError";
                }
            });
            return rows;
        };


    }]);
});
