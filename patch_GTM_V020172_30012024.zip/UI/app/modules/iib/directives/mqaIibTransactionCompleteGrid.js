/*
 /// <summary>
 /// modules.iib.directives - mqaIibTransactionCompleteGrid
 /// IIB Module Directive to List Transactions available for Viewing
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 08/05/2018
 /// </summary>
 */

define(['modules/iib/module', 'lodash','bootstrap-validator'], function(module, lodash) {
  "use strict";

  module.registerDirective('mqaIibTransactionCompleteGrid', ['$timeout','$filter','$log', '$state','transactionReportingSvc', function($timeout, $filter, $log, $state, transactionReportingSvc)
  {
    return {
        restrict: 'E',
        templateUrl: "app/modules/iib/directives/mqaDynamicTableDashboardList.tpl.html",
        replace: true,
        bindToController:{
            gridOptions:'=',
            data:'=',
            watchFlag:'='

        },
        controllerAs:'vm',
        controller: function($element, $scope)
        {
            var _this = this;
            _this.watched = false;
            _this.functions = {};
            _this.model = {gridOptions:{}, flags:{}};
            if (_this.gridOptions != null)
                _this.model.gridOptions = _this.gridOptions;
            else {
                _this.model.gridOptions = {
                    resizable: false,
                    selectable: "row",
                    noRecords: true,
                    messages: {
                        noRecords: "No Records Available or Document Type Not Selected"
                    },
                    dataSource: {
                        pageSize: 10,
                        sort: [
                            {field: "CompleteDate", dir: "desc"}
                        ],
                        schema: {
                            model: {
                                TransactionId: {type: "string"},
                                CompleteDate: {type: "date"},
                                BrokerHost: {type: "string"},
                                BrokerName: {type: "string"},
                                DepartmentId: {type: "number"},
                                ErrorCount: {type: "number"},
                                ExecutionGroup: {type: "string"},
                                FlowName: {type: "string"},
                                JobId: {type: "string"},
                                JobName: {type: "string"},
                                NodeName: {type: "string"},
                                Supplemental: {type: "string"},
                                RunTime: "number",
                                CompanyId: {type: "number"},
                                StatusCode: {type: "number"},
                                TransactionCount: {type: "number"}

                            }
                        },
                        aggregate: [
                            {field: "TransactionCount", aggregate: "sum"},
                            {field: "RunTime", aggregate: "sum"},
                            {field: "ErrorCount", aggregate: "sum"}]

                    },
                    columns: [
                        {
                            field: "JobName",
                            title: "Job Name",
                            width: "220px",
                            filterable: {
                                cell: {
                                    showOperators: false,
                                    operator: "contains",
                                    inputWidth: 200
                                }
                            }
                        },
                        {
                            field: "BrokerName",
                            title: "Broker",
                            filterable: {
                                cell: {
                                    showOperators: false,
                                    operator: "contains",
                                    inputWidth: 160
                                }
                            }
                        },
                        {
                            field: "ExecutionGroup",
                            title: "ExecutionGroup",
                            filterable: {
                                cell: {
                                    showOperators: false,
                                    operator: "contains",
                                    inputWidth: 160
                                }
                            }

                        },
                        {
                            field: "FlowName",
                            title: "Flow",
                            filterable: {
                                cell: {
                                    showOperators: false,
                                    operator: "contains",
                                    inputWidth: 160
                                }
                            }

                        },
                        {
                            field: "NodeName",
                            title: "Node",
                            filterable: {
                                cell: {
                                    showOperators: false,
                                    operator: "contains",
                                    inputWidth: 160
                                }
                            }

                        },
                        {
                            field: "CompleteDate",
                            title: "Completed",
                            format: "{0:yyyy-MM-dd HH:mm:ss.fff}",
                            width: "200px",
                            filterable: {
                                cell: {
                                    inputWidth: 180
                                }
                            }

                        },
                        {
                            field: "RunTime",
                            title: "Running Time (seconds)",
                            aggregates: ["sum"],
                            filterable: false,
                            attributes: {style: "text-align:right;"},
                            headerAttributes: {style: "text-align:right;"},
                            footerTemplate: function (dataItem) {
                                var value;
                                if (dataItem.RunTime)
                                    value = dataItem.RunTime.sum;
                                else
                                    value = dataItem.sum;
                                if (value == null)
                                    return null;
                                return "<div class=\"truncate\" style=\"text-align:right\">" + $filter("secondsToStringFilter")(value.toFixed(3));
                            }
                        }

                    ]
                };
            }

            _this.functions.drill  = function(record)
            {
                // routine to invoke the transaction drill
                var baseState = $state.$current.parent;
                transactionReportingSvc.navigateTransaction(baseState.name + ".reporting.transactionDetail.jobview", {transactionId: record.TransactionId, transactionType: 1});
            };
            _this.model.flags.gridRefresh = _this.watchFlag;
            _this.model.data = _this.data;

            $scope.$watchCollection("vm.data", function(newValue, oldValue)
            {
                // update the grid the moment the data changes - no need for observable array
                if (newValue != oldValue || !_this.watched)
                {
                    _this.watched = true;
                    _this.model.data = _this.data;
                }
            });
       }
    }
  }]);

});

