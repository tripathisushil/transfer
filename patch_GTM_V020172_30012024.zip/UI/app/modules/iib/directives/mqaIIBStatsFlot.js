/*
 /*
 /// <summary>
 /// modules.iib.directives - mqaIIBStatsFlot.js
 /// Directive to display the IIB Stats for a given Metric and Given data using Flot
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 18/11/2015
 /// </summary>
 */
define(['modules/iib/module', 'lodash'], function(module, lodash) {
  "use strict";

  module.registerDirective('mqaIIBStatsFlot', ['$filter', function($filter){
    return {
        restrict: 'EA',
        scope:
        {
            metric:'@',
            stateObject:'=',
            exclusions:'='
        },
        template: '<mqa-flot-line dataset="seriesData" options="options" class="col-lg-12 col-sm-12 col-md-6 flot" callback="callback" />',


        link: function($scope, element, attrs)
        {
            $scope.seriesData = [];
            var removePoints = function()
            {
                // routine to remove the points from all series in the data
                lodash.forEach($scope.seriesData, function(series)
                {
                   if (series.data)
                      series.data.shift();
                });
            }
            var redraw = function()
            {
                // routine to redraw the chart based on the stateObject

                // check if I need to clear the data (due to a switch from real-time to non-realtime or vice versa)
                if ($scope.stateObject.clearData)
                    $scope.seriesData = [];
                else
                    removePoints();


                // map the data
                lodash.map($scope.stateObject.data, function(record) {
                    var value = lodash.get(record, $scope.metric);


                    if (value)
                    {
                        // check if the interface name is in the list
                        var series = lodash.find($scope.seriesData, {label: record.jobName});
                        if (!series)
                            series = $scope.seriesData.push({data : [], label: record.jobName});
                        series.data.push([record.transDate, value]);
                    }
                });

                // setup the watches
                $scope.$watch('stateObject', function(newValue, oldValue)
                {
                    if (oldValue != newValue)
                        redraw();
                });

                $scope.watchCollection("exclusions", function(newValue, oldValue)
                {
                    // hide all series that don't match the exclusions
                    if (newValue == oldValue)
                        return;

                    lodash.forEach($scope.seriesData, function (series)
                    {
                        var excluded = $scope.exclusions.indexOf(series.label);
                        series.line.hide = (excluded > -1);
                    });

                })
            }


        }
    }
  }]);

});


