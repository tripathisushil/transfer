/*
 /// <summary>
 /// app.modules.iib.controllers - iibNavigationCtrl.js
 /// Base IIB Navigation Controller
 /// Abstract Controller that is the parent of all IIB Module Screens - this will manage Signal-R Listeners amongst other things
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 22/05/2016
 /// </summary>
 */
define(['modules/iib/module'], function (module) {

	"use strict";

	module.registerController('iibNavigationCtrl', ['$scope', 'transactionReportingSvc', function ($scope, transactionReportingSvc)	{

	  // update the transaction reporting service
      transactionReportingSvc.reset(0);
	}]);
});
