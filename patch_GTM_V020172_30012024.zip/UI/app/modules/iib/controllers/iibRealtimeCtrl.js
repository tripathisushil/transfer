/*
 /// <summary>
 /// app.modules.iib.controllers - iibRealtimeCtrl.js
 /// Controller to manage realtime statistics for the IIB Module
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 22/05/2016
 /// </summary>
 */
define(['modules/iib/module', 'lodash'], function (module, lodash) {

	"use strict";

	module.registerController('iibRealtimeCtrl', ['$scope', '$timeout','$filter', 'chartSvc', 'socketIOSvc', function ($scope, $timeout, $filter,chartSvc, socketIOSvc) {


        // declare the update functions
        var _this = this;

        var updateHandler = function(data)
        {
            // routine to update the header values
            var metric = lodash.find(data.metrics, {id: "total"});
            if (metric)
            {
                _this.metrics.total.value = $filter("number")(metric.value);
                _this.metrics.total.chartData = lodash.map(metric.history, "value");
            }
            metric = lodash.find(data.metrics, {id: "failures"});
            if (metric)
            {
                _this.metrics.failures.value = $filter("number")(metric.value);
                _this.metrics.failures.chartData = lodash.map(metric.history, "value");
            }
        };


        // setup the chart configuration for sparkline
        _this.chartConfig = {};
        _this.chartConfig.files = chartSvc.sparkLineBase.bar;
        _this.chartConfig.total = chartSvc.sparkLineBase.bar;
        _this.chartConfig.failures = chartSvc.sparkLineBase.bar;


        // setup the metrics array
        _this.metrics = {total: {chartData: {}}, failures: {chartData: {}}};
        _this.metrics.total.value = 0;
        _this.metrics.total.chartData = [];
        _this.metrics.failures.value = 0;
        _this.metrics.failures.chartData = [];

        // setup for socket-io use
        $timeout(function()
        {
            socketIOSvc.addListener("iib.realtime.header", updateHandler);
            socketIOSvc.connectModule("iib", function(data)
            {
                updateHandler(data);
            });
        }, 1000);

    }]);
});
