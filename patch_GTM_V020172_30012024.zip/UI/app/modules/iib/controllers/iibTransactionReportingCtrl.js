/*
 /// <summary>
 /// app.modules.iib.controllers - iibTransactionReportingCtrl.js
 /// Base IIB Transaction Reporting Controller
 /// Abstract Controller that is the parent of all IIB Transaction Reporting Controllers
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 21/05/2016
 /// </summary>
 */
define(['modules/iib/module', 'moment', 'lodash'], function (module, moment, lodash) {

	moment().format();
	"use strict";

	module.registerController('iibTransactionReportingCtrl', ['$scope', '$log', '$state', '$filter','apiSvc', 'apiProvider', 'transactionReportingSvc', 'userSvc', function ($scope, $log, $state, $filter, apiSvc, apiProvider, transactionReportingSvc, userSvc)
	{
		// initialize the tabs
		$scope.tabs = [];
		$scope.tabs.push({title:'Grid View', icon:'fa-table', state: 'app.iib.reporting.transaction.gridview', activate:"**.gridview"});
		$scope.filterName = "iibTransaction";

		// initialize the filter dates
		$scope.dateRange =
		{
			startDate: moment().subtract("days", 1),
			endDate: moment()
		};


		// setup the filter
		$scope.data = [];
		$scope.filter = {topCount: 50};
        $scope.filter.companyId = userSvc.getOrgInfo().companyId;
        $scope.filter.module = 1;
		$scope.filter.jobNames = [];
		$scope.filter.statuses = [];
       	$scope.filter.departments = [];
        $scope.filter.transactionIds = [];
		$scope.filter.iibFilter = {};
		$scope.filter.iibFilter.brokers = [];

		$scope.refreshData = function()
		{
			// routine to formulate the filter object based on the current scope and send the filter object to the server for processing
			var filterObject = {};
			angular.copy($scope.filter, filterObject);
			filterObject.metadata = [];
			filterObject.fromDate = $scope.dateRange.startDate.toISOString();
			filterObject.toDate = $scope.dateRange.endDate.toISOString();
			transactionReportingSvc.refreshData(filterObject, function(result){
				$scope.data = result;
			});
		};

		// initialize the view
		transactionReportingSvc.loadBaseReportingInfo($scope);
	}]);

});
