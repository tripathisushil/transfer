/*
 /// <summary>
 /// app.modules.iib.controllers - iibTransactionDetailCtrl.js
 /// Controller for Transaction Detail - IIB Broker Events Sub Detail
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 6/21/2015
 /// </summary>
 */

define(['modules/iib/module', 'file-saver', 'lodash'], function (module, filesaver) {

	"use strict";

	module.registerController('iibTransactionDetailCtrl', ['$scope', '$log', 'uiSvc', 'apiProvider', function ($scope, $log, uiSvc, apiProvider)
    {

        // initialize the object
        $scope.viewDoc = function(id)
        {
            // work out the type based on the type
            apiProvider.getBlob('mftTransDetailIIBDoc',{id : id}).then(function (response)
            {
                var file = new Blob([response.blob], {type: response.blob.type});
             	if (response.blob.type == "application/octet-stream")
					filesaver(response.blob, response.fileName);
				else
				{
				    uiSvc.openBlob(file);
				}
            }).catch(function (result)
            {
                $log.error("Unable to download IIB Document", result);
            });
        }
    }]);
});
