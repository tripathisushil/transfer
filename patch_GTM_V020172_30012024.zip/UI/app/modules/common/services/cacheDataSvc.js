/*
 /// <summary>
 /// app.modules.common.services - cacheDataSvc.js
 /// Client Implementation of the Server Side Cache Data Service
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 11/26/2014
 /// </summary>
 */
define(['modules/common/module', 'lodash', 'moment', 'appCustomConfig'], function (module, lodash, moment, appCustomConfig) {
    "use strict";

    moment().format();

    module.registerService('cacheDataSvc', ['$templateCache', '$log', '$http', '$q', '$timeout', 'apiSvc', 'apiProvider', 'userSvc', function ($templateCache, $log, $http, $q, $timeout, apiSvc, apiProvider, userSvc) {

        // initialize the api
        var _this = this;
        var configs = [
            {url: 'admin/cache', 'resourceName': 'cacheData'},
            {url: 'admin/settings/env/read', 'resourceName': 'readEnvCache'},
            {url: 'customer/dynamicTable/read', 'resourceName': 'readDynamicTable'}
        ];

        angular.forEach(configs, function (value) {
            apiSvc.add(value);
        });


      // initialize the variables
        _this.product = {};
        _this.dashboardStates = {};
        _this.listTypes = {edi: "EDI_DOCUMENT"};

        var data;
        var modules = [];
        _this.data = {moduleConfig:{}, allowedViewTypes: ["xml", "txt", "json", "edi", "csv"]};


        //<editor-fold desc="Templates">
        _this.loadTemplate = function (template, id) {
            // routine to load a given template and return its html (via promises), if the template is not in the cache it will be added
            var deferred = $q.defer();
            var html = $templateCache.get(id);

            if (angular.isDefined(html)) {
                // The template was cached or a script so return it
                // html = html.trim();
                deferred.resolve(html);
            } else {
                // Retrieve the template if it is a URL
                $http.get(template, {cache: $templateCache}).then(
                    function (response) {
                        var html = response.data;
                        if (!html || !html.length) {
                            // Nothing was found so reject the promise
                            return deferred.reject("Template " + template + " was not found");
                        }
                        //       html = html.trim();
                        // Add it to the template cache using the url as the key
                        if (id)
                            $templateCache.put(id, html);
                        else
                            $templateCache.put(template, html);
                        deferred.resolve(html);
                    }, function () {
                        deferred.reject("Template " + template + " was not found");
                    }
                );
            }
            return deferred.promise;
        };

        _this.setTemplates = function () {
            // routine to load the required directive templates into the cache
            _this.loadTemplate("app/modules/common/directives/ui/mqaWidgetUserSaveDialog.tpl.html", "mqaWidgetUserSaveDialog.tpl.html");
            _this.loadTemplate("app/modules/common/directives/tables/mqaDataTable.tpl.html", "mqaDataTable.tpl.html");
            _this.loadTemplate("app/modules/common/directives/input/uiSelect-mqaTag.tpl.html", "uiSelect-mqaTag.tpl.html");
            _this.loadTemplate("app/modules/common/directives/input/uiSelect-mqaList.tpl.html", "uiSelect-mqaList.tpl.html");
            _this.loadTemplate("app/modules/common/directives/input/uiSelect-mqaCombo.tpl.html", "uiSelect-mqaCombo.tpl.html");
            _this.loadTemplate("app/modules/common/directives/tree/mqaTreeViewNode.tpl.html", "mqaTreeViewNode.tpl.html");
            _this.loadTemplate("app/modules/common/directives/tree/mqaTreeViewSubLinkNode.tpl.html", "mqaTreeViewSubLinkNode.tpl.html");
        };
        //</editor-fold>

        //<editor-fold desc="Parameters">
        _this.getParameter = function (id) {
            // routine to get a given parameter
            var items = lodash.filter(data.parameters, {id: id});
            return items;
        };
        _this.getParameterDescription = function (id) {
            // routine to get a parameter description
            var items = _this.getParameter(id);
            if (items && items.length > 0)
                return items[0].description;
            return "Unknown";
        };
        //</editor-fold>


        //<editor-fold desc="Product and Copyright">
        _this.getProductEnvironment = function () {
            return _this.product.environment;
        };

        _this.getBaseModules = function () {
            // routine to work out the base modules for this environment
            var baseModules = _this.getListForType("0", 'Module');
            var customModules = _this.getListForType("1", "Module", 0);
            lodash.forEach(customModules, function (record) {
                var found = lodash.find(baseModules, {code: record.code});
                if (found == null)
                    baseModules.push(record);
            });
            var returnArr = [];
            modules = [];

            // work out the start route for the module
            lodash.forEach(baseModules, function (dbRecord) {
                // check for an override
                var record = angular.copy(dbRecord);
                var override = _this.getListRecord("1", "Module", record.code, 0);
                if (override != null)
                    record = lodash.merge(record, override);
                var routePrefix = record.additional;
                var security = null;
                if (record.jsonData) {
                    record.startRoute = record.jsonData.ngroute + ".";
                    if (record.jsonData.ngroute_initial)
                        record.startRoute += record.jsonData.ngroute_initial;
                    else
                        record.startRoute += "dashboard";
                    routePrefix = record.jsonData.ngroute;

                    // get the security
                    if (record.jsonData.security)
                        security = record.jsonData.security;

                } else {
                    record.startRoute = record.additional + ".dashboard";
                }
                returnArr.push(record);
                modules.push({
                    id: record.code,
                    description: record.description,
                    routePrefix: routePrefix,
                    security: security
                });
            });
            return returnArr;
        };

        _this.getModuleDesc = function (moduleCode) {
            // routine to return the module description for the given module code
            if (modules.length == 0)
                _this.getBaseModules();

            var module = lodash.find(modules, {id: moduleCode.toString().toLowerCase()});
            if (module != null)
                return module.description;
            else
                return moduleCode;

        };

        //</editor-fold>

        //<editor-fold desc="Lists">

        _this.getEDIListType = function()
        {
            return _this.listTypes.edi;
        };
        _this.getDescriptionProperty = function (record) {
            if (record)
                return record.description;
            else
                return "Unknown";
        };

        // TODO: Take this out after the next HCN Upgrade and CNO Deployment
        _this.changeEDIDocumentFlags = function (record) {
            // routine to change the EDI Document Flags for the given data
            if (!record.jsonData)
                record.jsonData = {data: []};
            if (!record.jsonData.data)
                record.jsonData.data = [];
            var fields = record.jsonData.data;
            lodash.forEach(fields, function (field) {
                if (field.filter && field.filter.show != undefined) {
                    if (typeof (field.filter.show) === 'boolean') {
                        if (field.filter.show)
                            field.filter.show = 1;
                        else
                            field.filter.show = 0;
                    }
                }
            });
        }

        _this.replaceListForType = function (listType, filterType, companyId, newList) {
            // routine to replace a list with a new list
            switch (listType) {
                case "0":
                    lodash.remove(data.oltpLists, {type: filterType});
                    data.oltpLists = lodash.concat(data.oltpLists, lodash.filter(newList, {type: filterType}));
                    break;
                case "1":
                    if (companyId == null || companyId == undefined)
                        companyId = userSvc.getOrgInfo().companyId;
                    lodash.remove(data.companyLists, {companyId: companyId, type: filterType});
                    data.companyLists = lodash.concat(data.companyLists, lodash.filter(newList, {
                        companyId: companyId,
                        type: filterType
                    }));
                    break;
                case "2":
                    lodash.remove(data.olapLists, {type: filterType});
                    data.olapLists = lodash.concat(data.olapLists, lodash.filter(newList, {type: filterType}));
                    break;
            }
        };

        _this.getListForType = function (listType, filterType, companyId) {
            // return all company list types that match the given type
            var listArray = _this.getList(listType, companyId);
            if (listArray != null)
                return lodash.filter(listArray, {type: filterType});
            return null;

        };

        _this.getListRecord = function (listType, filterType, id, companyId) {
            var items = _this.getListForType(listType, filterType, companyId);
            if (items != null) {
                var record = lodash.find(items, {code: id.toString()});
                return record;
            }
            return record;
        };

        _this.getListDescription = function (listType, filterType, id, companyId) {
            var record = _this.getListRecord(listType, filterType, id, companyId);
            return _this.getDescriptionProperty(record);
        };
        _this.getListDescriptionFromArray = function (items, id) {
            if (items != null) {
                var record = lodash.find(items, {code: id.toString()});
                return _this.getDescriptionProperty(record);
            }
        };
        _this.getList = function (type, companyId) {
            // routine to return the list for the given type
            switch (type) {
                case "0":
                    return data.oltpLists;
                    break;
                case "1":
                    if (companyId == null || companyId == undefined)
                        companyId = userSvc.getOrgInfo().companyId;
                    return lodash.filter(data.companyLists, {companyId: companyId});
                    break;
                case "2":
                    return data.olapLists;
                    break;
            }
        };



        _this.initializeLists = function (force) {
            // routine to initialize the lists based on api call to the server
            // this will be called by the ui resolver when the layout appears
            var deferred = $q.defer();
            if (force == undefined)
                force = false;
            if (data != null && !force) {
                $timeout(function () {
                    deferred.resolve(data);
                }, 200);
            }
            return apiProvider.get('cacheData').then(function (result) {

                data = result;

                var parameter = _this.getParameter("CustomerInfo");
                if (parameter != null) {
                    apiProvider.get('readEnvCache').then(function (result) {
                        _this.product.environment = result.environment;
                    });
                }

                // update the document records data
                var docTypes = lodash.filter(result.companyLists, {type: _this.getEDIListType()});
                lodash.forEach(docTypes, function (record) {
                    _this.changeEDIDocumentFlags(record);
                });

                // update the core module config
                let cacheRecord = _this.getListRecord("1", "MODULE", "CORE", 0);
                if (cacheRecord != null)
                {
                    _this.data.moduleConfig = cacheRecord;
                    if (_this.data.moduleConfig.jsonData.settings.mime) {
                        lodash.forOwn(_this.data.moduleConfig.jsonData.settings.mime, function (value, key) {
                            if (!_this.data.allowedViewTypes.includes(key))
                                _this.data.allowedViewTypes.push(key);
                        })
                    }
                }
                deferred.resolve(result);
            }).catch(function (result) {
                deferred.reject(result);
                $log.error("Unable to retrieve cache Data", result);
            });
            return deferred.promise;
        };


        _this.updateCacheList = function (type, record) {
            // now update the current data in the service to reflect this change
            var oldRecord = _this.getListRecord("1", record.type, record.code);
            if (oldRecord)
                lodash.merge(oldRecord, record);
            else {
                var items = _this.getListForType(type, record.type);
                items.push(record);
            }
        };

        //</editor-fold>


        //<editor-fold desc="Company Information">
        _this.getCompanies = function () {
            // routine to return the companies
            return data.companies;
        };

        _this.getCompanyName = function (id) {
            // routine to get the company name for the given id
            var record = lodash.find(data.companies, {id: id});
            if (record != null)
                return record.name;
            else
                return "Unknown (" + id + ")";
        };
        //</editor-fold>


        //<editor-fold desc="Customers">
        _this.readDynamicTable = function (model) {
            return apiProvider.getList("readDynamicTable", model);
        };
        //</editor-fold>

        //<editor-fold desc="Dashboard">
        _this.setDashboardState = function(state, dashboardConfig)
        {
            let code = dashboardConfig.module + "." + dashboardConfig.code;
            lodash.set(_this.dashboardStates, code , state);
        };

        _this.getDashboardState = function(dashboardConfig)
        {
            let code = dashboardConfig.module + "." + dashboardConfig.code;
            return lodash.get(_this.dashboardStates, code, null);
        };
        //</editor-fold>

        _this.setTemplates();

    }
    ]);
});
