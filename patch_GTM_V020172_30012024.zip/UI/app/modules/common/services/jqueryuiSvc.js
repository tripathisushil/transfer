/*
 /// <summary>
 /// app.modules.common.services - jqueryuiSvc
 /// Service to Manage JQuery UI Functions
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 12/4/2015
 /// Dialog Service is based on the following service - https://github.com/jwstadler/angular-jquery-dialog-service

 /// </summary>
 */
define(['modules/common/module', 'jquery-ui'], function(module){
    "use strict";
    module.registerService('jqueryuiSvc',['$rootScope','$q', '$http', '$compile','$interpolate', 'cacheDataSvc', function($rootScope,$q, $http, $compile, $interpolate, cacheDataSvc)
    {
        var _this = this;
        _this.dialogs = {};


        /*
         * CONVERT DIALOG TITLE TO HTML
         * REF: http://stackoverflow.com/questions/14488774/using-html-in-a-dialogs-title-in-jquery-ui-1-10
         */
        $.widget("ui.dialog", $.extend({}, $.ui.dialog.prototype, {
            _title: function (title) {
                if (!this.options.title) {
                    title.html("&#160;");
                } else {
                    title.html(this.options.title);
                }
            }
        }));


        this.getFormValidateOptions = function()
        {
            // routine to return form validate options for bootstrap validation
            return {
                feedbackIcons: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                }
            }
        };

        this.getFormNoFeedbackIcons = function()
        {
            // routine to return form validate options for bootstrap validation
            return {
                feedbackIcons: {
                    validating: 'glyphicon glyphicon-refresh'
                }
            }
        };


        this.getDialog = function(id) {

            // Get the dialog from the cache
            var dialog = _this.dialogs[id];
            // Throw an exception if the dialog is not found
            if (!angular.isDefined(dialog)) {
                throw "jquery-ui service does not have a reference to dialog id " + id;
            }
            return dialog;
        };


        this.cleanDialog = function(id)
        {
            // Get the dialog and throw exception if not found
            var dialog = _this.getDialog(id);

            // This is only called from the close handler of the dialog
            // in case the x or escape are used to cancel the dialog. Don't
            // call this from close, cancel, or externally.
            dialog.deferred.reject();
            dialog.scope.$destroy();

            // Remove the object from the DOM
            dialog.element.remove();

            // Delete the dialog from the cache
            delete _this.dialogs[id];
        };


        this.cancelDialog = function(id)
        {
            // routine to cancel a dialog given its id
            var dialog = _this.getDialog(id);

            // send back a rejection of the promise
            dialog.deferred.reject();

            // cancel and close the dialog (calling the cleanup)
            dialog.element.dialog("close");
        };

        this.closeDialog = function(id, result)
        {
            // routine to close a dialog given its id
            var dialog = _this.getDialog(id);

            // send back a resolution of the promise
            dialog.deferred.resolve(result);

            // cancel and close the dialog (calling the cleanup)
            dialog.element.dialog("close");
        };

        _this.openDialog = function(id, template, model, options)
        {
            // routine to open jquery dialog with based on smart-admin dialog standard, along with a scope (which the smart admin system did not allow)
            // check that we have the required arguments
            if (!angular.isDefined(id)) {
                throw "openDialog requires id in call to open";
            }

            if (!angular.isDefined(template)) {
                throw "openDialog requires template in call to open";
            }
            if (!angular.isDefined(model)) {
                model = null;
            }

            if (!angular.isDefined(options))
            {
                options = {
                    autoOpen: false,
                    modal: true,
                    width:'auto',
                    resizable: false
                };
            }

            var dialogOptions = {};
            if (angular.isDefined(options)) {
                angular.extend(dialogOptions, options);
            }

            // Initialize our dialog structure
            var dialog = { scope: null, element: null, deferred: $q.defer() };
            cacheDataSvc.loadTemplate(template).then(function(html){

                // set up the scope for the dialog
                dialog.scope = $rootScope.$new();
                dialog.scope.model = model;
                dialog.scope.dialogId = id;

                // create the parsed html
                var dialogLinker = $compile(html);
                dialog.element = $(dialogLinker(dialog.scope));

                // do the title and button parsing as per the smart admin standard
                var title = dialog.element.find('[data-dialog-title]').remove().html();
                var buttons = dialog.element.find('[data-dialog-buttons]').remove()
                    .find('button').map(function (idx, button) {
                        return {
                            class: button.className,
                            html: button.innerHTML,
                            click: function () {
                                if ($(button).data('action'))
                                    dialog.scope.$eval($(button).data('action'));
                                dialog.element.dialog("close");
                            }
                        }
                    });
                dialogOptions.title = $interpolate(title)(dialog.scope);
                dialogOptions.buttons = $interpolate(buttons)(dialog.scope);

                // Handle the case where the user provides a custom close and also
                // the case where the user clicks the X or ESC and doesn't call
                // close or cancel.
                var customCloseFn = dialogOptions.close;
                dialogOptions.close = function(event, ui) {
                    if (customCloseFn) {
                        customCloseFn(event, ui);
                    }
                    _this.cleanDialog(id);
                };

                dialog.element.dialog(dialogOptions);
                dialog.element.dialog("open");

                // Cache the dialog
                _this.dialogs[id] = dialog;
            }, function(error){
                // something has failed, write to the console and throw the error
                console.error("jquery dialog failed", error);
                throw error;
            });
            return dialog.deferred.promise;
        };

    }]);
});


