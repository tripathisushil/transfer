/*
 /// <summary>
 /// app.modules.iib.controllers - iibTransactionDetailDiagramCtrl
 /// Controller for IIB Transaction Detail - Diagram
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 02/10/2021
 /// </summary>
 */

define(['modules/common/module', 'lodash'], function (module, lodash) {

	"use strict";

	module.registerController('v1TransactionDetailDiagramCtrl', ['$scope', '$log', '$location',  '$state', 'uiSvc', function ($scope, $log, $location, $state, uiSvc)
    {

        // initialize the object
        var _this = this;
        _this.functions = {};
        _this.model = {flags: {diagramInitialized: false, paneInitialized: false}};
        _this.diagramOptions =  {
            layout: {
                type: "tree",
                subtype: "tipover",
                underneathHorizontalOffset: 140
            },
            connectionDefaults: {
                selectable: false,
                endCap:"ArrowEnd",
                stroke: {
                    color: "#979797",
                    width: 1
                }
            },
            zoomRate: 1,
            zoomMin: 1,
            zoomMax: 1

        };

        //<editor-fold desc="Diagram">
        _this.functions.diagramDrawer =  function (options)
        {
            // function to control how the diagram is drawn
            var dataviz = kendo.dataviz;
            var g = new dataviz.diagram.Group();

            var dataItem = options.dataItem;

            var color = "green";
            var baseColor = "#D4D4F0";
            if (dataItem.isError)
                color = "#a90329";
            if (!dataItem.enabled)
            {
                color = "black";
                baseColor = "#D1D1D7";
            }
            if (dataItem.shapeType === 2)
            {
                var image = new dataviz.diagram.Image({
                    source: dataItem.image.src,
                    width: dataItem.image.width,
                    height: dataItem.image.height
                });
                g.append(image);
            }
            if (dataItem.shapeType === 0)
            {

                g.append(new dataviz.diagram.Circle({
                    radius: 60,

                    stroke:
                        {
                            color: color,
                            width: 1
                        },
                    fill: color
                }));

                g.append(new dataviz.diagram.Circle({
                    radius: 55,
                    x: 5, y:5,
                    stroke:
                        {
                            color: baseColor,
                            width: 1
                        },
                    fill: baseColor
                }));
            }

            if (dataItem.shapeType === 1)
            {
                g.append(new dataviz.diagram.Rectangle({
                    width: 200,
                    height: 67,
                    stroke: {
                        width: 0
                    },
                    fill: baseColor
                }));
                g.append(new dataviz.diagram.Rectangle({
                    width: 8,
                    height: 67,
                    fill: color,
                    stroke: {
                        width: 0
                    }
                }));
            }
            return g;
        };

        _this.functions.refreshDiagram = function()
        {
            // routine to refresh the diagram
            // routine to refresh the diagram
            if ($scope.transactionType != 0 && $scope.transactionType != 101)   // non-mft transactions have no diagram
                return;
            uiSvc.drawKendoDiagramPoints($scope.diagram, $scope.data.diagram, _this.functions.diagramDrawer);
            if ($scope.data.diagram.zoom > 0 && $scope.navigation)
            {
                $scope.diagram.options.zoomMin = $scope.data.diagram.zoom;
                $scope.diagram.options.zoomMax = $scope.data.diagram.zoom;
                $scope.diagram.zoom($scope.data.diagram.zoom);
            }

            // now determine if we need to select the shape
            if (!$scope.diagram.select() || !$scope.diagram.select().length)
            {
                // find the shapes that match the url
                var foundShape = null;
                lodash.forEach($scope.diagram.shapes, function(shape)
                {
                    // check if this is the shape we want
                    if (!foundShape && $state.current.name.endsWith(shape.dataItem.route.routeName))
                    {
                        // check if the type matches

                        if (shape.dataItem.route.routeParms && $location.search().type)
                        {
                            var compareObject = angular.fromJson(shape.dataItem.route.routeParms);
                            if ($location.search().type == compareObject.type)
                                foundShape = shape;
                        }
                        else
                        {
                            foundShape = shape;
                        }
                    }
                });
                if (foundShape)
                    foundShape.select();
            }
        };

        _this.functions.navDiagram = function(event) {
            if (event.selected && event.selected.length && event.selected[0].dataItem) {
                // navigate to the route defined in the shape
                var url = event.selected[0].dataItem.route;
                if (url) {
                    var stateNav = "^." + url.routeName;
                    if (url.routeParms)
                        $state.go(stateNav, angular.fromJson(url.routeParms));
                    else
                        $state.go(stateNav);
                }
            }
        }
        //</editor-fold>

        //<editor-fold desc="Initialization">
        _this.functions.initView = function()
        {
            // routine to initialize the view when the data changes
            _this.functions.refreshDiagram();
        };

        _this.functions.checkInit = function()
        {
            // routine to check if both the panes and the diagram have been initialized and therefore we can request data from the server
            if (_this.model.flags.diagramInitialized && _this.model.flags.paneInitialized)
            {
                $scope.initView();          // This will cause the read from the server which will invoke the v2_changed event
            }
        };

        //<editor-fold desc="Event Subscribers">
        $scope.$on("kendoWidgetCreated", function(event, widget)
        {
            // once the kendo widgets are created
            if ($scope.diagram === widget)
            {
                _this.model.flags.diagramInitialized = true;
                _this.functions.checkInit();
            }
        });

        $scope.$on("panes_init", function(event, panes)
        {
            // once we know the splitter pane has been initialize the panes
            _this.model.flags.paneInitialized = true;
            _this.functions.checkInit();
        });

        $scope.$on("iib-changed", function()
        {
            // build the screen when we have been told we have data from the parent
            $scope.initializeTabs();
            _this.functions.initView();
        });
    }]);
});
