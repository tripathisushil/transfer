
/*
 /// <summary>
 /// modules.common.directives.ui - mqaJsonEditor.js
 /// Common Directive to Manage Viewing JSON Content via json EDITOR
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 22/01/2023
 /// </summary>
 */

define(['modules/common/module', 'jsoneditor', 'angular-jsoneditor'], function(module, jsoneditor)
{
    "use strict";
    window.JSONEditor = jsoneditor;
    module.registerDirective('mqaJsonEditor', ['$timeout', 'uiSvc', function($timeout, uiSvc)
    {
    return  {
        restrict: 'E',
        replace: true,
        templateUrl: 'app/modules/common/directives/ui/mqaJsonEditor.tpl.html',
        scope:{},
        bindToController: {
            data:"=",
            uiObject: "=?",
            readOnly:"@?",
            functionManager:'=?'
        },
        controllerAs:'vmEditor',
        controller: function ($scope)
        {
           var _this = this;
           _this.functions = {};



            _this.functions.initializeWidget = function()
            {
                // routine to initialize the widget


                const content = {
                    text: undefined, // used in text mode
                    json: {
                        array: [1, 2, 3],
                        boolean: true,
                        color: '#82b92c',
                        null: null,
                        number: 123,
                        object: { a: 'b', c: 'd' },
                        time: 1575599819000,
                        string: 'Hello World'
                    }
                };
                _this.model = {data: content, options: {mode: "code"}};

            };
            _this.functions.initializeWidget();
        }
    }
  }]);

});


