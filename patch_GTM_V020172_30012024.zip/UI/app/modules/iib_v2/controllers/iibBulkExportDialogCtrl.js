/*
 /// <summary>
 /// app.modules.iib_v2.controllers - iibBulkExportDialogCtrl
 /// Controller to Manage Bulk Export/Resubmit of Payloads in the IIB Module
 //  This will be a custom CLI Controller Dialog
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 28/05/2021
 /// </summary>
 */

define(['modules/iib_v2/module', 'lodash'], function (module, lodash)
{

    "use strict";

    module.registerController('iibBulkExportDialogCtrl', ['$scope', '$uibModalInstance', '$timeout', 'jqueryuiSvc', 'adminDataSvc', 'uiSvc', 'iibv2DataSvc', 'dialogData', function ($scope, $uibModalInstance, $timeout, jqueryuiSvc, adminDataSvc, uiSvc, dataSvc, dialogData)
    {
        let _this = this;

        // add the base model
        _this.model = {title: dialogData.title, icon: dialogData.icon, data: dialogData.data, flags: {allowDownload: false}};


        //<editor-fold desc="Functions">
        _this.functions = {};

        _this.functions.confirmDialog = function()
        {
            // routine to save the form
            _this.form.enableFieldValidators("destination", _this.model.data.resubmitType == '1');
            _this.form.validate();
            let valid = _this.form.isValid();
            if (!valid)
                return;
            dialogData.title = _this.model.data.resubmitType == '0' ? "Export Payloads" : "Re-Submit Payloads";

            // create the cli Request
            if (dialogData.functions.confirmFunction)
            {
                // send the data to the server
                dialogData.functions.confirmFunction(_this.model).then(function(result)
                {
                    _this.progressInfo.description = "Processing...";
                    _this.progressInfo.perc = "1%";
                    _this.progressInfo.inProgress = true;
                    _this.progressInfo.showHeader = false;
                    _this.progressInfo.buttons = [];

                    if (_this.model.data.resubmitType == '2')
                    {
                        dataSvc.prepareExportPayloadDialog(_this)
                    }

                    // update the dialog progress
                    if (dialogData.functions.responseFunction)
                        dialogData.functions.responseFunction(_this, result);

                    // trigger a dialog timer
                    _this.startTimer();
                }).catch(function(err)
                {
                    uiSvc.showError(dialogData.title + "Failed " + err);
                });
            }
        };
        _this.functions.cancelDialog = function()
        {
            // close the window
            $uibModalInstance.dismiss('cancel');
        };

        _this.functions.setupValidator = function()
        {
            // setup bootstrap validator when the form is rendered
            let innerForm = $(document.getElementById('frmBulkExport'));
            let fields = {
                fields: {
                    destination: {
                        group:"#div_destination",
                        excluded: false,
                        validators: {
                            notEmpty: {
                                message: 'Destination is Required'
                            },
                        }
                    },
                }
            };
            let formOptions = lodash.merge({}, jqueryuiSvc.getFormValidateOptions(), fields);
            let fv = innerForm.bootstrapValidator(formOptions);
            _this.form = innerForm.data('bootstrapValidator');

        }


        _this.functions.initialize = function()
        {
            // set up the model
            _this.model.flags.allowDownload = dataSvc.hasDownload();
            if (_this.model.flags.allowDownload)
                _this.model.data.resubmitType = '2';
            else
                _this.model.data.resubmitType = '1';
            _this.model.buttons = [];

            // initialize this for CLI
            adminDataSvc.initializeCLI(_this, dialogData, $uibModalInstance);
            _this.initialize();
            _this.progressInfo.inProgress = false;

            // setup bootstrap validator
            $uibModalInstance.rendered.then(function()
            {
                _this.functions.setupValidator();
            });
        };

        _this.functions.initialize()
        //</editor-fold>


    }]);
});
