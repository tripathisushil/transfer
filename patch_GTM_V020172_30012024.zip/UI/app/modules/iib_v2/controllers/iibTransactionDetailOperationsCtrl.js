/*
 /// <summary>
 /// app.modules.iib_v2.controllers - iibTransactionDetailOperationsCtrl.js
 /// Controller for Managing the IIB/ACE Transaction Operations Panel
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 04/09/2023
 /// </summary>
 */

define(['modules/iib_v2/module', 'lodash'], function (module, lodash) {

    "use strict";

    module.registerController('iibTransactionDetailOperationsCtrl', ['$scope', '$log', 'iibv2DataSvc', 'transactionReportingSvc', 'uiSvc', function ($scope, $log, dataSvc, transactionReportingSvc, uiSvc)
    {
        // initialize the model
        let _this = this;
        _this.functions = {};
        _this.model = {flags:{inProgress: false, allowDownload: false}};

        $scope.$on("iib_v2_changed", function()
        {
            // build the screen when we have been told we have data from the parent
            _this.functions.initView();
        });

        //<editor-fold desc="Functions">
        _this.functions.initialize = function()
        {
            // routine to initialize the controller and as necessary update the data
            _this.model.flags.allowDownload = dataSvc.hasDownload();
            _this.functions.initView();
        };


        _this.functions.initView = function()
        {
            // routine to initialize the controller and determine what operations the user has access to for this transaction
            if (!$scope.data)
                return;
            _this.model.id = $scope.data.baseTransaction.transactionId;
            _this.model.cliOperations = transactionReportingSvc.calcTransactionOperations($scope.data.baseTransaction);

            // check if there is at least more than 1 attachment
            if ($scope.data.module_data.payload_count != null)
            {
                _this.model.flags.allowDownload = $scope.data.module_data.payload_count > 0;
            }
            else
            {
                // BACKWARD COMPAT - check for attachments
                let attachments = lodash.filter($scope.data.module_data.nodes, function(node)
                {
                    if (node.info)
                    {
                        let attachment = lodash.find(node.info, function(o)
                        {
                            return o.attachment_id != null;
                        });
                        if (attachment != null)
                            return attachment;
                        else
                            return null;
                    };
                });
                _this.model.flags.allowDownload = attachments.length > 0;
            }
        };

        _this.functions.requestPayloadExport = function()
        {
            let cliOperation = {
                ui:
                    {
                        question: "Export Transaction Payloads",
                        class: "txt-color-",
                        icon: "fa fa-download",
                        description: "Export Transaction Payloads"
                    },
                operation: dataSvc.cliInstructionEnum.PAYLOAD_EXPORT,
                class: 'txt-color-teal'
            };
            cliOperation.record = {transactionId: _this.model.id};
            cliOperation.completeFunction = function (result, instructionData, isError)
            {
                 if (!isError)
                     uiSvc.showExtraSmallPopup("Payload Export", 'Export completed successfully !', 5000, null, "fa-download");

            };
            dataSvc.confirmCLIOperation(cliOperation);
        };

        //</editor-fold>

        // initialize
        _this.functions.initialize();
    }]);
});
