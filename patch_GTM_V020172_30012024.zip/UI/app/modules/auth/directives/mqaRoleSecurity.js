/*
 /// <summary>
 /// modules.auth.directives - mqaRoleSecurity.js
 /// General Authentication Directive to a show/hide or enable/disable elements based on the current users roles
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 30 August 2017
 /// </summary>
 */

define(['modules/auth/module', 'lodash'], function(module, lodash){
  "use strict";

  module.registerDirective('mqaRoleSecurity', ['userSvc', function(userSvc)
  {
    return {
        restrict: 'A',
        link: function ($scope, element, attributes)
        {
            $scope.$watch(attributes.mqaRoleSecurity, function (features)
            {
                var isInvalid = true;
                if (features === undefined || features === null || features.length === 0)
                {
                    isInvalid = true;
                }
                else
                {
                    lodash.forEach(features, function(feature)
                    {
                        var value = userSvc.hasFeature(feature);
                        if (value)
                        {
                            isInvalid = false;
                            return false;
                        }
                    })
                }
                if (isInvalid)
                {
                    // check if I need to modify the visibility or the enablement
                    if (attributes.roleDisabled)
                        $(element).prop("disabled", true);
                    else
                        element.hide();
                }
            });
        }

    }
  }]);

});


