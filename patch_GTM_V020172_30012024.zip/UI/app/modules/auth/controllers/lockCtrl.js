/*
 /// <summary>
 /// app.modules.auth.controllers - lockCtrl
 /// Controller to manage user Lock-out due to a session timeout
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 17/08/2017
 /// </summary>
 */
define(['modules/auth/module', 'lodash'], function (module, lodash)
{
    "use strict";
    module.registerController('lockCtrl', ['$scope', '$auth', '$log', '$timeout', 'uiSvc','userSvc', 'cacheDataSvc', function ($scope, $auth, $log, $timeout, uiSvc, userSvc, cacheDataSvc)
    {
        let _this = this;

        // create the functions
        _this.model = {};
        _this.functions = {};

        //<editor-fold desc="Form Management">
        _this.functions.initialize = function()
        {
            // routine to initialize the view
            _this.functions.setupEnvironment();

            // build up model variables
            _this.model.user = userSvc.getProfile();
            _this.model.flags = {inProgress: false}
            _this.model.company =  lodash.find(cacheDataSvc.getCompanies(), {id: _this.model.user.companyId});
            if (_this.model.company.validation_type == null)
                _this.model.company.validation_type = 0;

            _this.model.companyName = (_this.model.company != null ) ? _this.model.company.name : "";
            _this.model.flags.showLogin = (_this.model.company.validation_type === 0 || _this.model.company.validation_type === 1);

            // setup BV  when this form loads
            $timeout(function()
            {
                _this.functions.setupBootstrapValidator();
            }, 500);
        };

        _this.functions.setupEnvironment = function()
        {
            // determine the splash screen information
            let returnObj = uiSvc.buildSplash();
            returnObj.product = uiSvc.getProductInfo(cacheDataSvc.getProductEnvironment());
            _this.model.splash = returnObj.splash;
            _this.model.buttonClass = returnObj.buttonClass;
            _this.model.product = returnObj.product;
        };

        _this.functions.handleError = function(err)
        {
            // routine to manage error handling
            _this.model.flags.inProgress = false;
            userSvc.showLoginError("Lock-out", err);
        };

        _this.functions.setupBootstrapValidator = function ()
        {
            // routine to setup bootstrap validator for this form
            let form = $(document.getElementById('frmLock'));
            let fields = {
                fields: {
                    password: {
                        excluded: false,
                        container: "tooltip",
                        validators: {
                            notEmpty: {
                                message: 'The Login Password cannot be empty'
                            }
                        }
                    }
                }
            };
            let formOptions = lodash.merge({} ,fields, uiSvc.getFormNoFeedbackIcons());
            let fv = form.bootstrapValidator(formOptions).off('success.form.bv').on('success.form.bv', function(e)
            {
                // Prevent form submission
                e.preventDefault();
            });
            _this.form = form.data('bootstrapValidator');
            if (_this.form)
                _this.form.enableFieldValidators("password", _this.model.flags.showLogin);
        };
        //</editor-fold>

        //<editor-fold desc="Other Functions">
        _this.functions.login = function()
        {
            if (_this.form)
            {
                _this.form.validate();
                let valid = _this.form.isValid();
                if (!valid)
                    return;
            }
            _this.functions.invokeLogin();

        };

        _this.functions.invokeLogin = function()
        {
            // routine to invoke a login
            _this.model.flags.inProgress = true;
            let model = {user: _this.model.user.login, password: _this.model.password, companyId: _this.model.user.companyId, domain: _this.model.user.domain};
            userSvc.functions.invokeLogin(_this.model.company, model,_this.functions.handleError);
        };

        _this.functions.logout = function()
        {
            // routine to login as a different user
            userSvc.logout(true);
        };

        //</editor-fold>

        _this.functions.initialize();

    }]);
});