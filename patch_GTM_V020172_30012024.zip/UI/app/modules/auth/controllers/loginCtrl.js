/*
 /// <summary>
 /// app.modules.auth.controllers - loginCtrl
 /// Controller to manage user Sign-In
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 17/08/2017
 /// </summary>
 */
define(['modules/auth/module', 'lodash'], function (module, lodash)
{
    "use strict";
    module.registerController('loginCtrl', ['$scope', '$auth', '$timeout', 'uiSvc', 'jqueryuiSvc','userSvc', 'cacheDataSvc', 'cachePromise', function ($scope, $auth, $timeout,  uiSvc, jqueryuiSvc, userSvc, cacheDataSvc, cachePromise)
    {
        let _this = this;
        _this.model = {credentials:{}, splash:{}, flags: {allowSocial: false, allowRegister: false, inProgress: false, showDomain: false, showLogin: true}};

        // create the functions
        _this.functions = {};


        //<editor-fold desc="Form Management">
        _this.functions.initializeCompany = function()
        {
            _this.model.companies = cacheDataSvc.getCompanies();
            _this.model.credentials.company = lodash.find(_this.model.companies, {default: true});
            if (_this.model.credentials.company == null)
                _this.model.credentials.company = lodash.find(_this.model.companies, {id: 2});
            if (_this.model.credentials.company == null)
                _this.model.credentials.company = _this.model.companies[0];
        };

        _this.functions.initialize = function()
        {
            // routine to initialize the view after the cache has been read
            userSvc.logout(false);

            // clear out any token
            $auth.removeToken();

            // setup the environment
            _this.functions.setupEnvironment();

            // get the companies and select the default one
            _this.functions.initializeCompany();

            // Standard/MS-AD Login
            $timeout(function()
            {
                _this.functions.setupBootstrapValidator();
            }, 500);

        };

        _this.functions.setupEnvironment = function()
        {
            // determine the splash screen information
            let returnObj = uiSvc.buildSplash();
            returnObj.product = uiSvc.getProductInfo(cacheDataSvc.getProductEnvironment());

            _this.model.splash = returnObj.splash;
            _this.model.buttonClass = returnObj.buttonClass;
            _this.model.product = returnObj.product;
        };

        _this.functions.handleError = function(err)
        {
            // routine to manage error handling
            _this.model.flags.inProgress = false;
            userSvc.showLoginError("Sign-In", err);
        };

        _this.functions.setupBootstrapValidator = function ()
        {
            // routine to setup bootstrap validator for this form
            let form = $(document.getElementById('frmLogin'));
            let fields = {
                fields: {
                    loginCode: {
                        excluded: false,
                        group: "#div_login",
                        validators: {
                            notEmpty: {
                                message: 'Login Code cannot be empty'
                            }
                        }
                    },
                    password: {
                        excluded: false,
                        group: "#div_password",
                        validators: {
                            notEmpty: {
                                message: 'The Login Password cannot be empty'
                            }
                        }
                    },
                    company_select: {
                        excluded: false,
                        group: "#div_companySelect",
                        validators: {
                            callback: {
                                message: 'Company is Mandatory',
                                callback: function (value, validator, $field)
                                {
                                    const valid = _this.model.credentials.company != null;
                                    return valid;
                                }
                            }
                        }
                    },
                    domain_select: {
                        excluded: false,
                        group: "#div_domainSelect",
                        validators: {
                            callback: {
                                message: 'Domain is Mandatory',
                                callback: function (value, validator, $field)
                                {
                                    const valid = _this.model.credentials.domain != null;
                                    return valid;
                                }
                            }
                        }
                    }
                }
            };
            let formOptions = lodash.merge({} ,fields, jqueryuiSvc.getFormNoFeedbackIcons());
            let fv = form.bootstrapValidator(formOptions).on('success.form.bv', function(e)
            {
                // Prevent form submission
                e.preventDefault();
            });
            _this.form = form.data('bootstrapValidator');

            // select the first company in the list
            _this.functions.onCompanyChange();
        };
        //</editor-fold>

        //<editor-fold desc="Other Functions">

        _this.functions.login = function()
        {
            if (_this.form)
            {
                _this.form.revalidateField("company_select");
                _this.form.revalidateField("domain_select");
                _this.form.validate();
                let valid = _this.form.isValid();
                if (!valid)
                    return;
            }
            _this.functions.invokeLogin();
        };
        _this.functions.invokeLogin = function()
        {
            // routine to invoke a login
            _this.model.flags.inProgress = true;
            let model = {
                user: _this.model.credentials.user,
                password: _this.model.credentials.password,
                companyId: _this.model.credentials.company.id
            };
            if (_this.model.credentials.domain)
                model.domain = _this.model.credentials.domain.domain;
            userSvc.functions.invokeLogin(_this.model.credentials.company, model,_this.functions.handleError);
        };

        _this.functions.onCompanyChange = function()
        {
            // routine to handle the re-selection of a company when initial display or when the user changes the company
            let currentCompany = _this.model.credentials.company;
            if (currentCompany.validation_type == null)
                currentCompany.validation_type = 0;
            _this.model.validation_type = parseInt(currentCompany.validation_type);
            _this.model.flags.showLogin = (currentCompany.validation_type == 0 || currentCompany.validation_type == 1);
            _this.model.flags.showDomain = currentCompany.validation_type == 1 && currentCompany.validation_details.domains != null;
            if (_this.form)
            {
                _this.form.enableFieldValidators("domain_select", _this.model.flags.showDomain);
                _this.form.enableFieldValidators("loginCode", _this.model.flags.showLogin);
                _this.form.enableFieldValidators("password", _this.model.flags.showLogin);
            }
            if (_this.model.flags.showDomain)
            {
                // set the variables
                _this.model.credentials.domain = currentCompany.validation_details.domains[0]
            }
            else
            {
                _this.model.credentials.domain = null;
            }
        };
        //</editor-fold>

        _this.functions.initialize();
    }]);
});

