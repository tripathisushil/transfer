/*
 /// <summary>
 /// app.modules.custom.spe_cno.services - speCNODataSvc.js
 /// CNO SPE Module Data Service
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 15/12/2017
 /// </summary>
 */
define(['modules/custom/spe_cno/module', 'lodash'], function(module, lodash)
{
    "use strict";
    module.registerService('speCNODataSvc',['$state', '$filter','$log', '$timeout', '$q', 'uiSvc','apiSvc', 'apiProvider', 'cacheDataSvc', 'chartSvc', 'transactionReportingSvc', function($state, $filter, $log, $timeout, $q, uiSvc, apiSvc, apiProvider, cacheDataSvc, chartSvc, transactionReportingSvc)
    {
        let _this = this;
        // setup the api
        let configs = [
            {url: 'client/cno/spe/reporting/rep001', resourceName:'speCNOReport_REP001'},
            {url: 'client/cno/tpci/search', resourceName: 'speCNOTPCISearch'},
            {url: 'client/cno/tpci/dashboard', resourceName: 'speCNOTPCIDashboard'},
            {url: 'client/cno/tpci/vendor', resourceName: 'speCNOTPCIVendor'},
            {url: 'client/cno/tpci/errors', resourceName: 'speCNOTPCIErrors'},
            {url: 'client/cno/tpci/transactions', resourceName: 'speCNOTPCITransactions'},
            {url: 'client/cno/tpci/detail/', resourceName: 'speCNOTPCIDetail'},

            {url: 'client/cno/aegf/search', resourceName: 'speCNOAEGSearch'},
            {url :'client/cno/aegf/read/:id', resourceName: 'speCNOAEGRead', params: {id:'@id'}},
            {url :'client/cno/aegf/update/:id', resourceName: 'speCNOAEGFUpdate', params: {id:'@id'}}

        ];

        angular.forEach(configs, function(value){
            apiSvc.add(value);
        });


        //<editor-fold desc="Sender & Customized Reporting">
        _this.senderImport = function(model)
        {
            // routine to prepare for sender imports
            return apiProvider.getObject("speCNOSenderImport", model);
        };
        _this.processReport_REP001 = function(model)
        {
            return apiProvider.getList("speCNOReport_REP001", model);
        };
        //</editor-fold>


        //<editor-fold desc="Third Party Commission Intake">
        _this.tpciModules = {ENROLLMENT: 1, COMMISSION: 2};
        _this.tpciVendors = cacheDataSvc.getListForType("1", "TPCI_VENDOR");


        //<editor-fold desc="Dashboard">
        _this.refreshTPCIDashboard = function (filterObject, module) {
            // routine to request the TPCI Dashboard Reporting for the given filter object and module id
            filterObject.module = module;
            return apiProvider.getObject('speCNOTPCIDashboard', filterObject);
        };

        _this.refreshTPCIVendor = function(filterObject)
        {
            // routine to return the vendor breakdown information for the given filter
            return apiProvider.getList('speCNOTPCIVendor', filterObject);
        };

        _this.refreshTPCIErrors = function(filterObject)
        {
            // routine to return the the error listing for the given filter
            return apiProvider.getList('speCNOTPCIErrors', filterObject);
        };
        _this.refreshTPCITransactions = function(filterObject)
        {
            // routine to return the the record listing for the given filter
            return apiProvider.getList('speCNOTPCITransactions', filterObject);
        };

        _this.getTPCIDashboardColorPalette = function (module)
        {
            // routine to return the color palette for for the WMQ Gateway Bridge
            let baseColors = chartSvc.getColors();
            //let colors =  ['#6096BA', '#274C77','#FF6700', '#A3CEF1', '#023047', '#8B8C89'];
            //let color =  {error: baseColors.chartError, unk: baseColors.chartUnknown, requests: colors[0], success: colors[1], time: colors[2], bytes: colors[3], proc_time: colors[5]};
            let colors = ['#89BBFE', '#006494', '#25A18E', '#7AE582', '#615d6C', '#9EB3C2'];
            let color = {
                error: baseColors.chartError,
                unk: baseColors.chartUnknown,
                requests: colors[0],
                success: colors[1],
                amounts: colors[2],
                vendors: colors[3],
                send_bytes: colors[4],
                receive_bytes: colors[5]
            };

            return {
                colorArray: colors,
                colorNames: color
            };
        };

        _this.showTPCIVendorSummary = function (filter, module)
        {
            // routine to display the Vendor Summary Dialog on the TPCI Dashboard
            let record = filter;
            record.module = module;

            let controlOptions = {};
            controlOptions.templateUrl = "app/modules/custom/spe_cno/partials/tpci-vendor-detail-dialog.tpl.html";
            controlOptions.controller = "cnoTpicVendorDetailDialogCtrl";
            controlOptions.controllerAs = "vmDialog";
            controlOptions.size = 'lg';
            controlOptions.windowClass = 'lg-modal';
            uiSvc.showDialog(record, controlOptions);
        };

        _this.onTPCICountDrill = function(data, filter)
        {
            // routine to handle drills on the counts for both the comparision filter and the standard filter
            let module = filter.module;
            switch (data.caption)
            {
                case "Vendors":
                    _this.showTPCIVendorSummary(filter, module);
                    break;
                case "Errors":
                    _this.showTPCITransactionSummary(filter, 1);
                    break;
                case "Transactions Received":
                    _this.showTPCITransactionSummary(filter, 0);
                    break;
            }
        };



        _this.showTPCITransactionSummary = function(filter, type)
        {
            // routine to display the Transaction Dialog on the TPCI Dashboard
            let record = {filter: filter, type: type};
            let controlOptions = {};
            controlOptions.templateUrl = "app/modules/custom/spe_cno/partials/tpci-dashboard-transaction-dialog.tpl.html";
            controlOptions.controller = "cnoTpciDashboardTransactionDialogCtrl";
            controlOptions.controllerAs = "vmDialog";
            controlOptions.size = 'lg';
            controlOptions.windowClass = 'xl-modal';
            uiSvc.showDialog(record, controlOptions);
        };

        _this.parseTPCIVendorData = function(value)
        {
            // routine to parse the record the data for grid use
            lodash.forEach(value, function(item)
            {
                let value = $filter("localUTCStringFilter")(item.last_date);
                item.last_date = $filter("kendoDateFilter")(value);
                item.name = item._id;

                // get the name
                let record = cacheDataSvc.getListRecord("1", "TPCI_VENDOR", item._id);
                if (record != null)
                    item.name = record.description;
            });
            return value;
        };


        //</editor-fold>

        //<editor-fold desc="Grid">
        _this.parseTPCICountData = function (data, vendorData, updateObject, module, mode)
        {
            // update the counts for the given data for the given module
            if (data == undefined)
                data = {count: 0, succeeded: 0, failed: 0, vendors: 0, amount: 0, premium: 0};

            // update the vendors data
            data.vendors = (vendorData) ? vendorData.length : 0;

            updateObject.vendors.value = $filter("number")(data.vendors);
            updateObject.requests.value = $filter("number")(data.count);
            updateObject.failed.value = $filter("number")(data.failed);

            // update the commission data
            if (module == _this.tpciModules.COMMISSION)
            {
                updateObject.amount.value =  $filter("currency")(data.amount);
                updateObject.premium.value =  $filter("currency")(data.premium);
            }
        };

        _this.refreshTPCISearch = function(filterObject, module)
        {
            // routine to return all requests for the given filter in the given module with stats
            filterObject.module = module;
            return apiProvider.getObject('speCNOTPCISearch', filterObject);
        };

        _this.parseTPCIGridData = function(value, module)
        {
            // routine to parse the record the data for grid use
            let dateFormat = "yyyy-MM-dd";
            lodash.forEach(value, function(item)
            {
                let value = $filter("localUTCStringFilter")(item.received_date);
                item.received_date = $filter("kendoDateFilter")(value);
                if (item.insured_dob)
                {
                    value = $filter("removeUTCDateFilter")(item.insured_dob);
                    item.insured_dob = $filter("kendoDateFilter")(value, dateFormat);
                }
                if (item.policy)
                {
                    if (item.policy.effective_date)
                    {
                        value = $filter("removeUTCDateFilter")(item.policy.effective_date);
                        item.policy_effective_date = $filter("kendoDateFilter")(value, dateFormat);
                    }
                    if (item.policy.signed_date)
                    {
                        value = $filter("removeUTCDateFilter")(item.policy.signed_date);
                        item.policy_signed_date = $filter("kendoDateFilter")(value, dateFormat);
                    }
                    if (item.policy.termination_date)
                    {
                        value = $filter("removeUTCDateFilter")(item.policy.termination_date);
                        item.policy_termination_date = $filter("kendoDateFilter")(value, dateFormat);
                    }
                    if (item.policy.original_eff_date)
                    {
                        value = $filter("removeUTCDateFilter")(item.policy.original_eff_date);
                        item.policy_original_eff_date = $filter("kendoDateFilter")(value, dateFormat);
                    }
                }
                if (item.agent_npn && (!item.agent_san || item.agent_san == ''))
                    item.agent_san = item.agent_npn;
                if (item.commission)
                {
                    if (item.commission.eff_date)
                    {
                        value = $filter("removeUTCDateFilter")(item.commission.eff_date);
                        item.commission_eff_date = $filter("kendoDateFilter")(value, dateFormat);
                    }
                }
                _this.getTPCIRowStatus(item);
            });
            return value;
        };

        _this.getTPCITransactionStatus = function (value)
        {
            // return the status for the given value - this matches GWID Status
            return $filter("speGwidStatusFilter")(value);
        };

        _this.getTPCIProcStatus = function (value, rowStyle)
        {
            // return the status for the TPCI Status for the given value
            let status = parseInt(value);
            if (rowStyle)
            {
                if (status >=1 && status < 5 && rowStyle != 'transactionError')
                    rowStyle = 'transactionError';
            }
            switch (status)
            {
                case 1:
                    return "Input Document";
                    break;
                case 2:
                    return "Document Failed - Record Length";
                    break;
                case 3:
                    return "Document Failed - Duplicate Record";
                    break;
                case 4:
                    return "Document Failed - Pre-Edits";
                    break;
                case 5:
                    return "Document Failed - Duplicate Field";
                    break;
                case 6:
                    return "Merge - Ready for Extraction by LifePro";
                    break;
                case 7:
                    return "Sent to Life-Pro - Awaiting Response";
                    break;
                case 8:
                    return "Feedback Received from LifePro";
                    break;
                default:
                    return "Unknown (" + value + ")";
            };
        };

        _this.getTPCIVendor = function(code, company)
        {
            // routine to return the TCPI Vendor Name
            let vendor = lodash.find(_this.tpciVendors, function(record)
            {
                return record.companyId == company && record.code == code;
            });
            if (vendor != null)
                return vendor.description;
            else
                return code;
        };

        _this.getTPCIRowStatus = function(row)
        {
            // return the status for the given value - this matches GWID Status
            row.rowStyle = $filter("speGwidRowStyleFilter")(row.status);
            row.status_desc = _this.getTPCITransactionStatus(row.status);
            row.vendor_name = _this.getTPCIVendor(row.vendor_code, row.company_id);
            row.processing_status_desc = _this.getTPCIProcStatus(row.processing_status, row.rowStyle);
        };

        //</editor-fold>

        //<editor-fold desc="Detail">
        _this.showTPCIAssociatedTransaction = function(modalResult)
        {
            // routine to show associated transactions with from a TPCI Drill
            var baseState = null;
            let record = {transactionId: modalResult.id};
            switch(modalResult.module)
            {
                case "itx":
                case "itx_lifepro":
                    //baseState = "app.custom.spe_cno.reporting";
                    //record.transactionType = 2;
                    baseState = "app.mft_v2.reporting";
                    record.transactionType = 0;
                    break;
                case "mft":
                    baseState = "app.mft_v2.reporting";
                    record.transactionType = 0;
                    break;
            }
            transactionReportingSvc.navigateTransaction(baseState + ".transactionDetail.jobview", record);
        };

        _this.showTCPIDetail = function(doc)
        {
            // routine to show the the detail of an TPCI Record

            let record = doc;
            let controlOptions = {};
            controlOptions.templateUrl = "app/modules/custom/spe_cno/partials/tpci-detail-dialog.tpl.html";
            controlOptions.controller = "cnoTpciDetailDialogCtrl";
            controlOptions.controllerAs = "vmDialog";
            controlOptions.size = 'lg';
            controlOptions.windowClass = 'xl-modal';
            let modalInstance = uiSvc.showDialog(record, controlOptions);
            modalInstance.result.then(function (modalResult)
            {
                if (modalResult.id)
                    _this.showTPCIAssociatedTransaction(modalResult);
            }).catch(function (err)
            {
                if (err != "cancel")
                    $log.error("Unable to Display Detail Dialog", err);
            });
        };

        _this.readTPCIDetail = function(doc)
        {
            // routine to return the gwid for the given document
            let filterObject = {oid: doc.id, companyId: doc.company_id, recordIndex: doc.record_index, jobId: doc.job_id, processingKey: doc.processing_id, module: doc.entity_type};
            if (doc.reference && doc.reference.itx && doc.reference.itx.id)
                filterObject.ediTransactionId = doc.reference.itx.id;
            if (doc.reference && doc.reference.lifepro && doc.reference.lifepro.job_id)
            {
                filterObject.systemId = doc.source_system_id;
                filterObject.lifeProJobId = doc.reference.lifepro.job_id;
                if (doc.reference.lifepro.itx_id)
                    filterObject.lifeProEdiTransactionId = doc.reference.lifepro.itx_id;
            }
            return apiProvider.getObject("speCNOTPCIDetail", filterObject);
        };
        //</editor-fold>

        //<editor-fold desc="General Functions">
        _this.getTPCIDepartment = function()
        {
            // determine the type of reporting to do based on the state
            let department = {id: 0, code: "enrollment"};
            let _state = $state.get($state.current);
            if (_state != null && _state.data != null && _state.data.department)
                department = _state.data.department;
            return department;
        };
        _this.getTPCIDepartmentName = function(type)
        {
            // routine to return the department name
            if (type == _this.tpciModules.ENROLLMENT)
                return "Enrollment";
            if (type == _this.tpciModules.COMMISSION)
                return "Commission";
            return "Unknown";
        };


        //</editor-fold>





        //</editor-fold>

        //<editor-fold desc="Automated Employer Group Files">
        _this.aegf = {functions: {}, data: {}};
        _this.aegf.functions.updateConfig = function(record, recordStatus, id, description)
        {
            // routine to save the given list of customer list records with audit information
            let model = {record: record, recordStatus: recordStatus, audit: _this.createAudit(description, 0)};
            return apiProvider.getObjectMixed("speCNOAEGFUpdate", {id: id}, model);
        };
        _this.aegf.functions.readConfig = function(id)
        {
            // routine to read an aegf configuration using its id
            return apiProvider.get('speCNOAEGRead', {id: id});
        };
        _this.aegf.functions.searchConfigs = function(filterObject)
        {
            // routine to read all configs for the given filter object
            return apiProvider.getObject("speCNOAEGSearch", filterObject);
        };
        _this.aegf.functions.initializeConfig = function(group, sub_group)
        {
            // routine to initialize a new config record with the defaults
            let record = {};
            return record;
        }
        //</editor-fold>


    }]);

});
