/*
 /// <summary>
 /// app.modules.custom.mfthix.controllers - mftHixNavigationCtrl.js
 /// Base MFT HIX Navigation Controller
 /// Abstract Controller that is the parent of all MFT HIX Module Screens - this will manage Signal-R Listeners amongst other things
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date:29/3/2016
 /// </summary>
 */
define(['modules/custom/mfthix/module'], function (module) {

	"use strict";

	module.registerController('mftHixNavigationCtrl', ['$scope', 'transactionReportingSvc', function ($scope, transactionReportingSvc)
	{
       // update the transaction reporting service
       transactionReportingSvc.reset(0);


	}]);
});
