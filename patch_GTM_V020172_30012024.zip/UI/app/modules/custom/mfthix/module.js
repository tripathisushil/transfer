/*
 /// <summary>
 /// app.modules.custom.mfthix - module.js
 /// Emblem Health MFT HIX Module Bootstrapper - All Views will be the MFT Views this is just the bootstapper
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 29/3/2016
 /// </summary>
 */
define([
    'angular',
    'angular-couch-potato',
    'angular-ui-router',
    'angular-resource',
    'modules/common/module',
    'modules/mft/module',
    'modules/custom/mfthix/module'
    

], function (ng, couchPotato) {
    'use strict';

    var module = ng.module('app.mqacustom.mfthix', ['ui.router','ngResource','app.mqacommon', 'app.mqamft']);
    var stateProvider;
    var couchProvider;


    module.config(function ($stateProvider, $couchPotatoProvider)
    {
        stateProvider = $stateProvider;
        couchProvider = $couchPotatoProvider;
        $stateProvider
            .state('app.custom.mfthix',
            {
                abstract: true,
                url: '/mfthix',
                views:
                {
                    "nav@app": {
                        controller: 'mftHixNavigationCtrl',
                        templateUrl: 'app/modules/custom/mfthix/partials/navigation.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/custom/mfthix/controllers/mftHixNavigationCtrl',
                                'modules/mft/services/mftChartSvc',
                                'modules/mft/services/mftDataSvc'
                            ])
                        }
                    },
                    "content@app":
                    {
                        templateUrl: 'app/modules/layout/partials/module-header.tpl.html'
                    },
                    "realtime@content":
                    {
                        controller: 'mftRealtimeCtrl',
                        templateUrl: 'app/modules/mft/partials/realtime-header.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/mft/controllers/mftRealtimeCtrl'
                            ])
                        }
                    }
                },
                data:
                {
                    title: 'HIX MFT Interface', module: 'HIX MFT Documents'
                }
            })
            .state("app.custom.mfthix.reporting.transaction",
            {
                abstract: true,
                url: '/transaction',
                views:
                {
                    "innerContent@content":
                    {
                        controller: 'mftTransactionReportingCtrl',
                        templateUrl: 'app/modules/transaction-reporting/partials/transaction-reporting-layout.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/mft/controllers/mftTransactionReportingCtrl'
                            ])

                        }
                    },
                    "filterContent@content":
                    {
                        templateUrl:'app/modules/mft/partials/transaction-reporting-filter.tpl.html'
                    },
                    "footerContent@content":
                    {
                        templateUrl:'app/modules/mft/partials/transaction-reporting-footer.tpl.html'
                    }
                },
                data:
                {
                    title:'Transaction Reporting'
                }
            })
            .state("app.custom.mfthix.reporting.transaction.gridview",{
                url: '/gridview',
                views: {
                    "tabContent@content": {
                        controller: 'transactionReportingGridViewCtrl',
                        templateUrl: 'app/modules/transaction-reporting/partials/transaction-reporting-gridview.tpl.html',
                        resolve:  {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/transaction-reporting/controllers/transactionReportingGridViewCtrl'
                            ])
                        }
                    }
                }
            })
            .state('app.custom.mfthix.dashboard', {
                url: '/dashboard',
                views: {
                    "innerContent@content":
                    {
                        controller: 'mftDashboardCtrl',
                        templateUrl: 'app/modules/mft/partials/dashboard.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/mft/controllers/mftDashboardCtrl',
                                'modules/mft/directives/mqaMftTransactionStats',
                                'modules/mft/directives/mqaMftToDo',
                                'smartadmin/modules/graphs/directives/flot/flotBasic',
                                'smartadmin/modules/graphs/directives/vectormap/vectorMap'
                            ])

                        }
                    }
                },
                data:{
                    title: 'Dashboard'
                }
            })
    });

    couchPotato.configureApp(module);

    module.run(['$couchPotato', 'transactionReportingSvc',  'uiSvc', function($couchPotato, transactionReportingSvc, uiSvc)
    {
        module.lazy = $couchPotato;
        transactionReportingSvc.createDetailRoutes("app.custom.mfthix", stateProvider, couchProvider);
        var viewStates = uiSvc.initializeMFTViewStates(couchProvider);
        uiSvc.createViewStates("app.custom.mfthix", stateProvider, viewStates);
    }]);
    return module;
});