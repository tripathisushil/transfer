/*
 /// <summary>
 /// app.modules.custom.faster.controllers - fasterVendorAdminCtrl.js
 /// Faster Vendor Administration Controller
 /// Controller to manager the Faster Vendor Administration Process
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 11/08/2015
 /// </summary>
 */
define(['modules/custom/faster/module', 'moment'], function (module, moment) {

	"use strict";
	moment().format();


	module.registerController('fasterVendorAdminCtrl', ['$scope', '$log', 'apiSvc', 'apiProvider', function ($scope, $log, apiSvc, apiProvider) 	{


		// setup the webservice calls
		var config = {url :'/faster/vendor', 'resourceName': 'fasterVendorAdmin'};
		apiSvc.add(config);


		$scope.getAll = function () {
			// routine to formulate the filter object based on the current scope and send the filter object to the server for processing
			// now search for the data
			apiProvider.getList('fasterVendorAdmin').then(function (result)
			{
				$scope.data = result;
			}).catch(function (result) {
				$log.error("Unable to retrieve Transaction Data", result);
			});
		};

		$scope.addUpdate = function(profile, isAdd)
		{
			// routine to add the profile
			if (isAdd)
				profile.id = 0;
			apiProvider.save("fasterVendorAdmin", profile).then(function (result)
			{
				$scope.data = result;

			}).catch(function (result)
			{
				$log.error("Unable to Process Request", result);
			});
		};

		$scope.delete = function(id)
		{
			apiProvider.admin("fasterVendorAdmin", id).then(function (result)
			{
				$scope.data = result;

			}).catch(function (result)
			{
				$log.error("Unable to Process Request", result);
			});


		};

		// get the initial data on controller instantiation
		$scope.getAll()
	}]);
});
