/*
 /// <summary>
 /// app.modules.custom.hix - module.js
 /// Emblem Health HIX Module Bootstrapper
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 6/28/2015
 /// </summary>
 */
define([
    'angular',
    'angular-couch-potato',
    'angular-ui-router',
    'angular-resource',
    'modules/common/module',
    'modules/custom/faster/module',

], function (ng, couchPotato) {
    'use strict';

    var module = ng.module('app.mqacustom.faster', ['ui.router','ngResource','app.mqacommon']);
    var stateProvider;
    var couchProvider;


    module.config(function ($stateProvider, $couchPotatoProvider)
    {
        stateProvider = $stateProvider;
        couchProvider = $couchPotatoProvider;
        $stateProvider
            .state('app.custom.faster.admin.vendor', {
                url: '/faster/admin/vendor',
                views: {
                    "innerContent@content":
                    {
                        controller: 'fasterVendorAdminCtrl',
                        templateUrl: 'app/modules/custom/faster/partials/vendor-admin.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/custom/faster/controllers/fasterVendorAdminCtrl',
                                'modules/custom/hix/directives/mqaHixCounts',
                                'modules/custom/hix/directives/mqaHixMemberStats',
                                'modules/custom/hix/directives/mqaHixTimeStats',
                                'modules/custom/hix/directives/mqaHixDocTimeStats'
                            ])

                        }

                    }
                },
                data:{
                    title: 'Vendor Profile Administration', module: 'Administration', module_id:"admin", security:["admin"]
                }
            })
    });

    couchPotato.configureApp(module);

    module.run(['$couchPotato', 'uiSvc', function($couchPotato, uiSvc){
        module.lazy = $couchPotato;
    }]);

    return module;
});