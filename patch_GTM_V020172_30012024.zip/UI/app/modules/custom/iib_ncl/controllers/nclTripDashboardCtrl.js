/*
 /// <summary>
 /// app.modules.custom.iib_ncl.controllers - nclTripDashboardCtrl.js
 /// Controller to manage NCL Trips IIB Dashboard
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 07/05/2018
 /// </summary>
 */
define(['modules/custom/iib_ncl/module', 'moment', 'lodash', 'appCustomConfig'], function (module, moment, lodash, appCustomConfig) {

    "use strict";
    moment().format();

    module.registerController('nclTripDashboardCtrl', ['$scope', '$filter', '$log', '$interval', '$timeout', '$state', 'chartSvc','iibv2DataSvc', 'userSvc', 'uiSvc', 'cacheDataSvc', 'transactionReportingSvc', function ($scope, $filter, $log, $interval, $timeout, $state, chartSvc, iibv2DataSvc, userSvc, uiSvc, cacheDataSvc, transactionReportingSvc)
    {
        var _this = this;
        _this.functions = {};

        // user config variables
        const  _dashboardLimitConfig = "info.settings.iib_ncl.dashboards.trip.lastLimit";

        //<editor-fold desc="Data Management">
        _this.functions.initializeVariables = function()
        {
            // routine to initialize the base view model variables
            var now = moment();
            _this.model = {};
            _this.timers = {};
            _this.model.flags = {toggle: true, appliedUserDates: 0, inProgress: false, showTableSettings: false};  // initialize the view model

            // date options
            _this.model.userDateOptions = {fromDate:{maxDate: now}, toDate:{maxDate: now, minDate: now}};
            _this.model.userDateOptions.fromDate.value = now;
            _this.model.userDateOptions.toDate.value = now;
            _this.model.userDateOptions.disabled = true;
            _this.model.userDateValidator = {};



            // set the initial state of the dashboard
            _this.model.updateType = chartSvc.dashboardStates.INITIALIZE;

            // initialize the filter to take into account the user departments
            var orgInfo = userSvc.getOrgInfo();
            _this.model.filterObject = {};
            _this.model.filterObject.companyId =  orgInfo.companyId;
            _this.model.filterObject.departments = [];
            if (!userSvc.hasFeature("FILTERALL"))
                lodash.merge(_this.model.filterObject.departments, orgInfo.departments);

            // application list
            _this.model.application = {selected: "ALL"};
            _this.model.application.options = cacheDataSvc.getListForType("1", "IIB_APP",  _this.model.filterObject.companyId);
            _this.model.application.options.unshift({code:"ALL", description:"All Applications"});


            // initialize the theme
            var dashboardTheme = chartSvc.getDashboardPalette();
            _this.model.colors = dashboardTheme.colors;
            _this.model.opacity = dashboardTheme.opacity;



            // initialize the timers
            _this.timers.timer = null;
            _this.timers.dayTimer = null;
            _this.timers.dayIntervalTimer = null;

        };


        _this.functions.initWidgets = function (initialLoad)
        {


            //<editor-fold desc="Transaction Table Widget">
            _this.model.transactionTable = {};
            _this.model.transactionTable.data = [];
            _this.model.transactionTable.update = {value: 0};
            _this.model.transactionTable.options = {
                resizable: false,
                selectable: "row",
                sortable: true,
                groupable: false,
                filterable: true,
                columnMenu: true,
                scrollable: true,
                reorderable: false,
                noRecords: true,
                messages: {
                    noRecords: "No Records Available"
                },
                dataSource: {
                    pageSize: 25,
                    sort: [
                        {field: "action_date", dir: "desc"}
                    ],
                    schema:
                        {
                            model:
                                {
                                    id: "_id",
                                    uid:"_id"
                                }
                        },
                    aggregate: [
                        { field: "node_count", aggregate: "sum" },
                        { field: "_id", aggregate: "count" },
                        { field: "running_time", aggregate: "sum" },
                        { field: "is_error", aggregate: "sum"}]


        },
                pageable:
                    {
                        pageSizes: [25,50,75, "All"]
                    },
                columns: [
                    {
                        field: "_id",
                        title: "TransactionId",
                        width: "100px",
                        filterable: {
                            cell: {
                                showOperators: false,
                                operator: "contains",
                                inputWidth: 200
                            }
                        },
                        aggregates:["count"],
                        footerTemplate:"Total: #=count#",
                        groupFooterTemplate:"Total: #=count#"
                    },
                    {
                        field: "action_date",
                        title: "Transaction Date",
                        format: "{0:yyyy-MM-dd HH:mm:ss.fff}",
                        width: "180px"
                    },
                    {
                        field: "broker_id",
                        title: "Broker",
                        width: "200px",
                        filterable: {
                            cell: {
                                showOperators: false,
                                operator: "contains",
                                inputWidth: 160
                            }
                        }
                    },
                    {
                        field: "execution_group_id",
                        title: "Execution Group",
                        width:"120px",
                        filterable: {
                            cell: {
                                showOperators: false,
                                operator: "contains",
                                inputWidth: 160
                            }
                        }

                    },
                    {
                        field: "application_id",
                        title: "Application",
                        width: "230px",
                        filterable: {
                            cell: {
                                showOperators: false,
                                operator: "contains",
                                inputWidth: 160
                            }
                        }

                    },
                    {
                        field: "flow_name",
                        title: "Flow",
                        width: "230px",
                        filterable: {
                            cell: {
                                showOperators: false,
                                operator: "contains",
                                inputWidth: 160
                            }
                        }
                    },
                    {
                        field: "node_count",
                        title: "N. Count",
                        width: "80px",
                        aggregates:["sum"],
                        footerTemplate:"<div style=\"text-align: right\">#=sum#</div>",
                        groupFooterTemplate:"<div style=\"text-align: right\">#=sum#</div>",
                        attributes:{style:"text-align:right;"},
                        headerAttributes:{style:"text-align:right;"},
                        filterable: false
                    },
                    {
                        field: "client_id",
                        title: "Client Id",
                        width: "130px"
                    },
                    {
                        field: "reservation_id",
                        title: "Reservation",
                        width: "150px"
                    },
                    {
                        field: "source_id",
                        title: "Source",
                        width: "100px"
                    },
                    {
                        field: "voyage_id",
                        title: "Voyage",
                        width: "100px"
                    },
                    {
                        field: "running_time",
                        title: "Running Time (seconds)",
                        aggregates:["sum"],
                        width: "180px",
                        filterable: false,
                        attributes:{style:"text-align:right;"},
                        headerAttributes:{style:"text-align:right;"},
                        footerTemplate: function(dataItem)
                        {
                            var value;
                            if (dataItem.running_time)
                                value = dataItem.running_time.sum;
                            else
                                value = dataItem.sum;
                            if (value == null)
                                return null;
                            return "<div class=\"truncate\" style=\"text-align:right\">" + $filter("secondsToStringFilter")(value.toFixed(3));
                        }
                    }
                ],
                dataBound: function(e)
                {
                    var grid = this;
                    uiSvc.dataBoundKendoGrid(grid, null);

                    // remove the vertical scroll bar
                    var gridWrapper = e.sender.wrapper;
                    gridWrapper.toggleClass("no-scrollbar", true);
                }

            };
            if (initialLoad == false)
                _this.model.transactionTable.limit  = _this.model.transactionTableLimit;


            //</editor-fold>

            //<editor-fold desc="Channel Bar Widget">
            _this.model.channelBar = {series:[], update:{value:0}, options:{}};
            _this.model.channelBar.options = {
                bars: {
                    show: true,
                    barWidth: 0.5,
                    align: "center",
                    lineWidth: 2,
                    fill:_this.model.opacity
                },

                grid : {
                    show : true,
                    hoverable : true,
                    clickable : true,
                    tickColor : "#efefef",
                    borderWidth : 0,
                    borderColor : "#DDD"
                },
                legend: false,
                tooltip : true,
                tooltipOpts : {
                    content : "<b>%x</b> = <span>%y</span>",
                    defaultTheme : false
                }
            };
            //</editor-fold>

            //<editor-fold desc="Groupings">
            _this.model.groups = {data: []};
            _this.model.groups.data.push({title:"Sources", serverProperty:"sources", chartData:[]});
            _this.model.groups.data.push({title:"Voyages", serverProperty:"voyages", chartData:[]});
            _this.model.groups.data.push({title:"Applications", serverProperty: "applications", chartData:[]});
            _this.model.groups.update = {value: 0};
            //</editor-fold>
        };

        _this.functions.parseData = function (serverData)
        {
            // routine to parse the data received from the server into a dataobject required for the view
            _this.functions.buildDonuts(serverData);
            _this.functions.buildChannelBar(serverData);
            _this.functions.buildTransactionTable(serverData);
        };
        //</editor-fold>

        //<editor-fold desc="Filter Management">
        _this.functions.toggleState = function (isRealTime, userInvoked)
        {
            // routine to handle realtime toggle
            if (userInvoked == undefined)
                userInvoked = true;

            // set the flags
            _this.model.flags.toggle = isRealTime;
            _this.model.userDateOptions.disabled = isRealTime;
            if (userInvoked && !isRealTime)   // user invoked and turn off realtime
            {
                // set the filter to what ever the user has selected
                _this.functions.applySearch();
                return; // this was called  again with the flags set byt applySearch so return
            }
            if (isRealTime)
            {
                // switching from non-realtime to realtime
                _this.model.updateType = chartSvc.dashboardStates.INITIALIZE;
                _this.model.flags.appliedUserDates = 0;
            }
            else
            {
                // switching from realtime to non-realtime
                _this.functions.cancelTimer();

                // update the dates and flags
                _this.model.updateType = chartSvc.dashboardStates.CUSTOM;

            }

            // re-initialize the dashboard now that the flag has changed
            _this.functions.init(false);
        };

        _this.functions.applySearch = function()
        {
            // routine to apply the search parameters when the user has changed the selection
            if (_this.model.flags.toggle == false)
                _this.functions.setDates();
        };

        _this.functions.setDates = function()
        {
            // routine to manage the custom search
            if (_this.model.flags.appliedUserDates == 2)
                return;

            // validate the date selection
            if (_this.model.userDateValidator != null) {
                _this.model.userDateValidator.form.validate();
                var isValid = _this.model.userDateValidator.form.isValid();
                if (!isValid)
                    return;
                var value = _this.model.userDateValidator.getValue();
                _this.functions.applyDates(value.fromDate, value.toDate);
            }
        };

        _this.functions.applyDates = function(fromDate, toDate)
        {
            // routine to apply the date selection from the user and refresh the dashboard
            _this.model.filterObject.fromDate = fromDate.set({hour: 0, minute:0, second: 0, millisecond: 0});
            _this.model.filterObject.toDate = toDate.set({hour: 23, minute:59, second: 59, millisecond: 999});
            _this.model.flags.appliedUserDates = 1;
            _this.functions.toggleState(false, false);
        };

        //</editor-fold>

        //<editor-fold desc="Dashboard Management">

        _this.functions.startNextDay = function()
        {
            // change the date when the day changes
            var now = moment();
            _this.model.userDateOptions.fromDate.maxDate = now;
            _this.model.userDateOptions.toDate.maxDate = now;
            _this.model.userDateOptions.fromDate.value = now;
            _this.model.userDateOptions.toDate.value = now;

            // update the live filter
            if (_this.model.flags.toggle)
            {
                _this.functions.toggleState(true, false);
                return;
            }
        };
        _this.functions.init = function (initialLoad)
        {
            // routine to reintialize the dashboard when the real-time flag changes or the user first comes into the view
            _this.functions.initWidgets(initialLoad);
            if (initialLoad)
            {
                userSvc.getConfig().then(function (config)
                {
                    _this.model.transactionTableLimit = lodash.get(config, _dashboardLimitConfig, 100);
                    _this.model.transactionTable.limit = _this.model.transactionTableLimit;
                    _this.functions.refreshData();
                });
            }
            else
            {
                _this.functions.refreshData();
            }
            // create a timer that runs tommorrow and every day thereafter
            var nextDay = moment().add({days: 1}).set({hour: 0, minute: 0, second: 1});
            var interval = moment.duration(nextDay.diff(moment()));
            _this.timers.dayIntervalTimer = $timeout(function()
            {
                _this.functions.startNextDay();

                _this.timers.dayTimer = $interval(function()
                {
                    _this.functions.startNextDay();

                }, 1000 * 60 * 60 * 24 );

            }, interval.asMilliseconds());
        };

        _this.functions.cancelTimer = function()
        {
            // stop the timer
            if (_this.timers.timer)
            {
                var cancelled = $interval.cancel(_this.timers.timer);
                if (cancelled)
                    _this.timers.timer = null;
            }
        };

        _this.functions.manageTimer = function()
        {
            // routine to manage the timer
            var autoUpdate =  (_this.model.updateType > chartSvc.dashboardStates.CUSTOM);
            if (!autoUpdate)
            {
                _this.functions.cancelTimer();
                if (_this.model.appliedUserDates == 1)
                    _this.model.appliedUserDates = 2;
            }
            else
            {
                // start the timer
                if (_this.timers.timer == null)
                {
                    var seconds = (appCustomConfig.runMode == uiSvc.modes.DEMO) ? 10 : 60;
                    _this.timers.timer = $interval(_this.functions.refreshData, seconds * 1000);
                }

            }
        };


        _this.functions.refreshData = function ()
        {
            // routine to request a refresh of the data from the server
            _this.model.flags.inProgress = true;
            _this.functions.updateFilters();

            // get a copy  of the filter and send it
            var requestFilter = angular.copy(_this.model.filterObject);
            requestFilter.fromDate = requestFilter.fromDate.toDate().toISOString();
            requestFilter.toDate = requestFilter.toDate.toDate().toISOString();
            // update the data
            iibv2DataSvc.refreshNCLTripDashboard(requestFilter).then(function (result)
            {

                // parse the data
                _this.functions.parseData(result);


                // update the update type if this is the first time
                if (_this.model.updateType == chartSvc.dashboardStates.INITIALIZE)
                {
                    // update the filters
                    _this.model.updateType = chartSvc.dashboardStates.INITIALIZE_COMPLETE;
                }
                _this.functions.manageTimer();

            }).catch(function (result)
            {
                $log.error("Unable to retrieve Dashboard Information", result);
            }).finally(function()
            {
                _this.model.flags.inProgress = false;
            });
        };

        _this.functions.updateFilters = function ()
        {
            // routine to update the filter object with the correct date just before calling the refresh
            _this.model.filterObject.application = _this.model.application.selected;
            if (_this.model.filterObject.application == "ALL")
                _this.model.filterObject.application = null;
            _this.model.filterObject.recordLimit = _this.model.transactionTable.limit;

            // date updates
            if (_this.model.updateType == chartSvc.dashboardStates.CUSTOM)
                return;
            if (_this.model.updateType == chartSvc.dashboardStates.INITIALIZE)
            {

                _this.model.filterObject.fromDate = moment().subtract().set({hour: 0, minute: 0, second: 0, millisecond: 0});
                _this.model.filterObject.toDate = moment().subtract({minutes: 1}).set({second: 59, millisecond: 999});   // account for a backlogged loader
                if (appCustomConfig.runMode == uiSvc.modes.DEBUG)
                {
                    _this.model.filterObject.fromDate = moment("2020-01-18 00:00:00", "YYYY-MM-DD HH:mm:ss").set({second: 59,millisecond: 999  });
                    _this.model.filterObject.toDate = moment("2020-01-18 23:30:00", "YYYY-MM-DD HH:mm:ss").set({second: 59,millisecond: 999  });
                }

                // set the user date filter back to what it needs to be incase the realtime has been switched back on
                if (_this.model.userDateValidator && _this.model.userDateValidator.setValue)
                {
                    _this.model.userDateValidator.setValue({fromDate: _this.model.filterObject.fromDate.toDate(), toDate: _this.model.filterObject.toDate.toDate()});
                };
            }

            if (_this.model.updateType == chartSvc.dashboardStates.INITIALIZE_COMPLETE)
            {
                // set the flag to realtime mode
                _this.model.updateType = chartSvc.dashboardStates.REALTIME;
            }
            if (_this.model.updateType == chartSvc.dashboardStates.REALTIME)
            {
                if (appCustomConfig.runMode == uiSvc.modes.DEMO) // demo mode
                {
                    _this.model.filterObject.toDate = moment(_this.model.filterObject.toDate).add({seconds: 10}).set({millisecond: 999});
                }
                else
                {
                    _this.model.filterObject.toDate = moment(_this.model.filterObject.toDate).add({minutes: 1}).set({second: 0, millisecond: 0});
                }
            }

        };


        $scope.$on('$destroy', function() {
            // Make sure that the interval is destroyed too
            _this.functions.cancelTimer();

            // cancel the day timer
            if (_this.timers.dayTimer != null)
            {
                $interval.cancel(_this.timers.dayTimer);
                _this.timers.dayTimer = null;
            }

            if (_this.timers.dayIntervalTimer != null)
                $interval.cancel(_this.timers.dayIntervalTimer);
        });



        //</editor-fold>

        //<editor-fold desc="Widget Data Management">
        _this.functions.buildChannelBar = function(serverData)
        {
            _this.model.channelBar.series = [];

            // now loop through the data and create a flot bar data structure -
            if (serverData.groups.channels != null)
            {
                _this.model.channelBar.series = lodash.map(serverData.groups.channels, function(series, index)
                {
                    // create the element
                    var barSeries =  {data: [], label: series._id, options:{flotJS:{color: _this.model.colors[index]}}};
                    var value = [index, series.count];
                    barSeries.data.push(value);
                    return barSeries;
                });
            }
            _this.model.channelBar.options.xaxis = function () {
                var returnObject = {ticks:[]};
                returnObject.ticks = lodash.map(_this.model.channelBar.series, function(series, index)
                {
                    return [index, series.label];
                });
                return returnObject;
            }();
            _this.model.channelBar.update.value += 1;
        };
        _this.functions.buildDonuts = function(serverData)
        {
            // routine to merge the different grouping data
            lodash.forEach(_this.model.groups.data, function(group)
            {
                //  get the data for the server property
                var serverCollection = serverData.groups[group.serverProperty];
                if (serverCollection)
                {
                    // we have data for the selected property now update the chart data
                    lodash.forEach(serverCollection, function(dataRow)
                    {
                        // try and find the record in the current dashboard chart
                        var record = lodash.find(group.chartData, {label: dataRow._id});
                        if (record)
                            record.value += dataRow.count;
                        else
                            group.chartData.push({label: dataRow._id, value: dataRow.count});
                    });
                }
            });
            _this.model.groups.update.value += 1;
        };

        _this.functions.buildTransactionTable = function(serverData)
        {

            // routine to massage the data for dashboard grid use
            var statusList = cacheDataSvc.getListForType("0", "FTEStatus");
            lodash.forEach(serverData.records, function(item)
            {
                var value = $filter("localUTCStringFilter")(item.action_date);
                item.action_date = $filter("kendoDateFilter")(value);
                item.trans_type = 0;
                if (item.status_code)
                    item.status_code = parseInt(item.status_code);
                if (item.trans_type != null)
                    item.trans_type = parseInt(item.trans_type);
                transactionReportingSvc.mapMongoStatus(item, item.status_code);
                item.status = cacheDataSvc.getListDescriptionFromArray(statusList, item.status_code);
                if (item.is_error)
                {
                    item.rowStyle = "transactionError";
                };
            });
            // routine to update the transaction table
            _this.model.transactionTable.data = serverData.records;
        };

        _this.functions.viewTransaction  = function(record)
        {
            // routine to invoke the transaction drill
            var baseState = $state.$current.parent;
            iibv2DataSvc.transactionDrill(record, baseState);
        };

        _this.functions.applyTransactionLimit = function()
        {
            // routine to update the transaction limit to the database
            userSvc.getConfig().then(function(config)
            {
                var value = parseInt(_this.model.transactionTableLimit);
                lodash.set(config, _dashboardLimitConfig, value);
                userSvc.saveConfig().then(function()
                {
                    uiSvc.showExtraSmallPopup("User Configuration Update", "User Configuration Update Successful !", 5000);
                    _this.model.transactionTable.limit = value;
                    _this.functions.toggleTableSettings();
                    _this.functions.refreshData();
                }).catch(function(err)
                {
                    uiSvc.showError("User Config Update Failure", err)
                })
            }).catch(function (reason)
            {
                $log.error("Config Read Failure", reason);
            });
        };

        _this.functions.toggleTableSettings = function ()
        {
            if (_this.model.flags.showTableSettings == true)
                _this.model.flags.showTableSettings = false;
            else
                _this.model.flags.showTableSettings = true;
        };

        //</editor-fold>

        // get the initial data on controller instantiation
        _this.functions.initializeVariables();
        _this.functions.init(true);
    }]);
});
