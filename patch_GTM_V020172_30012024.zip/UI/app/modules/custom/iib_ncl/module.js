/*
 /// <summary>
 /// app.modules.custom.iib_ncl - module.js
 /// IIB Module Bootstrapper
 /// NCL Customizations
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 07/05/2018
 /// </summary>
 */
define([
    'angular',
    'angular-couch-potato',
    'angular-ui-router',
    'angular-resource',
    'modules/common/module',
    'modules/iib_v2/module',
    'modules/custom/iib_ncl/module'
], function (ng, couchPotato) {
    'use strict';

    var module = ng.module('app.mqacustom.iib_ncl', ['ui.router','ngResource','app.mqacommon', 'app.mqaiib_v2']);
    var stateProvider;
    var couchProvider;


    module.config(function ($stateProvider, $couchPotatoProvider)
    {
        stateProvider = $stateProvider;
        couchProvider = $couchPotatoProvider;
        $stateProvider
            .state('app.custom.iib_ncl', {
                abstract: true,
                url: '/iib_ncl',
                views: {

                    "nav@app":
                    {
                        controller: 'iibv2NavigationCtrl',
                        templateUrl: 'app/modules/custom/iib_ncl/partials/navigation.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/iib_v2/controllers/iibv2NavigationCtrl',
                                'modules/iib_v2/services/iibv2DataSvc',
                                'modules/common/services/chartSvc',
                                'modules/iib_v2/services/iibv2DataSvc'
                                ])

                        }
                    },
                    "content@app":
                    {
                        templateUrl: 'app/modules/layout/partials/module-header.tpl.html'
                    },
                    "realtime@content":
                    {
                        controller: 'iibv2RealtimeCtrl',
                        controllerAs: 'realtime',
                        templateUrl: 'app/modules/iib_v2/partials/realtime-header.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/iib_v2/controllers/iibv2RealtimeCtrl'
                            ])
                        }
                    }
                },
                data:{
                    title: '' +
                        'App Connect Enterprise', module: 'iib', security:['iib'], module_id:"iib"

                }})

            .state('app.custom.iib_ncl.dashboard', {
                url: '/dashboard'
            })
            .state('app.custom.iib_ncl.dashboard.transaction', {
                url: '/transaction',
                views: {
                    "content@app":
                        {
                            controller: 'iibv2TransactionDashboardCtrl',
                            templateUrl: 'app/modules/iib_v2/partials/transaction-dashboard.tpl.html',
                            controllerAs: 'transDashboard',
                            resolve: {
                                deps: $couchPotatoProvider.resolveDependencies([
                                    'modules/common/directives/graphs/mqaChartjs',
                                    'modules/common/directives/input/mqaJqSmallDateRangePicker',
                                    'modules/common/directives/ui/mqaDashboardCount',
                                    'modules/iib_v2/controllers/iibv2TransactionDashboardCtrl',
                                    'modules/iib_v2/directives/iibTransactionDashboardCount',
                                    'modules/iib_v2/directives/iibTransactionDashboardApplicationChart'
                                ])

                            }
                        }
                },
                data:{
                    title: 'Transaction Dashboard'
                }
            })

            .state('app.custom.iib_ncl.dashboard.trip', {
                url: '/trips',
                views: {
                    "content@app":
                        {
                            controller: 'nclTripDashboardCtrl',
                            templateUrl: 'app/modules/custom/iib_ncl/partials/trip-dashboard.tpl.html',
                            controllerAs: 'dashboard',
                            resolve: {
                                deps: $couchPotatoProvider.resolveDependencies([
                                    'modules/common/directives/graphs/mqaChartjs',
                                    'modules/common/directives/input/mqaJqSmallDateRangePicker',
                                    'modules/custom/iib_ncl/controllers/nclTripDashboardCtrl',
                                    'modules/common/directives/tables/mqaDataTable'
                                ])

                            }
                        }
                },
                data:{
                    title: 'Trips Dashboard'
                }
            })

            .state('app.custom.iib_ncl.reporting.transaction',
            {
                abstract: true,
                url: '/transaction',
                views:
                {
                    "innerContent@content":
                    {
                        controller: 'iibv2TransactionReportingCtrl',
                        controllerAs: 'vm',
                        templateUrl: 'app/modules/transaction-reporting/partials/transaction-reporting-layout.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/iib_v2/controllers/iibv2TransactionReportingCtrl'
                            ])

                        }
                    },
                    "footerContent@content":
                    {
                        template:'<div></div>'
                    }
                },
                data:
                {
                    title:'Transaction Reporting'
                }
            })
            .state("app.custom.iib_ncl.reporting.transaction.gridview",{
                url: '/gridview?settingId',
                views:            {
                    "tabContent@content": {
                        controller: 'iibv2TransactionReportingGridViewCtrl',
                        controllerAs: 'vmgrid',
                        templateUrl: 'app/modules/iib_v2/partials/transaction-reporting-gridview.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/iib_v2/controllers/iibv2TransactionReportingGridViewCtrl',
                                'modules/iib_v2/directives/mqaIibAppGrid'
                            ])
                        }
                    },
                    "filterContent@content": {
                        controller: 'iibv2TransactionReportingAppFilterCtrl',
                        controllerAs: 'vmFilter',
                        templateUrl: 'app/modules/iib_v2/partials/transaction-reporting-app-filter.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/iib_v2/controllers/iibv2TransactionReportingAppFilterCtrl',
                                'modules/iib_v2/directives/mqaIibAppGrid'
                            ])
                        }
                    }
                },
                data: {
                    settings: {
                        code: "REP103_001",
                        type: 3,
                        description: "Transaction Listing",
                        notes: "List of Transactions",
                        reloadState: ".reporting.transaction",
                    }
                }
            })

    });

    couchPotato.configureApp(module);

    module.run(['$couchPotato', 'transactionReportingSvc',  function($couchPotato, transactionReportingSvc)
    {
        module.lazy = $couchPotato;
        transactionReportingSvc.createDetailRoutes("app.custom.iib_ncl", stateProvider, couchProvider);
    }]);
    return module;
});