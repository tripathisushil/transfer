
/*
 /// <summary>
 /// modules.custom.iib_ncl.directives.input - nclDashboardFilter.js
 /// Directive to Manage date and application selection within the NCL Dashboard
 /// This is a rehash of the mqajqFilter - this dashboard will be reworked later
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 23/03/2019
 /// </summary>
 */

define(['modules/common/module', 'lodash', 'moment','bootstrap-validator'], function(module, lodash, moment){
    "use strict";
    moment().format();


    module.registerDirective('nclDashboardFilter', ['$timeout', 'jqueryuiSvc', 'userSvc', function($timeout, jqueryuiSvc, userSvc){

    return {
        restrict: 'E',
        templateUrl: 'app/modules/custom/iib_ncl/directives//nclDashboardFilter.tpl.html',
        scope:{},
        bindToController:{
            onExecute:'&',
            options:"="
        },
        controllerAs:'filter',
        controller: function ($element, $scope)
        {
           var _this = this;

            var bv = null;
            var setupBV = function () {
                // routine to setup bootstrap validator for this form
                var fromDate = {
                    fields: {
                        dateRange_fromDate: {
                            excluded: false,
                            validators: {
                                date: {
                                    message: "The From Date is Invalid",
                                    max: "dateRange_toDate"
                                },
                                notEmpty: {
                                    message: 'From Date is Mandatory'
                                },
                                callback: {
                                    callback: function (value, validator, $field)
                                    {
                                        // check if the date > maxDate or > the to Date
                                        var currdate = moment(value).toDate().getTime();
                                        if (_this.vm.fromDate.options.maxDate)
                                        {
                                            var maxDate = _this.vm.fromDate.options.maxDate;
                                            if (currdate > maxDate.getTime())
                                                return {valid:false, message: "Date Cannot be Greater than Today"};
                                        }
                                        if (_this.vm.toDate.value != null)
                                        {
                                            var compareDate = moment(_this.vm.toDate.value).toDate().getTime();
                                            if (currdate > compareDate)
                                                return {valid:false, message:"From Date cannot be Greater than To Date"};
                                        }
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                };
                var toDate = {
                    fields: {
                        dateRange_toDate: {
                            excluded: false,
                            validators: {
                                date: {
                                    message: "The To Date is Invalid",
                                    min:"dateRange_fromDate"
                                },
                                notEmpty: {
                                    message: 'To Date is Mandatory'
                                },
                                callback: {
                                    message: 'To Date cannot be Less than From Date',
                                    callback: function (value, validator, $field)
                                    {
                                        // check if the date > maxDate or < the from Date
                                        var currdate = moment(value).toDate().getTime();
                                        if (_this.vm.toDate.options.maxDate)
                                        {
                                            var maxDate = _this.vm.toDate.options.maxDate;
                                            if (currdate > maxDate.getTime())
                                                return {valid:false, message: "Date Cannot be Greater than Today"};
                                        }
                                        if (_this.vm.fromDate.value != null)
                                        {
                                            var compareDate = moment(_this.vm.fromDate.value).toDate().getTime();
                                            if (currdate < compareDate)
                                            {
                                                return {valid: false, message:"To Date cannot be Less than From Date"};
                                            }
                                        }
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                };
                var application = {
                    fields: {
                        app: {
                            excluded: false,
                            group: "#div_application",
                            validators: {
                                callback: {
                                    callback: function (value, validator, $field) {
                                        return _this.vm.functions.validateCombo(_this.vm.application, 'Application Cannot be Empty')
                                    }
                                }
                            }
                        }
                    }
                };

                var fields = lodash.merge(fromDate, toDate, application);
                var formOptions = lodash.merge({}, fields,  {submitButtons: 'button[id="filter_submit"]'}, jqueryuiSvc.getFormNoFeedbackIcons());
                var fv = $element.bootstrapValidator(formOptions);
                bv = $element.data('bootstrapValidator');
            };
            

            // setup the variables
            _this.vm = {fromDate: {value: null, options: {}}, toDate: {value: null, options: {}}, application: null};
            var orgInfo = userSvc.getOrgInfo();
            _this.vm.companyId =  orgInfo.companyId;

            _this.vm.functions = {};
            _this.vm.functions.validateCombo = function(modelValue, message)
            {
                // routine to validate the ui- select combo and return the result to bv
                var returnObj = {message: message, valid: true};
                if (modelValue)
                {
                    returnObj.valid = (modelValue !== "");
                }
                else
                    returnObj.valid = false;
                return returnObj;
            };

            // setup the dates based on the options provided
            if (_this.options.fromDate)
            {
                if (_this.options.fromDate.maxDate) {
                    _this.vm.fromDate.options.maxDate = _this.options.fromDate.maxDate.toDate();
                }
                if (_this.options.fromDate.defaultDate)
                    _this.vm.fromDate.options.defaultDate = _this.options.fromDate.defaultDate.toDate();
                if (_this.options.fromDate.value)
                    _this.vm.fromDate.value = _this.options.fromDate.value.format("l");
            }
            if (_this.options.toDate)
            {
                if (_this.options.toDate.maxDate)
                {
                    _this.vm.toDate.options.maxDate = _this.options.toDate.maxDate.toDate();
                }
                if (_this.options.toDate.defaultDate)
                    _this.vm.toDate.options.defaultDate = _this.options.toDate.defaultDate.toDate();
                if (_this.options.toDate.value)
                    _this.vm.toDate.value = _this.options.toDate.value.format("l");
            }
            if (_this.options.app.value)
                _this.vm.application = _this.options.app.value;


            // check if there is an inprogress watch variable
            _this.vm.inProgress = null;

            // watch the options
            $scope.$watch("filter.options", function(newValue, oldValue)
            {
                // check for a progress update
                if (newValue == undefined)
                    return;
                if (newValue.inProgress != undefined && (newValue.inProgress != oldValue.inProgress))
                {
                    _this.vm.inProgress = newValue.inProgress;
                }

                // check for a clear update
                if (newValue.clear != undefined && (newValue.clear != oldValue.clear))
                {
                    _this.vm.fromDate.value = null;
                    _this.vm.toDate.value = null;
                    if (bv)
                    {
                        bv.resetField("application", true);
                        bv.resetField("dateRange_fromDate", true);
                        bv.resetField("dateRange_toDate", true);
                    }
                }

                // check for a maxDate update
                if (newValue.fromDate.maxDate != undefined && (newValue.fromDate.maxDate != oldValue.fromDate.maxDate))
                {
                    _this.vm.fromDate.options.maxDate = newValue.fromDate.maxDate.toDate();

                }
                if (newValue.toDate.maxDate != undefined && (newValue.toDate.maxDate != oldValue.toDate.maxDate))
                {
                    _this.vm.toDate.options.maxDate = newValue.toDate.maxDate.toDate();
                }
            }, true);
            if (_this.options.inProgress != undefined)
            {
                $scope.$watch("filter.options.inProgress", function(newValue, oldValue)
                {
                    if (newValue != oldValue)
                        _this.vm.inProgress = newValue;
                }, true);
            }

            // check if a clear has been invoked
            $scope.$watch("filter.options.clear", function(newValue, oldValue)
            {
                if (newValue != oldValue)
                {
                }
            }, true);


            // setup the functions
            _this.vm.functions.onFromDate = function(selectedDate)
            {
                if (bv)
                    bv.revalidateField("dateRange_fromDate");
            };
            _this.vm.functions.onComboChange = function(fieldName)
            {
                // routine to revalidate the field when a combo Changes
                if (bv)
                    bv.revalidateField(fieldName);
            };

            _this.vm.functions.onToDate = function(selectedDate)
            {
                if (bv)
                    bv.revalidateField("dateRange_toDate");
            };
            _this.vm.functions.execute = function()
            {
                // validate the form
                bv.enableFieldValidators("dateRange_fromDate", true);
                bv.enableFieldValidators("dateRange_toDate", true);
                bv.enableFieldValidators("app", true);
                bv.validate();
                var isValid = bv.isValid();
                if (!isValid)
                {
                    return;
                }
                if (_this.vm != null)
                    _this.vm.inProgress = true;
                _this.onExecute()(moment(_this.vm.fromDate.value), moment(_this.vm.toDate.value), _this.vm.application);

            };


            // setup BV  when this form loads
            $timeout(function()
            {
                setupBV();
            }, 500);

        }
    }
  }]);

});


