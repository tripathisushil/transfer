/*
 /// <summary>
 /// app.modules.custom.mckclmxtent.services - mckClmXtentDataSvc.js
 /// Client Implementation of the Server Side Mckesson Claims Xtent Data Service
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 28/7/2015
 /// </summary>
 */
define(['modules/custom/mckclmxtent/module','lodash'], function(module, lodash)
{
    "use strict";
    module.registerService('mckClmXtentDataSvc',[function()
    {
        // dummy data for now when we get signal-r working - this will be populated by signalr
        var stats = {};
        stats.transactions = {value: 20, chartData:[110,150,300,130,400,240,220,310,220,300, 270, 210]};
        stats.claims = {value: 10, chartData:[110,150,300,130,400,240,220,310,220,300, 270, 210]};


        this.chartColors = {
            "progress": "#c79121",
            "success": "#69a9ff",
            "error": "#B20000"
        };

        this.stats = stats;


    }]);
});
