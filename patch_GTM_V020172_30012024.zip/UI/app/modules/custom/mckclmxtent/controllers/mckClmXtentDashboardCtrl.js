/*
 /// <summary>
 /// app.modules.custom.mckclmxtent.controllers - mckClmXtentNavigationCtrl.js
 /// Base Mckesson Claims XTent Navigation Controller
 /// Abstract Controller that is the parent of all Mckesson Claims XTent Module Screens - this will manage Signal-R Listeners amongst other things
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 28/7/2015
 /// </summary>
 */
define(['modules/custom/mckclmxtent/module', 'moment', 'lodash'], function (module, moment, lodash) {

	"use strict";
	moment().format();


	module.registerController('mckClmXtentDashboardCtrl', ['$scope', '$log', 'apiSvc', 'apiProvider', 'transactionReportingSvc', 'mckClmXtentDataSvc', function ($scope, $log, apiSvc, apiProvider, transactionReportingSvc, mckClmXtentDataSvc) {


		// initialize the base variables
		$scope.errorsCollapsed = true;
		$scope.data = [];
		$scope.gridData = [];

		// initialize the filter object
		var now = new Date();
		$scope.dateRange = {};
		$scope.dateRange.fromDate = now;
		$scope.dateRange.toDate = now;
		$scope.filter = {};
		var docType = transactionReportingSvc.getDocumentType();
		if (docType) {
			$scope.filter.docTypes = [];
			$scope.filter.docTypes.push(docType.code);
		}

		$scope.timeColors = ["#57889c", "#800517"];

        $scope.applyCustomSearch = function(fromDate, toDate)
        {
            // routine to manage the date selection by the user
            $scope.filter.fromDate = fromDate.set({hour: 0, minute:0, second: 0, millisecond: 0}).toDate();
            $scope.filter.toDate = toDate.set({hour: 23, minute:59, second: 59, millisecond: 999}).toDate();
            $scope.refreshData();
        };


        $scope.refreshData = function ()
		{
			// routine to formulate the filter object based on the current scope and send the filter object to the server for processing
            $scope.userDateOptions.inProgress = true;
			var filterObject = {};
			angular.copy($scope.filter, filterObject);

			// now update the dates
            filterObject.fromDate =  filterObject.fromDate.toISOString();
            filterObject.toDate = filterObject.toDate.toISOString();

			// now search for the data
			apiProvider.getList('mftSearch', filterObject).then(function (result)
			{
				$scope.data = result;
				$scope.gridData = transactionReportingSvc.parseKendoGridData(lodash.cloneDeep(result));
			}).catch(function (result) {
				$log.error("Unable to retrieve Transaction Data", result);
			}).finally(function()
    		{
        		$scope.userDateOptions.inProgress = false;
    		});
		};

        // get the initial data on controller instantiation for today
        var now = moment();
        $scope.userDateOptions = {inProgress: false, clear: 0, fromDate:{maxDate: now}, toDate:{maxDate: now}};
        $scope.userDateOptions.fromDate.value = now;
        $scope.userDateOptions.toDate.value = now;
		$scope.userDateValidator = {};
		$scope.applyCustomSearch(now, now);

	}]);
});
