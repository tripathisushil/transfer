/*
 /// <summary>
 /// app.modules.custom.mckclmxtent.controllers - mckClmXtentRealtimeCtrl.js
 /// Controller to manage realtime statistics for the Mckesson Claims XTent Module
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 28/7/2015
 /// </summary>
 */
define(['modules/custom/mckclmxtent/module'], function (module) {

	"use strict";

	module.registerController('mckClmXtentRealtimeCtrl', ['$scope', 'chartSvc', 'mckClmXtentDataSvc', function ($scope, chartSvc, mckClmXtentDataSvc) {

		// set a scope variable to the entire dataservice that way when the service variables get used on the view - angular will create a watch on service variables
		$scope.dataSvc = mckClmXtentDataSvc;

		// setup the chart configuration for sparkline
		$scope.chartConfig = {};
		$scope.chartConfig.claims = chartSvc.sparkLineBase.bar;
		$scope.chartConfig.transactions = chartSvc.sparkLineBase.bar;
	}]);
});
