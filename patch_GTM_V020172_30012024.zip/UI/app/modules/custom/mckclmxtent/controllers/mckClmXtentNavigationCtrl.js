/*
 /// <summary>
 /// app.modules.custom.mckclmxtent.controllers - mckClmXtentNavigationCtrl.js
 /// Base Mckesson Claims XTent Navigation Controller
 /// Abstract Controller that is the parent of all Mckesson Claims XTent Module Screens - this will manage Signal-R Listeners amongst other things
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 28/7/2015
 /// </summary>
 */
define(['modules/custom/mckclmxtent/module'], function (module) {

	"use strict";

	module.registerController('mckClmXtentNavigationCtrl', ['$scope', 'transactionReportingSvc', function ($scope, transactionReportingSvc)
	{
       // update the transaction reporting service
       transactionReportingSvc.reset(0);
       $scope.documentTypeId = transactionReportingSvc.documentType.code;
	}]);
});
