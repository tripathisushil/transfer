/*
 /// <summary>
 /// app.modules.custom.mckclmxtent.directives - mqaMckClmXtentCounts
 /// Directive to display the Mckesson Claims XTent Counts for the data provided

 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 7/18/2015
 /// </summary>
 */

define(['modules/custom/mckclmxtent/module', 'lodash'], function(module, lodash) {
  "use strict";

  module.registerDirective('mqaMckClmXtentCounts', ['$state', 'chartSvc','mckClmXtentDataSvc', 'mftChartSvc', 'transactionReportingSvc', function($state, baseChartSvc, dataSvc, mftChartSvc, transactionReportingSvc){
    return {
        restrict: 'E',
        scope:
        {
            data:'=',
            gridData:'=grid'
        },
        templateUrl: "app/modules/custom/mckclmxtent/directives/mqaMckClmXtentCounts.tpl.html",
        link: function ($scope, element, attributes)
        {
            // claims drill fields
            $scope.claimsCollapsed = true;
            $scope.claimsData = [];
            $scope.claimsFields = [];
            $scope.claimsFields.push({name: "claimid", description: "Claim Number", source: "docId", type: "string", tooltip: false, width: 300});
            $scope.claimsFields.push({name: "jobname", description: "Job Name", source: "jobName", type:"string", tooltip: false, width: 300});
            $scope.claimsFields.push({name: "result", description: "Result", source: "supplementalStatus", type:"string", tooltip: true, width: 400});

            // errors drill fields
            $scope.errorsCollapsed = true;
            $scope.errorsData = [];
            $scope.errorsFields = [];
            $scope.errorsFields.push({name: "claimid", description: "Claim Number", source: "docId", type: "string", tooltip: false, width: 300});
            $scope.errorsFields.push({name: "jobname", description: "Job Name", source: "jobName", type:"string", tooltip: false, width: 300});
            $scope.errorsFields.push({name: "result", description: "Result", source: "supplementalStatus", type:"string", tooltip: true, width: 400});


            $scope.statusDrill = function(i, row)
            {
                // routine to manage the drill on the status morris chart
                if (row && row.label == "Errors")
                    $scope.errorsCollapsed = !$scope.errorsCollapsed;
            };

            $scope.transactionDetailDrill = function(model)
            {
                // routine to invoke the transaction drill
                var baseState = $state.$current.parent;
                var record = {transactionId: model.transactionId, transactionType: model.mqaModule};
                transactionReportingSvc.navigateTransaction(baseState.name + ".reporting.transactionDetail.docview", record);
            };

            var updateData = function()
            {
                // routine to update the values when the data changes
                $scope.transactionCount = 0;
                $scope.documentCount = 0;
                $scope.metricList = [];
                $scope.metricData = [];
                $scope.colorPalette = ['#a57225', '#3D52D5', '#B5B1B2'];

                $scope.metricList.push({label:"Successful", color: "#3D52D5", summary: mftChartSvc.chartSummaries.completed, clickparams: 1});
                $scope.metricList.push({label:"In-Progress", color: dataSvc.chartColors.progress, summary: mftChartSvc.chartSummaries.inProgress, clickparams: 2});
                $scope.metricList.push({label:"Errors", color: dataSvc.chartColors.error, summary: mftChartSvc.chartSummaries.error, clickparams: 3});

                $scope.$watchCollection("gridData", function(newValue, oldValue)
                {
                    // routine to rebuild the grids when the data changes
                    if (newValue != oldValue)
                    {
                        $scope.claimsData = lodash.uniq($scope.gridData, function(record)
                        {
                            if (record.docId)
                                return record.docId;
                        });
                        $scope.documentCount = $scope.claimsData.length;
                    }
                });
                $scope.$watchCollection("data", function(newValue, oldValue)
                {
                    // routine to rebuild the view when the data changes
                    if (newValue != oldValue)
                    {
                        $scope.metricData = [];
                        var total = lodash.reduce($scope.data, mftChartSvc.chartSummaries.count.reduceFunction, mftChartSvc.chartSummaries.count.reduceBase);
                        lodash.forEach($scope.metricList, function(metric)
                        {
                            $scope.metricData.push({value: lodash.reduce($scope.data, metric.summary.reduceFunction, mftChartSvc.chartSummaries.count.reduceBase), label: metric.label, color: metric.color });
                        });
                        var errors = lodash.filter($scope.data, mftChartSvc.chartSummaries.error.filterFunction);
                        $scope.errorsData = transactionReportingSvc.parseKendoGridData(lodash.cloneDeep(errors));
                        $scope.transactionCount =  total;
                    }
               });

            };
            updateData();
        }
    }
  }]);

});


