/*
 /// <summary>
 /// app.modules.custom.hix - module.js
 /// Emblem Health HIX Module Bootstrapper
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 6/28/2015
 /// </summary>
 */
define([
    'angular',
    'angular-couch-potato',
    'angular-ui-router',
    'angular-resource',
    'modules/common/module',
    'modules/mft/module',
    'modules/custom/hix/module',


], function (ng, couchPotato) {
    'use strict';

    var module = ng.module('app.mqacustom.hix', ['ui.router','ngResource','app.mqacommon', 'app.mqamft']);
    var stateProvider;
    var couchProvider;


    module.config(function ($stateProvider, $couchPotatoProvider)
    {
        stateProvider = $stateProvider;
        couchProvider = $couchPotatoProvider;
        $stateProvider
            .state('app.custom.hix',
            {
                abstract: true,
                url: '/hix',
                views:
                {
                    "nav@app": {
                        controller: 'hixNavigationCtrl',
                        templateUrl: 'app/modules/custom/hix/partials/navigation.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/custom/hix/controllers/hixNavigationCtrl',
                                'modules/custom/hix/services/hixDataSvc',
                                'modules/mft/services/mftChartSvc',
                                'modules/mft/services/mftDataSvc'
                            ])
                        }
                    },
                    "content@app":
                    {
                        templateUrl: 'app/modules/layout/partials/module-header.tpl.html'
                    },
                    "realtime@content":
                    {
                        controller: 'hixRealtimeCtrl',
                        templateUrl: 'app/modules/custom/hix/partials/realtime-header.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/custom/hix/controllers/hixRealtimeCtrl'
                            ])
                        }
                    }
                },
                data:
                {
                    title: 'HIX Interface', module: 'HIX Documents'
                }
            })
            .state('app.custom.hix.reporting.transaction',
            {
                abstract: true,
                url: '/transaction',
                views:
                {
                    "innerContent@content":
                    {
                        controller: 'mftTransactionReportingCtrl',
                        templateUrl: 'app/modules/transaction-reporting/partials/transaction-reporting-layout.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/mft/controllers/mftTransactionReportingCtrl'
                            ])

                        }
                    },
                    "filterContent@content":
                    {
                        templateUrl:'app/modules/mft/partials/transaction-reporting-filter.tpl.html'
                    },
                    "footerContent@content":
                    {
                        templateUrl:'app/modules/custom/hix/partials/transaction-reporting-footer.tpl.html'
                    }
                },
                data:
                {
                    title:'Transaction Reporting'
                }
            })
            .state("app.custom.hix.reporting.transaction.gridview",{
                    url: '/gridview',
                    views: {
                        "tabContent@content": {
                            controller: 'transactionReportingGridViewCtrl',
                            templateUrl: 'app/modules/transaction-reporting/partials/transaction-reporting-gridview.tpl.html',
                            resolve:  {
                                deps: $couchPotatoProvider.resolveDependencies([
                                    'modules/transaction-reporting/controllers/transactionReportingGridViewCtrl'
                            ])
                         }
                    }
                }
             })
            .state('app.custom.hix.dashboard', {
                url: '/dashboard',
                views: {
                    "innerContent@content":
                    {
                        controller: 'hixDashboardCtrl',
                        templateUrl: 'app/modules/custom/hix/partials/dashboard.tpl.html',
                        resolve: {
                            deps: $couchPotatoProvider.resolveDependencies([
                                'modules/custom/hix/controllers/hixDashboardCtrl',
                                'modules/custom/hix/directives/mqaHixCounts',
                                'modules/custom/hix/directives/mqaHixMemberStats',
                                'modules/custom/hix/directives/mqaHixTimeStats',
                                'modules/custom/hix/directives/mqaHixDocTimeStats'
                            ])
                        }

                    }
                },
                data:{
                    title: 'Dashboard'
                }
            })
    });

    couchPotato.configureApp(module);

    module.run(['$couchPotato', 'transactionReportingSvc',  'uiSvc', function($couchPotato, transactionReportingSvc, uiSvc)
    {
        module.lazy = $couchPotato;
        transactionReportingSvc.createDetailRoutes("app.custom.hix", stateProvider, couchProvider);
        var viewStates = uiSvc.initializeMFTViewStates(couchProvider);
        uiSvc.createViewStates("app.custom.hix", stateProvider, viewStates);
    }]);

    return module;
});