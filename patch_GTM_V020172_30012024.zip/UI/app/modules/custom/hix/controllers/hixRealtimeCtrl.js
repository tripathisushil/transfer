/*
 /// <summary>
 /// app.modules.custom.hix.controllers - hixRealtimeCtrl.js
 /// Controller to manage realtime statistics for the HIX Module
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 28/6/2015
 /// </summary>
 */
define(['modules/custom/hix/module'], function (module) {

	"use strict";

	module.registerController('hixRealtimeCtrl', ['$scope', 'chartSvc', 'hixDataSvc', function ($scope, chartSvc, hixDataSvc) {

		// set a scope variable to the entire dataservice that way when the service variables get used on the view - angular will create a watch on service variables
		$scope.dataSvc = hixDataSvc;

		// setup the chart configuration for sparkline
		$scope.chartConfig = {};
		$scope.chartConfig.policies = chartSvc.sparkLineBase.bar;
		$scope.chartConfig.members = chartSvc.sparkLineBase.bar;
		$scope.chartConfig.documents = chartSvc.sparkLineBase.bar;
		$scope.chartConfig.transactions = chartSvc.sparkLineBase.bar;
	}]);
});
