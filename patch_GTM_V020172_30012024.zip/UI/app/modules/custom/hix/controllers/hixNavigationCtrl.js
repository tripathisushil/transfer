/*
 /// <summary>
 /// app.modules.custom.hix.controllers - hixNavigationCtrl.js
 /// Base HIX Navigation Controller
 /// Abstract Controller that is the parent of all HIX Module Screens - this will manage Signal-R Listeners amongst other things
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 6/28/2015
 /// </summary>
 */
define(['modules/custom/hix/module'], function (module) {

	"use strict";

	module.registerController('hixNavigationCtrl', ['$scope', 'transactionReportingSvc', function ($scope, transactionReportingSvc)	{

	  // update the transaction reporting service
      transactionReportingSvc.reset(0);
      $scope.documentTypeId = transactionReportingSvc.documentType.code;
	}]);
});
