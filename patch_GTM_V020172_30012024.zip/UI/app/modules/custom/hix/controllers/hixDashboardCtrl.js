/*
 /// <summary>
 /// app.modules.custom.hix.controllers - hixNavigationCtrl.js
 /// Base HIX Navigation Controller
 /// Abstract Controller that is the parent of all HIX Module Screens - this will manage Signal-R Listeners amongst other things
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 6/28/2015
 /// </summary>
 */
define(['modules/custom/hix/module', 'moment'], function (module, moment) {

	"use strict";
	moment().format();


	module.registerController('hixDashboardCtrl', ['$scope', '$log', 'apiSvc', 'apiProvider', 'transactionReportingSvc','hixDataSvc', function ($scope, $log, apiSvc, apiProvider, transactionReportingSvc, hixDataSvc) 	{

		// initialize the filter object
		$scope.filter = {};
		var docType = transactionReportingSvc.getDocumentType();
		if (docType)
		{
			$scope.filter.docTypes = [];
			$scope.filter.docTypes.push(docType.code);
		}

		// initialize other variables
		$scope.colorPalette = ['#a57225', '#3D52D5', '#496949', '#6e3671'];


        $scope.applyCustomSearch = function(fromDate, toDate)
        {
            // routine to manage the date selection by the user
            $scope.filter.fromDate = fromDate.set({hour: 0, minute:0, second: 0, millisecond: 0}).toDate();
            $scope.filter.toDate = toDate.set({hour: 23, minute:59, second: 59, millisecond: 999}).toDate();
            $scope.refreshData();
        };

        $scope.refreshData = function ()
		{
			// routine to formulate the filter object based on the current scope and send the filter object to the server for processing
            $scope.userDateOptions.inProgress = true;
            var filterObject = {};
			angular.copy($scope.filter, filterObject);

			// now update the dates
			filterObject.fromDate =  filterObject.fromDate.toISOString();
			filterObject.toDate = filterObject.toDate.toISOString();

			// now search for the data
			apiProvider.getList('mftSearch', filterObject).then(function (result)
			{
				$scope.data = result;

				// now because the vendor data is comma delimited - we need to break it down
				$scope.actionData = hixDataSvc.getActionCodeList($scope.data);

			}).catch(function (result) {
				$log.error("Unable to retrieve Transaction Data", result);
			}).finally(function()
			{
                $scope.userDateOptions.inProgress = false;
			});
		};

		// get the initial data on controller instantiation for today
		var now = moment();
        $scope.userDateOptions = {inProgress: false, clear: 0, fromDate:{maxDate: now}, toDate:{maxDate: now}};
        $scope.userDateOptions.fromDate.value = now;
		$scope.userDateOptions.toDate.value = now;
		$scope.userDateValidator = {};
		$scope.applyCustomSearch(now, now);
	}]);
});
