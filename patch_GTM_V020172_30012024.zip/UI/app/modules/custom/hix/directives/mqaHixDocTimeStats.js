/*
 /// <summary>
 /// modules.custom.hix.directives - mqaHixDocTimeStats
 /// Directive to display the HIX Document Processing Time Stats for the Data Provided

 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 7/18/2015
 /// </summary>
 */

define(['modules/custom/hix/module', 'lodash'], function(module, lodash) {
  "use strict";

  module.registerDirective('mqaHixDocTimeStats', ['$filter', 'hixDataSvc', 'mftChartSvc', function($filter, hixDataSvc, mftChartSvc){
    return {
        restrict: 'E',
        scope:
        {
            data:'='
        },
        templateUrl: "app/modules/custom/hix/directives/mqaHixDocTimeStats.tpl.html",
        link: function ($scope, element, attributes)
        {
            var updateData = function()
            {
                $scope.minValue = 0;
                $scope.maxValue = 0;
                $scope.avgValue = 0;
                if (!$scope.data || !$scope.data.length)
                    return;

                // routine to update the values when the data changes
                var timeArray = lodash.chain($scope.data).groupBy("docId").map(function(values, key)
                {
                    return lodash.reduce(values, mftChartSvc.chartSummaries.time.reduceFunction, mftChartSvc.chartSummaries.time.reduceBase);
                }).value();

                // now get the values
                $scope.minValue = $filter('secondsToStringFilter')(lodash.min(timeArray));
                $scope.maxValue = $filter('secondsToStringFilter')(lodash.max(timeArray));
                $scope.avgValue = $filter('secondsToStringFilter')((lodash.sum(timeArray) / timeArray.length));
            };
            $scope.$watchCollection("data", function()
            {
                updateData();
            });
            updateData();
        }
    }
  }]);

});


