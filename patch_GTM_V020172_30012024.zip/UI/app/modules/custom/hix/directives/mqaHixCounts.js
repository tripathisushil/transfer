/*
 /// <summary>
 /// modules.custom.hix.directives - mqaHixCounts
 /// Directive to display the HIX Counts for the data provided

 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 7/18/2015
 /// </summary>
 */

define(['modules/custom/hix/module', 'lodash'], function(module, lodash) {
  "use strict";

  module.registerDirective('mqaHixCounts', ['hixDataSvc', function(hixDataSvc){
    return {
        restrict: 'E',
        scope:
        {
            data:'='
        },
        templateUrl: "app/modules/custom/hix/directives/mqaHixCounts.tpl.html",
        link: function ($scope, element, attributes)
        {
            var updateData = function()
            {
                // routine to update the values when the data changes
                $scope.policyCount = 0;
                $scope.documentCount = 0;
                $scope.transactionCount = 0;
                if (!$scope.data || !$scope.data.length)
                    return;
                $scope.policyCount = lodash.chain($scope.data).filter(function(record)
                {
                    return hixDataSvc.hasPolicyNumber(record);
                }).uniq(function(record){
                    return hixDataSvc.getPolicyNumber(record);
                }).value().length;
                $scope.documentCount = lodash.uniq($scope.data,  function(record){
                    return record.docId;
                }).length;
                $scope.transactionCount = $scope.data.length;
            };
            $scope.$watchCollection("data", function()
            {
                updateData();
            });
            updateData();
        }
    }
  }]);

});


