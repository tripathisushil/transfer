/*
 /// <summary>
 /// modules.custom.hix.directives - mqaHixMemberStats
 /// Directive to display the HIX Member Stats for the data provided

 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 7/18/2015
 /// </summary>
 */

define(['modules/custom/hix/module', 'lodash'], function(module, lodash) {
  "use strict";

  module.registerDirective('mqaHixMemberStats', ['hixDataSvc', function(hixDataSvc){
    return {
        restrict: 'E',
        scope:
        {
            data:'='
        },
        templateUrl: "app/modules/custom/hix/directives/mqaHixMemberStats.tpl.html",
        link: function ($scope, element, attributes)
        {
            var updateData = function()
            {
                $scope.minValue = 0;
                $scope.maxValue = 0;
                $scope.avgValue = 0;
                if (!$scope.data || !$scope.data.length)
                    return;

                // routine to update the values when the data changes
                // work out the documents with the highest member counts
                var documents = hixDataSvc.calcMemberDocuments($scope.data);
                var memberArray = lodash.map(documents, function(value)
                {
                    return hixDataSvc.calculateMemberCount(value);
                });

                // now get the values
                $scope.minValue = lodash.min(memberArray);
                $scope.maxValue = lodash.max(memberArray);
                $scope.avgValue = (lodash.sum(memberArray) / memberArray.length);
            };
            $scope.$watchCollection("data", function()
            {
                updateData();
            });
            updateData();
        }
    }
  }]);

});


