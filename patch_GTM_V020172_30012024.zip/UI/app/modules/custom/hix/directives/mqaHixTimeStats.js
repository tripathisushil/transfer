/*
 /// <summary>
 /// modules.custom.hix.directives - mqaHixTimeStats
 /// Directive to display the HIX Statistics over time for the data selected

 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 7/18/2015
 /// </summary>
 */

define(['modules/custom/hix/module', 'lodash', 'dygraphs', 'dygraphs-sync'], function(module, lodash) {
  "use strict";

  module.registerDirective('mqaHixTimeStats', ['chartSvc','hixDataSvc', function(chartSvc, hixDataSvc){
    return {
        restrict: 'E',
        scope:
        {
            data:'='
        },
        templateUrl: "app/modules/custom/hix/directives/mqaHixTimeStats.tpl.html",
        link: function ($scope, element, attributes)
        {
            var sync;
            var graphs = {};
            var dynData = {};
            var metrics = [{property:"transactions", title: "No. of Transactions", color: "#496949"}, {property:"members", title: "No. of Members", color: "#6e587a"}, {property: "policies", title: "No. of Policies", color: "#57889c"}, {property: "documents", title: "No. of Documents", color: "#a57225"}];
            var syncGraphs = [];
            var buildGraphs = function()
            {

                // routine to build up the intial dyncharts that will be used throughout
                lodash.forEach(metrics, function(metric)
                {
                    dynData[metric.property] = [[0]];
                    var chartElement =  element.find(".hix_" + metric.property + "Chart");
                    var graph =  new Dygraph(chartElement[0], dynData[metric.property], {
                        title: metric.title,
                        xRangePad: 10,
                        drawPoints: true,
                        pointSize: 3,
                        //dateWindow: [Date.parse("2015/05/05 7:00:00"), Date.parse("2015/05/06 23:00:00")],
                        includeZero: true,
                        labels: ["local time", "Count"],
                        strokeWidth: 2.5,
                        series: {
                            Count: {
                                drawGapEdgePoints: true
                            }
                        }
                    });
                    syncGraphs.push(graph);
                    graphs[metric.property] = graph;
                });

                // setup the graph sync
                sync = Dygraph.synchronize(syncGraphs, {zoom: false, selection: true});

            };
            var updateData = function()
            {
                // routine to update the graphs when the data changes
                lodash.forEach(metrics, function(metric)
                {
                    dynData[metric.property] = [];
                });

                // loop through the transactions and map each date with a series object
                if ($scope.data && $scope.data.length)
                {

                    var chartData = lodash.chain($scope.data).sortBy("transDate").groupBy("transDate").map(function(values, key)
                    {
                        return hixDataSvc.buildStats(values, key);
                    }).sortBy("date").value();
                    lodash.forEach(chartData, function(statsRecord)
                    {
                        lodash.forEach(metrics, function(metric)
                        {
                            var point = [statsRecord.date, statsRecord[metric.property]];
                            dynData[metric.property].push(point);
                        });
                    });
                }

                // now update the graph
                lodash.forEach(metrics, function(metric)
                {
                    var graph = graphs[metric.property];
                    var realPointData = chartSvc.addRealTimeDatePoints(lodash.cloneDeep(dynData[metric.property]), 20, false);
                    graph.updateOptions( { file: realPointData, colors: [metric.color]});
                });

            };
            $scope.$watchCollection("data", function()
            {
                updateData();
            });
            buildGraphs();
        }
    }
  }]);

});


