/*
 /// <summary>
 /// app.modules.custom.hix.services - hixDataSvc.js
 /// Client Implementation of the Server Side HIX  Data Service
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 28/06/2015
 /// </summary>
 */
define(['modules/custom/hix/module','lodash'], function(module, lodash)
{
    "use strict";
    module.registerService('hixDataSvc',['transactionReportingSvc', function(transactionReportingSvc)
    {

        // dummy data for now when we get signal-r working - this will be populated by signalr
        var stats = {};
        stats.policies = {value: 10, chartData:[110,150,300,130,400]};
        stats.documents = {value: 10, chartData:[110,150,300,130,400]};
        stats.transactions = {value: 100, chartData:[310,150,300,130,240]};
        stats.members = {value: 50, chartData:[310,250,400,130,200]};
    
        var hasPolicyNumber = function(record)
        {
            // routine to return if the record has a policy number
            if (record == null)
                return 0;
            if (!record.indexes || !record.indexes.metaIndexes || !record.indexes.metaIndexes.eh_hixpolicy || record.indexes.metaIndexes.eh_hixpolicy == '')
                return false;
            return true;
        };


        var calculateMemberCount = function(record)
        {
            if (record == null)
                return 0;
            if (!record.indexes || !record.indexes.metaIndexes || !record.indexes.metaIndexes.eh_hixmember)
                return 0;

            // calculate the number of members from the given value
            return record.indexes.metaIndexes.eh_hixmember.split(",").length;
        };

        this.calculateMemberCount = calculateMemberCount;
        this.hasPolicyNumber = hasPolicyNumber;
        this.stats = stats;
        this.calcMemberDocuments = function(data)
        {
            // routine to calculate a unique set of hix documents based on the one that has the
            // highest member group
            var documents = transactionReportingSvc.getDocuments(data);
            return lodash.chain(documents).groupBy("docId").map(function(records, key)
            {
                var maxMembers = 0;
                var returnRecord = null;
                lodash.forEach(records, function (record)
                {
                    var members = calculateMemberCount(record);
                    if (members > maxMembers) {
                        returnRecord = record;
                        maxMembers = members;
                    }
                });
                return returnRecord;
            }).value();
        }

        this.getPolicyNumber = function(record)
        {
                return record.indexes.metaIndexes.eh_hixpolicy;
        };


        this.buildStats = function(records, dateStr)
        {
            // routine to build up statistics for the given group of records
            var dataObject = {date: new Date(dateStr), policies: 0, transactions: 0, members: 0, documents: 0};
            var documents = {};

            lodash.forEach(records, function (record)  {
                dataObject.transactions += 1;

                // check if the document of this record has been counted
                if (record.docId && record.docId != '')
                {
                    if  (documents[record.docId] == null)
                    {
                        documents[record.docId] = true;
                        dataObject.documents += 1;
                    }
                    if (dataObject.members == 0)
                        dataObject.members = calculateMemberCount(record);
                    if (dataObject.policies == 0 && hasPolicyNumber(record))
                        dataObject.policies = 1;
                }
            });
            return dataObject;
        };

        this.getActionCodeList = function(data)
        {
            // routine to break down the action code list
            var returnList = [];
            var actionCodes = lodash.chain(data).map("indexes.metaIndexes.eh_hixactioncode").compact().value();
            lodash.forEach(actionCodes, function(actionCode)
            {
                var splitCodes = actionCode.split(",");
                lodash.forEach(splitCodes, function(code)
                {
                    returnList.push({actionCode: code})
                });
            });
            return returnList;

        }
    }]);
});
