/*
 /// <summary>
 /// app - app.js
 /// Angular Startup Configuration for the UI
 /// Adapted from the SmartAdmin Template
 ///
 /// Copyright © 2009 - MQAttach Canada Inc. and All associated Companies
 /// Written By: Mac Bhyat
 /// Date: 11/25/2014
 /// </summary>

 */
'use strict';

define([
    'angular',
    'angular-couch-potato',
    'appCustomConfig',
    'appConfig',
    'angular-ui-router',
    'angular-animate',
    'angular-bootstrap',
    'angular-sanitize',
    'angular-ui-select',
    'smartwidgets',
    'notification',
    'satellizer'
], function (ng, couchPotato, appCustomConfig, appConfig) {

    var app = ng.module('app', [

        //<editor-fold desc="Angular Dependencies">
        'ngSanitize',

        'scs.couch-potato',
        'ngAnimate',
        'ui.router',
        'ui.bootstrap',
        'ui.select',
        'satellizer',
        //</editor-fold>

        //<editor-fold desc="SmartAdmin Dependencies">

        'app.layout',
        'app.graphs',
        'app.tables',
        'app.forms',
        'app.ui',
        'app.widgets',
        //</editor-fold>

        // TODO Define Application Dependencies here
        //<editor-fold desc="Application Dependencies">
        'app.mqacommon',
        'app.mqainstall',
        'app.mqaauth',    
        'app.mqalayout',
        'app.mqatr',
        'app.mqamft',
        'app.mqamft_v2',
        'app.mqabridge',
        'app.mqaadmin',
        'app.mqaiib',
        'app.mqaiib_v2',
        'app.mqaspe',
        'app.mqaboomi',
        'app.mqacustom.hix',
        'app.mqacustom.mckclmxtent',
        'app.mqacustom.mfthix',
        'app.mqacustom.hcnspe',
        'app.mqacustom.spe_cno',
        'app.mqacustom.iib_ncl'
        //</editor-fold>
    ]);

    couchPotato.configureApp(app);

    app.config(function ($provide, $httpProvider, uiSelectConfig, $authProvider, $locationProvider) {

        // set the hash prefix
        //$locationProvider.html5Mode(false).hashPrefix('!');


        // setup the ui-config theme
        uiSelectConfig.theme = 'select2';


        // Intercept http calls.
        $provide.factory('ErrorHttpInterceptor', function ($q) {
            var errorCounter = 0;
            function notifyError(rejection)
            {
                // check if this is an authorization issue
                if (rejection.status == 401 && (rejection.data && rejection.data.jwt))
                    return;
                console.error("http_error=", rejection);
                if (rejection.status == -1)
                {
                    rejection.status = "503";
                    rejection.statusText = "Service Unavailable";
                    var parser = document.createElement('a');
                    parser.href = rejection.config.url;
                    rejection.data = "Please confirm that the following Web Server is running <br/>" + parser.protocol+"://" + parser.hostname + ":" + parser.port;
                };

                $.bigBox({
                    title: rejection.status + ' ' + rejection.statusText,
                    content: rejection.data,
                    color: "#C46A69",
                    icon: "fa fa-warning shake animated",
                    number: ++errorCounter,
                    timeout: 6000
                });
            }

            return {
                // On request failure
                requestError: function (rejection) {
                    // show notification
                    notifyError(rejection);

                    // Return the promise rejection.
                    return $q.reject(rejection);
                },

                // On response failure
                responseError: function (rejection) {
                    // show notification
                    notifyError(rejection);
                    // Return the promise rejection.
                    return $q.reject(rejection);
                }
            };
        });

        // Add the interceptor to the $httpProvider.
        $httpProvider.interceptors.push('ErrorHttpInterceptor');
    });

    app.run(function ($couchPotato, $rootScope, $state, $stateParams) {
        app.lazy = $couchPotato;
        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;
        // editableOptions.theme = 'bs3';
    });

    return app;
});
